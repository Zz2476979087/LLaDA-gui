<div align="center">

# LLaDA-GUI

### GUI Grounding through Screen-State Masked Diffusion

</div>

<div align="center">
<img src="assets/llada_gui_overview.png" width="100%" alt="LLaDA-GUI overview">
</div>

<p align="center"><i>
LLaDA-GUI recovers an instruction-conditioned screen state and reads out the
grounded click from a unified spatial field.
</i></p>

LLaDA-GUI grounds a natural-language instruction in a complete GUI screenshot.
It represents the screen as a canonical visual lattice whose cells take one of
three states: **Target**, **Background**, or **Mask**. An instruction-conditioned
action field recovers this state with absorbing categorical diffusion, and a
region readout deterministically serializes the final click as
`lclick [x1,y1,x2,y2]`.

## Code map

- `src/llava/model/language_model/screen_state_action_field.py`: feature fusion,
  screen-state mixing, action energy, reverse recovery, and
  `L_map + lambda_x0 L_x0 + L_reg`.
- `src/llava/train/`: normalized data loading, MDM masking, optimization, and
  the localization-first curriculum.
- `src/llada_gui/`: grounding prompt, region-based click readout, and action
  serialization.
- `eval/`: LLaDA-GUI prediction and ScreenSpot-v2 evaluation.
- `scripts/`: reproducible training and evaluation entry points.

The LLaDA-V, LLaVA-compatible multimodal runtime, SigLIP-2, Transformers, and
FlashAttention code paths are backbone/runtime dependencies. Their original
license and copyright notices are retained where applicable.

## Environment

The released recipes target Linux, Python 3.11, CUDA 12.4, and NVIDIA GPUs.
Create the environment and install this package in editable mode:

```bash
conda env create -f environment.yaml
conda activate llada-gui
pip install -e .
```

Model weights, the SigLIP-2 vision tower, datasets, and screenshots are not
included in this repository. Download or place them locally, then provide their
paths through `MODEL_PATH`, `TOKENIZER_PATH`, and `VISION_TOWER`. The training
and evaluation scripts default to offline Hugging Face loading so that a run
does not silently fetch a different model revision.

## Data

Training data is not bundled. The normalized JSON contract is documented in
`data/FORMAT.md`. Validate a corpus before launching training:

```bash
python scripts/validate_data.py --data /path/to/train.json
```

To construct the normalized ScreenSpot-v2 evaluation manifest from its
official Mobile, Desktop, and Web JSONL files:

```bash
python eval/prepare_screenspot_v2.py \
  --source-root /path/to/screenspot_v2 \
  --output data/eval/screenspot_v2_official.json
```

The source root must contain `screenspot_v2_mobile.jsonl`,
`screenspot_v2_desktop.jsonl`, `screenspot_v2_web.jsonl`, and an `images/`
directory.

## Training

The action field uses the paper losses directly. `localization_first` presents
the all-Mask boundary and updates only the action field; `joint_optimization`
enables sampled screen states and full optimization while preserving the same
forward definition.

```bash
MODEL_PATH=/path/to/LLaDA-V-8B \
TOKENIZER_PATH=/path/to/LLaDA-V-8B \
VISION_TOWER=/path/to/siglip2-so400m-patch14-384 \
DATA_PATH=/path/to/train.json \
IMAGE_FOLDER=/path/to/images \
OUTPUT_DIR=/path/to/output \
GPUS=4 \
TRAIN_RECIPE=localization_first \
bash scripts/train.sh

MODEL_PATH=/path/to/LLaDA-V-8B \
TOKENIZER_PATH=/path/to/LLaDA-V-8B \
VISION_TOWER=/path/to/siglip2-so400m-patch14-384 \
DATA_PATH=/path/to/train.json \
IMAGE_FOLDER=/path/to/images \
OUTPUT_DIR=/path/to/output \
GPUS=4 \
TRAIN_RECIPE=joint_optimization \
bash scripts/train.sh
```

All recipe constants can be overridden through the `LLADA_GUI_*` variables in
`scripts/train.sh`.

## Inference and evaluation

Paper-facing inference uses four reverse updates, committed target support, a
peak-relative threshold of `0.30`, and a local decoding radius of `2`:

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3 \
EVAL_GPUS=4 \
MODEL_PATH=/path/to/checkpoint \
VISION_TOWER=/path/to/siglip2-so400m-patch14-384 \
IMAGE_FOLDER=/path/to/screenspot_v2/images \
MANIFEST=/path/to/screenspot_v2.json \
OUTPUT=/path/to/predictions.json \
REPORT_OUTPUT=/path/to/prediction_report.json \
METRICS_OUTPUT=/path/to/metrics.json \
bash scripts/eval_screenspot_v2.sh
```

Coordinate slots remain masked query context. They neither participate in
screen-state recovery nor generate the final point; coordinates are serialized
once after region decoding.

The evaluation entry point writes the merged predictions, a recovery report,
and ScreenSpot-v2 point-in-box accuracy broken down by domain and target type.

## Verification

CPU tests cover action serialization, region readout, screen-state corruption,
action-field stability, and loss decomposition. The optional Slurm smoke test
performs one real-checkpoint GPU inference followed by one training
forward/backward step:

```bash
pip install -e '.[test]'
PYTHONPATH=src pytest -q
sbatch tests/gpu_smoke.sbatch
```

The GPU smoke script intentionally requires `CHECKPOINT_PATH`,
`SMOKE_MANIFEST`, `SMOKE_IMAGE_FOLDER`, `TRAIN_DATA`, and `ACTION_FIELD_INIT`
through environment variables; inspect its header before submission.

## License

The project is released under the license in `LICENSE`. Backbone/runtime files
retain their applicable upstream notices.
