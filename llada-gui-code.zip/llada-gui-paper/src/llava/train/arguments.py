"""Command-line arguments for LLaDA-GUI training."""

from dataclasses import dataclass, field
from typing import Optional

import transformers


@dataclass
class ModelArguments:
    model_name_or_path: str = field(default="GSAI-ML/LLaDA-V")
    tokenizer_name_or_path: Optional[str] = None
    version: str = field(default="llava_llada")
    vision_tower: Optional[str] = None
    mm_tunable_parts: str = field(
        default="mm_vision_tower,mm_mlp_adapter,mm_language_model"
    )
    mm_vision_select_layer: int = field(default=-2)
    mm_vision_select_feature: str = field(default="patch")
    mm_projector_type: str = field(default="mlp2x_gelu")
    mm_patch_merge_type: str = field(default="spatial_unpad")
    mm_use_im_start_end: bool = field(default=False)
    mm_use_im_patch_token: bool = field(default=False)
    mm_newline_position: str = field(default="grid")
    pretrain_mm_mlp_adapter: Optional[str] = None
    vision_tower_pretrained: Optional[str] = None
    delay_load: bool = field(default=True)
    tune_mm_mlp_adapter: bool = field(default=False)
    add_faster_video: bool = field(default=False)


@dataclass
class DataArguments:
    data_path: str = field(metadata={"help": "Normalized screenshot-grounding JSON"})
    image_folder: Optional[str] = None
    image_aspect_ratio: str = field(default="anyres_max_6")
    image_grid_pinpoints: Optional[str] = None
    image_crop_resolution: Optional[int] = None
    image_split_resolution: Optional[int] = None
    lazy_preprocess: bool = field(default=True)
    is_multimodal: bool = field(default=False, init=False)
    image_processor: object = field(default=None, init=False, repr=False)
    mm_use_im_start_end: bool = field(default=False, init=False)


@dataclass
class TrainingArguments(transformers.TrainingArguments):
    cache_dir: Optional[str] = None
    remove_unused_columns: bool = field(default=False)
    model_max_length: int = field(default=8192)
    attn_implementation: str = field(default="flash_attention_2")
    lora_enable: bool = field(default=False)

    mm_projector_lr: Optional[float] = None
    mm_vision_tower_lr: Optional[float] = None
    screen_state_lr: Optional[float] = None
    group_by_modality_length: bool = field(default=True)
    train_sample_plan_output: Optional[str] = None
    train_sampler_seed: Optional[int] = None
    seed_before_model_init: bool = field(default=False)
    model_init_seed: Optional[int] = None

    use_conversation_mask: bool = field(default=False)
    action_token_weighting: bool = field(default=True)
    action_token_weight: float = field(default=1.10)
    icon_action_token_weight: float = field(default=1.20)
    small_icon_action_token_weight: float = field(default=1.25)
    coordinate_token_weighting: bool = field(default=True)
    coordinate_token_weight: float = field(default=1.05)
    icon_coordinate_token_weight: float = field(default=1.10)
    small_icon_coordinate_token_weight: float = field(default=1.15)

    screen_state_objective: bool = field(default=True)
    screen_state_loss_weight: float = field(default=1.0)

    # Populated by the training setup and consumed by LLaDAGUITrainer.
    mm_tunable_parts: Optional[str] = field(default=None, init=False)
    use_im_start_end: bool = field(default=False, init=False)
