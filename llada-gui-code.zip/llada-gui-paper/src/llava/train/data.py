"""Normalized screenshot-grounding data pipeline for LLaDA-GUI."""

from __future__ import annotations

import copy
import json
import os
import re
import time
from dataclasses import dataclass
from typing import Dict, Optional, Sequence

import torch
from PIL import Image, ImageFile
from torch.utils.data import Dataset
import transformers

from llava.constants import (
    DEFAULT_IMAGE_TOKEN,
    DEFAULT_IM_END_TOKEN,
    DEFAULT_IM_START_TOKEN,
    IGNORE_INDEX,
    IMAGE_TOKEN_INDEX,
)
from llava.mm_utils import process_anyres_image
from llava.utils import rank0_print
from .arguments import DataArguments, TrainingArguments


ImageFile.LOAD_TRUNCATED_IMAGES = True
ACTION_RE = re.compile(
    r"(?:lclick|click)\s*\[\s*([0-9.]+)\s*,\s*([0-9.]+)\s*,\s*"
    r"([0-9.]+)\s*,\s*([0-9.]+)\s*\]"
)
COORD_RE = re.compile(r"-?\d+(?:\.\d+)?")
ACTION_MARKER = "<|gui_ptr|>"
SYSTEM_MESSAGE = (
    "You are a helpful language and vision assistant. You are able to understand "
    "the visual content that the user provides, and assist the user with a variety "
    "of tasks using natural language."
)
CHAT_TEMPLATE = (
    "{% for message in messages %}{{'<|startoftext|>' + "
    "'<|start_header_id|>' + message['role'] + '<|end_header_id|>' + "
    "'\\n\\n' + message['content'] + '<|eot_id|>'}}{% endfor %}"
    "{% if add_generation_prompt %}{{ '<|start_header_id|>assistant"
    "<|end_header_id|>\\n\\n' }}{% endif %}"
)


def _find_subsequence(sequence, pattern):
    if not pattern or len(pattern) > len(sequence):
        return -1
    for start in range(len(sequence) - len(pattern) + 1):
        if sequence[start : start + len(pattern)] == pattern:
            return start
    return -1


def _parse_box(value):
    if isinstance(value, str):
        match = ACTION_RE.search(value)
        if not match:
            return None
        coordinates = [float(item) for item in match.groups()]
    elif isinstance(value, (list, tuple)) and len(value) >= 4:
        coordinates = [float(item) for item in value[:4]]
        if max(abs(item) for item in coordinates) <= 1.5:
            coordinates = [item * 1000.0 for item in coordinates]
    else:
        return None
    x1, y1, x2, y2 = coordinates
    x1, x2 = sorted((max(0.0, min(1000.0, x1)), max(0.0, min(1000.0, x2))))
    y1, y2 = sorted((max(0.0, min(1000.0, y1)), max(0.0, min(1000.0, y2))))
    return (x1, y1, x2, y2) if x2 > x1 and y2 > y1 else None


def _box_area(box):
    return (box[2] - box[0]) * (box[3] - box[1])


def _box_center(box):
    return ((box[0] + box[2]) * 0.5, (box[1] + box[3]) * 0.5)


def _select_target_box(row):
    """Select a valid target box, with the serialized click box as fallback."""
    click_box = _parse_box(row.get("target_action"))
    if click_box is None:
        raise ValueError(f"invalid target_action: {row.get('target_action')!r}")
    metadata = row.get("metadata") or {}
    candidate = _parse_box(
        row.get("gui_target_bbox_1000")
        or metadata.get("gui_target_bbox_1000")
        or row.get("bbox_xyxy_norm")
        or metadata.get("bbox_xyxy_norm")
    )
    if candidate is None or _box_area(candidate) > 60000.0:
        return click_box
    click_center = _box_center(click_box)
    target_center = _box_center(candidate)
    distance = (
        (click_center[0] - target_center[0]) ** 2
        + (click_center[1] - target_center[1]) ** 2
    ) ** 0.5
    if distance > 80.0 or _box_area(candidate) < _box_area(click_box):
        return click_box
    return candidate


def _select_negative_box(row):
    metadata = row.get("metadata") or {}
    candidate = _parse_box(
        metadata.get("gui_visual_negative_bbox_1000")
        or row.get("gui_visual_negative_bbox_1000")
    )
    if candidate is None or _box_area(candidate) > 60000.0:
        return None
    return candidate


def _append_action_marker(row):
    row = copy.deepcopy(row)
    action = str(row.get("target_action") or "").strip()
    marked_action = action if ACTION_MARKER in action else f"{action} {ACTION_MARKER}"
    row["target_action"] = marked_action
    for message in row.get("conversations") or []:
        if (message.get("from") or message.get("role")) in {"gpt", "assistant"}:
            if "value" in message:
                message["value"] = marked_action
            else:
                message["content"] = marked_action
            break
    return row


def _coord_mask(content, content_ids, tokenizer):
    spans = [match.span() for match in COORD_RE.finditer(str(content or ""))]
    mask = [0] * len(content_ids)
    if not spans:
        return mask
    try:
        encoded = tokenizer(
            content, add_special_tokens=False, return_offsets_mapping=True
        )
        if list(encoded["input_ids"]) == list(content_ids):
            for index, (start, end) in enumerate(encoded["offset_mapping"]):
                if any(start < right and end > left for left, right in spans):
                    mask[index] = 1
            if any(mask):
                return mask
    except Exception:
        pass
    for index, token_id in enumerate(content_ids):
        piece = tokenizer.decode([int(token_id)], skip_special_tokens=False)
        mask[index] = int(any(character.isdigit() for character in piece))
    return mask


def _task_instruction(content):
    text = re.sub(r"<image>", " ", str(content or ""), flags=re.IGNORECASE)
    for marker in (
        "Return exactly one action",
        "Use this format",
        "The box should",
        "Do not output",
    ):
        text = re.split(marker, text, maxsplit=1, flags=re.IGNORECASE)[0]
    return re.sub(r"\s+", " ", text).strip()


def preprocess_multimodal(sources, data_args):
    for source in sources:
        for message in source:
            value = message.get("value", message.get("content", ""))
            if value.count(DEFAULT_IMAGE_TOKEN) == 1 and not value.startswith(
                DEFAULT_IMAGE_TOKEN
            ):
                value = DEFAULT_IMAGE_TOKEN + "\n" + value.replace(
                    DEFAULT_IMAGE_TOKEN, ""
                ).strip()
            replacement = DEFAULT_IMAGE_TOKEN
            if data_args.mm_use_im_start_end:
                replacement = DEFAULT_IM_START_TOKEN + replacement + DEFAULT_IM_END_TOKEN
            value = value.replace(DEFAULT_IMAGE_TOKEN, replacement)
            if "value" in message:
                message["value"] = value
            else:
                message["content"] = value
    return sources


def preprocess_llada(sources, tokenizer, has_image=True) -> Dict[str, torch.Tensor]:
    """Serialize conversations and identify MDM and action-query positions."""
    roles = {"human": "user", "gpt": "assistant"}
    tokenizer = copy.deepcopy(tokenizer)
    if has_image:
        tokenizer.add_tokens([DEFAULT_IMAGE_TOKEN], special_tokens=True)
    image_token_id = tokenizer.convert_tokens_to_ids(DEFAULT_IMAGE_TOKEN)
    bos_token_id = tokenizer.convert_tokens_to_ids("<|startoftext|>")
    eot_id = tokenizer.convert_tokens_to_ids("<|eot_id|>")
    unmasked_ids = {
        tokenizer.convert_tokens_to_ids(token)
        for token in (
            "<|startoftext|>",
            "<|start_header_id|>",
            "<|end_header_id|>",
            "<|eot_id|>",
            "\n\n",
        )
    }
    tokenizer.chat_template = CHAT_TEMPLATE

    def encode_content(text):
        ids = tokenizer(text).input_ids
        return ids[1:] if ids and ids[0] == bos_token_id else ids

    all_ids, all_labels = [], []
    all_action_masks, all_coord_masks, all_action_query_masks = [], [], []
    all_instruction_masks = []
    for source in sources:
        if roles.get(source[0].get("from"), source[0].get("role")) != "user":
            source = source[1:]
        input_ids = tokenizer.apply_chat_template(
            [{"role": "system", "content": SYSTEM_MESSAGE}]
        )
        labels = [IGNORE_INDEX] * len(input_ids)
        action_mask = [0] * len(input_ids)
        coord_mask = [0] * len(input_ids)
        action_query_mask = [0] * len(input_ids)
        instruction_mask = [0] * len(input_ids)

        for message in source:
            role = roles.get(
                message.get("from", message.get("role")),
                message.get("from", message.get("role")),
            )
            content = message.get("value", message.get("content", ""))
            encoded = tokenizer.apply_chat_template(
                [{"role": role, "content": content}]
            )[1:]
            input_ids.extend(encoded)
            segment_labels = (
                [IGNORE_INDEX] * len(encoded) if role in {"user", "system"} else list(encoded)
            )
            segment_action = [0] * len(encoded)
            segment_coord = [0] * len(encoded)
            segment_query = [0] * len(encoded)
            segment_instruction = [0] * len(encoded)

            if role == "user":
                instruction_ids = encode_content(_task_instruction(content))
                instruction_start = _find_subsequence(encoded, instruction_ids)
                if instruction_start >= 0:
                    for offset, token_id in enumerate(instruction_ids):
                        if token_id not in unmasked_ids and token_id != image_token_id:
                            segment_instruction[instruction_start + offset] = 1
            elif role == "assistant":
                content_ids = encode_content(content)
                start = _find_subsequence(encoded, content_ids)
                if start < 0:
                    start = 0
                action_marker_patterns = [encode_content(ACTION_MARKER), encode_content(" " + ACTION_MARKER)]
                action_marker_start = -1
                for pattern in action_marker_patterns:
                    action_marker_start = _find_subsequence(content_ids, pattern)
                    if action_marker_start >= 0:
                        for offset in range(len(pattern)):
                            segment_query[start + action_marker_start + offset] = 1
                        break
                local_coord = _coord_mask(content, content_ids, tokenizer)
                for offset in range(len(content_ids)):
                    position = start + offset
                    if position >= len(encoded):
                        break
                    segment_action[position] = 1
                    segment_coord[position] = local_coord[offset]
                if ACTION_RE.search(content) or ACTION_MARKER in content:
                    for position, token_id in enumerate(encoded):
                        if token_id == eot_id:
                            segment_action[position] = 1
                for position, is_actor in enumerate(segment_query):
                    if is_actor:
                        segment_labels[position] = IGNORE_INDEX

            labels.extend(segment_labels)
            action_mask.extend(segment_action)
            coord_mask.extend(segment_coord)
            action_query_mask.extend(segment_query)
            instruction_mask.extend(segment_instruction)

        for position, token_id in enumerate(input_ids):
            if token_id in unmasked_ids:
                labels[position] = token_id
            if token_id == image_token_id:
                input_ids[position] = IMAGE_TOKEN_INDEX
        all_ids.append(input_ids)
        all_labels.append(labels)
        all_action_masks.append(action_mask)
        all_coord_masks.append(coord_mask)
        all_action_query_masks.append(action_query_mask)
        all_instruction_masks.append(instruction_mask)

    return {
        "input_ids": torch.tensor(all_ids, dtype=torch.long),
        "labels": torch.tensor(all_labels, dtype=torch.long),
        "action_token_mask": torch.tensor(all_action_masks, dtype=torch.long),
        "coordinate_token_mask": torch.tensor(all_coord_masks, dtype=torch.long),
        "action_query_token_mask": torch.tensor(all_action_query_masks, dtype=torch.long),
        "instruction_token_mask": torch.tensor(
            all_instruction_masks, dtype=torch.long
        ),
    }


class LazySupervisedDataset(Dataset):
    """Lazy loader for the normalized, screenshot-only training corpus."""

    def __init__(self, data_path, tokenizer, data_args, training_args=None):
        if not data_path.endswith(".json"):
            raise ValueError("data_path must be one normalized JSON corpus")
        with open(data_path, encoding="utf-8") as handle:
            self.list_data_dict = json.load(handle)
        if not isinstance(self.list_data_dict, list):
            raise TypeError("training JSON must contain a list")
        rank0_print(f"Loaded {len(self.list_data_dict)} samples from {data_path}")
        self.tokenizer = tokenizer
        self.data_args = data_args
        self.training_args = training_args

    def __len__(self):
        return len(self.list_data_dict)

    @property
    def modality_lengths(self):
        return [
            sum(len(message["value"].split()) for message in row["conversations"])
            for row in self.list_data_dict
        ]

    def _process_image(self, image_file):
        path = image_file if os.path.isabs(image_file) else os.path.join(
            self.data_args.image_folder or "", image_file
        )
        image = Image.open(path).convert("RGB")
        image_size = image.size
        if "anyres" not in self.data_args.image_aspect_ratio:
            raise ValueError("LLaDA-GUI requires an any-resolution image layout")
        pixels = process_anyres_image(
            image,
            self.data_args.image_processor,
            self.data_args.image_grid_pinpoints,
        )
        return pixels, image_size, "image"

    def __getitem__(self, index):
        for attempt in range(3):
            try:
                return self._get_item(index)
            except Exception as error:
                if attempt == 2:
                    raise
                print(f"[retry {attempt + 1}] sample {index}: {error}")
                time.sleep(1)

    def _get_item(self, index):
        row = self.list_data_dict[index]
        if "image" not in row or isinstance(row["image"], list) or "video" in row:
            raise ValueError("each row must contain exactly one screenshot")
        if not self.training_args or not self.training_args.screen_state_objective:
            raise ValueError("screen_state_objective must be enabled")

        source_row = _append_action_marker(row)
        image = [self._process_image(source_row["image"])]
        sources = preprocess_multimodal(
            copy.deepcopy([source_row["conversations"]]), self.data_args
        )
        encoded = preprocess_llada(sources, self.tokenizer, has_image=True)
        item = {key: value[0] for key, value in encoded.items()}

        metadata = row.get("metadata") or {}
        is_icon = bool(
            metadata.get("gui_is_icon", metadata.get("is_icon", False))
            or str(row.get("target_kind", "")).lower() == "icon"
        )
        item.update(
            image=image,
            id=row.get("id", index),
            gui_is_icon=is_icon,
            gui_is_visual_icon=bool(
                metadata.get("gui_is_visual_icon", metadata.get("is_visual_icon", is_icon))
            ),
            # Serialized clicks use a 10x10 box around the readout point; icon
            # rows therefore receive the small-target token weights.
            gui_is_small=is_icon,
            target_box_1000=torch.tensor(_select_target_box(row), dtype=torch.float32),
            target_row_mask=True,
        )
        negative = _select_negative_box(row)
        item["negative_box_1000"] = torch.tensor(
            negative or (0.0, 0.0, 0.0, 0.0), dtype=torch.float32
        )
        item["negative_row_mask"] = negative is not None
        return item


@dataclass
class DataCollatorForSupervisedDataset:
    tokenizer: transformers.PreTrainedTokenizer
    training_args: Optional[TrainingArguments] = None

    def _pad(self, tensors, value):
        return torch.nn.utils.rnn.pad_sequence(
            tensors, batch_first=True, padding_value=value
        )

    def __call__(self, instances: Sequence[Dict]) -> Dict[str, torch.Tensor]:
        limit = self.tokenizer.model_max_length
        input_ids = [item["input_ids"][:limit] for item in instances]
        labels = [item["labels"][:limit] for item in instances]
        action_masks = [item["action_token_mask"][:limit] for item in instances]
        coord_masks = [item["coordinate_token_mask"][:limit] for item in instances]
        action_query_masks = [item["action_query_token_mask"][:limit] for item in instances]
        instruction_masks = [
            item["instruction_token_mask"][:limit] for item in instances
        ]
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token_id = 0

        input_ids = self._pad(input_ids, self.tokenizer.pad_token_id)
        # LLaDA's historical collator supervises structural pad tokens.
        labels = self._pad(labels, self.tokenizer.pad_token_id)
        action_masks = self._pad(action_masks, 0).bool()
        coord_masks = self._pad(coord_masks, 0).bool()
        action_query_masks = self._pad(action_query_masks, 0).bool()
        instruction_masks = self._pad(instruction_masks, 0).bool()
        batch = {"input_ids": input_ids, "labels": labels}

        weights = torch.ones(labels.shape, dtype=torch.float32)
        for row_index, item in enumerate(instances):
            is_icon = bool(item["gui_is_icon"])
            action_weight = (
                self.training_args.small_icon_action_token_weight
                if is_icon and item["gui_is_small"]
                else self.training_args.icon_action_token_weight
                if is_icon
                else self.training_args.action_token_weight
            )
            coord_weight = (
                self.training_args.small_icon_coordinate_token_weight
                if is_icon and item["gui_is_small"]
                else self.training_args.icon_coordinate_token_weight
                if is_icon
                else self.training_args.coordinate_token_weight
            )
            if self.training_args.action_token_weighting:
                weights[row_index] = torch.where(
                    action_masks[row_index],
                    torch.maximum(
                        weights[row_index],
                        torch.full_like(weights[row_index], float(action_weight)),
                    ),
                    weights[row_index],
                )
            if self.training_args.coordinate_token_weighting:
                weights[row_index] = torch.where(
                    coord_masks[row_index],
                    torch.maximum(
                        weights[row_index],
                        torch.full_like(weights[row_index], float(coord_weight)),
                    ),
                    weights[row_index],
                )
        batch["mdm_token_weights"] = weights
        batch["mdm_mask_positions"] = labels.ne(IGNORE_INDEX).long()
        batch["action_query_token_mask"] = action_query_masks
        batch["instruction_token_mask"] = instruction_masks
        batch["coordinate_token_mask"] = coord_masks

        images = [entry for item in instances for entry in item["image"]]
        batch["images"] = [entry[0] for entry in images]
        batch["image_sizes"] = [entry[1] for entry in images]
        batch["modalities"] = [entry[2] for entry in images]
        batch["target_boxes_1000"] = torch.stack(
            [item["target_box_1000"] for item in instances]
        )
        batch["target_row_mask"] = torch.tensor(
            [item["target_row_mask"] for item in instances], dtype=torch.bool
        )
        batch["target_is_icon"] = torch.tensor(
            [item["gui_is_visual_icon"] for item in instances], dtype=torch.bool
        )
        batch["negative_boxes_1000"] = torch.stack(
            [item["negative_box_1000"] for item in instances]
        )
        batch["negative_row_mask"] = torch.tensor(
            [item["negative_row_mask"] for item in instances],
            dtype=torch.bool,
        )
        return batch


def make_supervised_data_module(tokenizer, data_args, training_args):
    dataset = LazySupervisedDataset(
        data_path=data_args.data_path,
        tokenizer=tokenizer,
        data_args=data_args,
        training_args=training_args,
    )
    collator = DataCollatorForSupervisedDataset(tokenizer, training_args)
    return {"train_dataset": dataset, "eval_dataset": None, "data_collator": collator}
