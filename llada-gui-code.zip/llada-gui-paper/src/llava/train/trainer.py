"""Sampling and optimizer utilities for the LLaDA-GUI training recipe."""

from __future__ import annotations

import hashlib
import json
import os
from typing import List, Optional

import torch
from torch.utils.data import Sampler
from transformers import Trainer
from transformers.trainer import (
    ALL_LAYERNORM_LAYERS,
    get_parameter_names,
    is_sagemaker_mp_enabled,
)


def split_to_even_chunks(indices, lengths, num_chunks):
    """Balance a length-sorted megabatch across distributed workers."""
    if len(indices) % num_chunks:
        return [indices[i::num_chunks] for i in range(num_chunks)]

    per_chunk = len(indices) // num_chunks
    chunks = [[] for _ in range(num_chunks)]
    chunk_lengths = [0 for _ in range(num_chunks)]
    for index in indices:
        target = chunk_lengths.index(min(chunk_lengths))
        chunks[target].append(index)
        chunk_lengths[target] += lengths[index]
        if len(chunks[target]) == per_chunk:
            chunk_lengths[target] = float("inf")
    return chunks


def get_length_grouped_indices(lengths, batch_size, world_size, generator=None):
    """Return a length-balanced random ordering."""
    indices = torch.randperm(len(lengths), generator=generator)
    megabatch_size = world_size * batch_size
    megabatches = [
        indices[i : i + megabatch_size].tolist()
        for i in range(0, len(lengths), megabatch_size)
    ]
    megabatches = [
        sorted(batch, key=lambda index: lengths[index], reverse=True)
        for batch in megabatches
    ]
    megabatches = [
        split_to_even_chunks(batch, lengths, world_size)
        for batch in megabatches
    ]
    return [index for batch in megabatches for chunk in batch for index in chunk]


def get_modality_length_grouped_indices(
    lengths, batch_size, world_size, generator=None
):
    """Group image and text rows separately before length balancing."""
    if not lengths or any(length == 0 for length in lengths):
        raise ValueError("modality lengths must be non-zero")
    if all(length > 0 for length in lengths) or all(length < 0 for length in lengths):
        return get_length_grouped_indices(
            lengths, batch_size, world_size, generator=generator
        )

    image_pairs = [(i, length) for i, length in enumerate(lengths) if length > 0]
    text_pairs = [(i, -length) for i, length in enumerate(lengths) if length < 0]
    image_indices, image_lengths = zip(*image_pairs)
    text_indices, text_lengths = zip(*text_pairs)
    image_order = [
        image_indices[i]
        for i in get_length_grouped_indices(
            image_lengths, batch_size, world_size, generator=None
        )
    ]
    text_order = [
        text_indices[i]
        for i in get_length_grouped_indices(
            text_lengths, batch_size, world_size, generator=None
        )
    ]

    megabatch_size = world_size * batch_size
    image_batches = [
        image_order[i : i + megabatch_size]
        for i in range(0, len(image_order), megabatch_size)
    ]
    text_batches = [
        text_order[i : i + megabatch_size]
        for i in range(0, len(text_order), megabatch_size)
    ]
    tail = image_batches[-1] + text_batches[-1]
    batches = image_batches[:-1] + text_batches[:-1]
    permutation = torch.randperm(len(batches), generator=generator)
    batches = [batches[i] for i in permutation]
    if tail:
        batches.append(sorted(tail))
    return [index for batch in batches for index in batch]


class LengthGroupedSampler(Sampler):
    """Length-balanced sampler with optional modality grouping."""

    def __init__(
        self,
        batch_size: int,
        world_size: int,
        lengths: Optional[List[int]],
        generator=None,
        group_by_modality: bool = False,
    ):
        if lengths is None:
            raise ValueError("lengths must be provided")
        self.batch_size = batch_size
        self.world_size = world_size
        self.lengths = lengths
        self.generator = generator
        self.group_by_modality = group_by_modality

    def __len__(self):
        return len(self.lengths)

    def __iter__(self):
        grouping = (
            get_modality_length_grouped_indices
            if self.group_by_modality
            else get_length_grouped_indices
        )
        return iter(
            grouping(
                self.lengths,
                self.batch_size,
                self.world_size,
                generator=self.generator,
            )
        )


class LLaDAGUITrainer(Trainer):
    """Trainer with the paper recipe's sampler and parameter-group learning rates."""

    def _sampler_generator(self):
        seed = getattr(self.args, "train_sampler_seed", None)
        if seed is None:
            return None
        generator = torch.Generator()
        generator.manual_seed(int(seed))
        return generator

    def _get_train_sampler(self):
        if self.train_dataset is None:
            return None
        if getattr(self.args, "group_by_modality_length", False):
            return LengthGroupedSampler(
                batch_size=self.args.train_batch_size,
                world_size=self.args.world_size * self.args.gradient_accumulation_steps,
                lengths=self.train_dataset.modality_lengths,
                generator=self._sampler_generator(),
                group_by_modality=True,
            )
        return super()._get_train_sampler()

    def get_train_dataloader(self):
        dataloader = super().get_train_dataloader()
        output = getattr(self.args, "train_sample_plan_output", None)
        if output and not getattr(self, "_sample_plan_written", False):
            self._write_sample_plan(output)
        return dataloader

    def _write_sample_plan(self, output):
        """Write a compact, deterministic audit of the sampled training rows."""
        if not self.is_world_process_zero():
            return
        sampler = self._get_train_sampler()
        indices = list(iter(sampler)) if sampler is not None else list(range(len(self.train_dataset)))
        rows = getattr(self.train_dataset, "list_data_dict", [])
        ids = [str((rows[i].get("id") if i < len(rows) else i) or i) for i in indices]
        blob = json.dumps(ids, separators=(",", ":"), ensure_ascii=False).encode()
        payload = {
            "num_samples": len(indices),
            "indices_sha256": hashlib.sha256(
                json.dumps(indices, separators=(",", ":")).encode()
            ).hexdigest(),
            "ids_sha256": hashlib.sha256(blob).hexdigest(),
            "first_indices": indices[:32],
            "first_ids": ids[:32],
        }
        output = os.path.abspath(output)
        os.makedirs(os.path.dirname(output), exist_ok=True)
        with open(output, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        self._sample_plan_written = True

    def create_optimizer(self):
        if is_sagemaker_mp_enabled():
            return super().create_optimizer()
        if self.optimizer is not None:
            return self.optimizer

        model = self.model
        decay_names = set(get_parameter_names(model, ALL_LAYERNORM_LAYERS))
        decay_names = {name for name in decay_names if "bias" not in name}

        learning_rates = []
        if self.args.mm_projector_lr is not None:
            learning_rates.append(("mm_projector", self.args.mm_projector_lr))
        if self.args.mm_vision_tower_lr is not None:
            learning_rates.append(("vision_tower", self.args.mm_vision_tower_lr))

        state_lr_text = os.environ.get("LLADA_GUI_STATE_PARAMETER_LR", "").strip()
        if state_lr_text:
            state_lr = float(state_lr_text)
            for suffix in (
                "state_embed.weight",
                "support_logit_bias",
                "support_logit_log_scale",
            ):
                learning_rates.append(
                    (f"gui_visual_action_diffusion_grounding.{suffix}", state_lr)
                )
        if self.args.screen_state_lr is not None:
            learning_rates.append(
                (
                    "gui_visual_action_diffusion_grounding",
                    self.args.screen_state_lr,
                )
            )

        named_parameters = [
            (name, parameter)
            for name, parameter in model.named_parameters()
            if parameter.requires_grad
        ]
        claimed = set()
        groups = []
        special_names = {
            name
            for name, _ in named_parameters
            if any(keyword in name for keyword, _ in learning_rates)
        }

        def add_groups(names, lr=None):
            for use_decay in (True, False):
                parameters = [
                    parameter
                    for name, parameter in named_parameters
                    if name in names and (name in decay_names) == use_decay
                ]
                if parameters:
                    group = {
                        "params": parameters,
                        "weight_decay": self.args.weight_decay if use_decay else 0.0,
                    }
                    if lr is not None:
                        group["lr"] = lr
                    groups.append(group)

        add_groups({name for name, _ in named_parameters if name not in special_names})
        for keyword, lr in learning_rates:
            names = {
                name
                for name, _ in named_parameters
                if keyword in name and name not in claimed
            }
            claimed.update(names)
            add_groups(names, lr)

        if not groups:
            raise RuntimeError("optimizer has no trainable parameter groups")
        optimizer_cls, optimizer_kwargs = Trainer.get_optimizer_cls_and_kwargs(self.args)
        self.optimizer = optimizer_cls(groups, **optimizer_kwargs)
        return self.optimizer
