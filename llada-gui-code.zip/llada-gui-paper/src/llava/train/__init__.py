"""Training components for LLaDA-GUI."""
