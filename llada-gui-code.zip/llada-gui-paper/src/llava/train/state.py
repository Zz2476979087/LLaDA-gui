"""Deterministic initialization contracts for the screen-state action field."""

from __future__ import annotations

import contextlib
import hashlib
import json
import os
from pathlib import Path

import torch

from llava.utils import rank0_print, rank_print


def _checkpoint_owns_action_field(model_path):
    config_path = Path(model_path) / "config.json"
    if not config_path.is_file():
        return False
    try:
        return bool(
            any(
                json.loads(config_path.read_text(encoding="utf-8")).get(key, False)
                for key in (
                    "screen_state_action_field_enabled",
                    "gui_unified_spatial_action_diffusion_enabled",
                    "gui_screen_state_action_field_enabled",
                    "gui_diffusion_grounding_enabled",
                )
            )
        )
    except (OSError, TypeError, ValueError):
        return False


def _copy_parameter(parameter, value):
    context = contextlib.nullcontext()
    try:
        import deepspeed

        if hasattr(parameter, "ds_id"):
            context = deepspeed.zero.GatheredParameters(
                [parameter], modifier_rank=0
            )
    except Exception:
        pass
    with context:
        if tuple(parameter.shape) != tuple(value.shape):
            return False
        parameter.data.copy_(value.to(parameter.device, parameter.dtype))
    return True


def initialize_action_field(model, model_path):
    """Apply the all-MASK initialization, then an optional state snapshot."""
    head = getattr(model, "screen_state_action_field", None)
    if head is None:
        raise RuntimeError("screen-state action field is missing")
    owns_head = _checkpoint_owns_action_field(model_path)
    if not owns_head:
        support_bias = float(
            os.environ.get("LLADA_GUI_TARGET_LOGIT_BIAS_INIT", "-1.5")
        )
        values = {
            "raw_visual_proj.weight": 0.0,
            "position_proj.2.weight": 0.0,
            "position_proj.2.bias": 0.0,
            "scale_embed.weight": 0.0,
            "state_embed.weight": 0.0,
            "visual_o.weight": 0.0,
            "visual_ffn.2.weight": 0.0,
            "visual_ffn.2.bias": 0.0,
            "offset_head.weight": 0.0,
            "offset_head.bias": 0.0,
            "support_logit_bias": support_bias,
            "support_logit_log_scale": 0.0,
        }
        parameters = dict(head.named_parameters())
        for name, scalar in values.items():
            parameter = parameters[name]
            shape = tuple(getattr(parameter, "ds_shape", parameter.shape))
            if not _copy_parameter(
                parameter, torch.full(shape, scalar, dtype=torch.float32)
            ):
                raise RuntimeError(f"failed to initialize {name}")
        rank0_print(
            f"Fresh action-field boundary initialized ({len(values)} tensors)"
        )

    snapshot_value = os.environ.get("LLADA_GUI_ACTION_FIELD_INIT_INPUT", "").strip()
    if snapshot_value:
        if owns_head:
            raise RuntimeError(
                "refusing to overwrite a checkpoint-owned unified action head"
            )
        snapshot_path = Path(snapshot_value).expanduser().resolve()
        from safetensors.torch import load_file

        state = load_file(str(snapshot_path), device="cpu")
        parameters = dict(head.named_parameters())
        if set(state) != set(parameters):
            raise RuntimeError(
                "unified head state keys differ: "
                f"missing={sorted(set(parameters) - set(state))}, "
                f"unexpected={sorted(set(state) - set(parameters))}"
            )
        for name, parameter in parameters.items():
            if not _copy_parameter(parameter, state[name]):
                raise RuntimeError(f"unified head state shape differs for {name}")
        rank0_print(
            f"Loaded action-field initialization: {snapshot_path}; tensors={len(state)}"
        )

    _report_fingerprint(head, model_path)
    _save_snapshot_if_requested(head)


def _parameter_cpu(parameter):
    if not hasattr(parameter, "ds_id"):
        return parameter.detach().cpu().clone()
    import deepspeed

    with deepspeed.zero.GatheredParameters([parameter]):
        return parameter.detach().cpu().clone()


def _fingerprint(head):
    digest = hashlib.sha256()
    count = 0
    for name, parameter in sorted(head.named_parameters()):
        value = _parameter_cpu(parameter).contiguous()
        raw = value.reshape(-1).view(torch.uint8).numpy().tobytes()
        shape = [int(size) for size in value.shape]
        digest.update(name.encode("utf-8"))
        digest.update(json.dumps(shape, separators=(",", ":")).encode("ascii"))
        digest.update(str(value.dtype).encode("ascii"))
        digest.update(raw)
        count += value.numel()
    return digest.hexdigest(), count


def _report_fingerprint(head, model_path):
    sha256, count = _fingerprint(head)
    rank = int(os.environ.get("RANK", os.environ.get("LOCAL_RANK", "0")))
    rank_print(
        f"Screen-state action-field fingerprint rank={rank} sha256={sha256} parameters={count}"
    )
    output = os.environ.get("LLADA_GUI_ACTION_FIELD_FINGERPRINT_OUTPUT", "").strip()
    if output:
        path = Path(output)
        path = path.with_name(f"{path.stem}.rank{rank}{path.suffix or '.json'}")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(
                {
                    "sha256": sha256,
                    "parameter_count": count,
                    "model_name_or_path": str(Path(model_path).resolve()),
                    "rank": rank,
                },
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )


def _save_snapshot_if_requested(head):
    output = os.environ.get("LLADA_GUI_ACTION_FIELD_INIT_OUTPUT", "").strip()
    if not output:
        return
    state = {
        name: _parameter_cpu(parameter).contiguous()
        for name, parameter in sorted(head.named_parameters())
    }
    if int(os.environ.get("RANK", os.environ.get("LOCAL_RANK", "0"))) != 0:
        return
    from safetensors.torch import save_file

    path = Path(output).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    save_file(state, str(path))
    rank0_print(f"Saved action-field initialization to {path}")
