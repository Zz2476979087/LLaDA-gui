"""Training entry point for LLaDA-GUI."""

from __future__ import annotations

import ast
import os
from pathlib import Path
import random
import re

import numpy as np
import torch
import transformers
from transformers import AutoConfig

from llava import conversation as conversation_lib
from llava.model.language_model.llava_llada import LlavaLLaDAModelLM
from llava.utils import rank0_print, rank_print
from .arguments import DataArguments, ModelArguments, TrainingArguments
from .data import make_supervised_data_module
from .state import initialize_action_field
from .trainer import LLaDAGUITrainer


# Released checkpoints use this internal module prefix. Public APIs and saved
# configuration use the paper-facing ``screen_state_action_field`` name.
_CHECKPOINT_ACTION_FIELD_PREFIX = "gui_visual_action_diffusion_grounding."


def _is_action_field_parameter(name):
    return name.startswith(_CHECKPOINT_ACTION_FIELD_PREFIX)


def _env_flag(name, default=False):
    value = os.environ.get(name)
    if not value:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def _seed_model_initialization(training_args):
    enabled = bool(
        training_args.seed_before_model_init
        or training_args.model_init_seed is not None
    )
    if _env_flag("LLADA_GUI_REQUIRE_MODEL_INIT_SEED") and not enabled:
        raise RuntimeError("a deterministic model-initialization seed is required")
    if not enabled:
        return
    seed = int(
        training_args.model_init_seed
        if training_args.model_init_seed is not None
        else training_args.seed
    )
    transformers.set_seed(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    rank_print(f"Seeded model initialization with {seed}")


def _load_model(model_args, training_args):
    if not model_args.vision_tower:
        raise ValueError("LLaDA-GUI requires --vision_tower")
    if "llada" not in model_args.model_name_or_path.lower():
        raise ValueError("the paper release supports only LLaDA-V")
    config = AutoConfig.from_pretrained(
        model_args.model_name_or_path, trust_remote_code=True
    )
    config.mm_vision_tower = model_args.vision_tower
    config.vision_tower = model_args.vision_tower
    model = LlavaLLaDAModelLM.from_pretrained(
        model_args.model_name_or_path,
        config=config,
        cache_dir=training_args.cache_dir,
        attn_implementation=training_args.attn_implementation,
        torch_dtype=torch.bfloat16 if training_args.bf16 else torch.float16,
        low_cpu_mem_usage=False,
    )
    initialize_action_field(model, model_args.model_name_or_path)
    model.config.use_cache = False
    return model


def _load_tokenizer(model_args, training_args):
    path = model_args.tokenizer_name_or_path or model_args.model_name_or_path
    tokenizer = transformers.AutoTokenizer.from_pretrained(
        path,
        cache_dir=training_args.cache_dir,
        model_max_length=training_args.model_max_length,
        padding_side="right",
        use_fast=False,
    )
    if tokenizer.unk_token is not None:
        tokenizer.pad_token = tokenizer.unk_token
    if model_args.version != "llava_llada":
        raise ValueError("LLaDA-GUI requires --version llava_llada")
    conversation_lib.default_conversation = conversation_lib.conv_templates[
        "llava_llada"
    ]
    return tokenizer


def _parse_grid_pinpoints(value, processor):
    if not isinstance(value, str):
        return value
    if "x" not in value:
        return ast.literal_eval(value)
    matches = re.findall(r"\((\d+)x(\d+)\)", value)
    if not matches:
        raise ValueError(f"invalid image_grid_pinpoints: {value}")
    start, end = tuple(map(int, matches[0])), tuple(map(int, matches[-1]))
    size = processor.size
    patch_size = size[0] if isinstance(size, (tuple, list)) else size["shortest_edge"]
    return [
        [row * patch_size, column * patch_size]
        for row in range(start[0], end[0] + 1)
        for column in range(start[1], end[1] + 1)
    ]


def _initialize_vision(model, tokenizer, model_args, data_args, training_args):
    model.get_model().initialize_vision_modules(
        model_args=model_args, fsdp=training_args.fsdp
    )
    tower = model.get_vision_tower()
    dtype = torch.bfloat16 if training_args.bf16 else torch.float16
    tower.to(dtype=dtype, device=training_args.device)
    data_args.image_processor = tower.image_processor
    data_args.is_multimodal = True
    data_args.mm_use_im_start_end = model_args.mm_use_im_start_end
    data_args.image_grid_pinpoints = _parse_grid_pinpoints(
        data_args.image_grid_pinpoints, tower.image_processor
    )

    config_values = {
        "image_aspect_ratio": data_args.image_aspect_ratio,
        "image_grid_pinpoints": data_args.image_grid_pinpoints,
        "image_crop_resolution": data_args.image_crop_resolution,
        "image_split_resolution": data_args.image_split_resolution,
        "tokenizer_padding_side": tokenizer.padding_side,
        "tokenizer_model_max_length": tokenizer.model_max_length,
        "mm_newline_position": model_args.mm_newline_position,
        "mm_use_im_start_end": model_args.mm_use_im_start_end,
        "mm_use_im_patch_token": model_args.mm_use_im_patch_token,
        "mm_projector_lr": training_args.mm_projector_lr,
        "mm_vision_tower_lr": training_args.mm_vision_tower_lr,
        "screen_state_lr": training_args.screen_state_lr,
        "mm_tunable_parts": model_args.mm_tunable_parts,
    }
    for name, value in config_values.items():
        setattr(model.config, name, value)
    training_args.mm_tunable_parts = model_args.mm_tunable_parts
    training_args.use_im_start_end = model_args.mm_use_im_start_end
    model.initialize_vision_tokenizer(model_args, tokenizer=tokenizer)
    return tower


def _configure_trainable_parameters(model, tower, model_args):
    parts = {part.strip() for part in model_args.mm_tunable_parts.split(",")}
    expected = {"mm_vision_tower", "mm_mlp_adapter", "mm_language_model"}
    if parts != expected:
        raise ValueError(f"mm_tunable_parts must be {sorted(expected)}")

    model.requires_grad_(False)
    tower.requires_grad_(True)
    model.get_model().mm_projector.requires_grad_(True)
    for name, parameter in model.named_parameters():
        if not any(
            marker in name
            for marker in ("vision_tower", "mm_projector", "vision_resampler")
        ):
            parameter.requires_grad_(True)

    head_only = _env_flag("LLADA_GUI_ACTION_FIELD_ONLY")
    if head_only:
        model.requires_grad_(False)
        for name, parameter in model.named_parameters():
            if _is_action_field_parameter(name):
                parameter.requires_grad_(True)

    trainable = [name for name, parameter in model.named_parameters() if parameter.requires_grad]
    if head_only and any(
        not _is_action_field_parameter(name) for name in trainable
    ):
        raise RuntimeError("warmup contains a non-grounding trainable parameter")
    if not trainable:
        raise RuntimeError("no trainable parameters")
    nonfinite = [
        name
        for name, parameter in model.named_parameters()
        if _is_action_field_parameter(name)
        and not torch.isfinite(parameter.detach()).all().item()
    ]
    if nonfinite:
        raise FloatingPointError(f"non-finite grounding parameters: {nonfinite}")
    rank0_print(
        f"Trainable parameters: {sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad):,}"
    )


def _safe_save(trainer, output_dir):
    trainer.accelerator.wait_for_everyone()
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    if trainer.deepspeed:
        trainer.save_model(output_dir)
        return
    state = trainer.model.state_dict()
    if trainer.args.should_save:
        trainer._save(
            output_dir,
            state_dict={name: value.cpu() for name, value in state.items()},
        )


def train(attn_implementation=None):
    parser = transformers.HfArgumentParser(
        (ModelArguments, DataArguments, TrainingArguments)
    )
    model_args, data_args, training_args = parser.parse_args_into_dataclasses()
    if training_args.lora_enable:
        raise ValueError("the released LLaDA-GUI recipe does not use LoRA")
    if training_args.use_conversation_mask:
        raise ValueError("LLaDA-GUI uses the screen-state mask, not conversation masking")

    _seed_model_initialization(training_args)
    model = _load_model(model_args, training_args)
    if _env_flag("LLADA_GUI_EXIT_AFTER_MODEL_INIT"):
        raise SystemExit(0)
    if training_args.gradient_checkpointing:
        model.enable_input_require_grads()

    tokenizer = _load_tokenizer(model_args, training_args)
    tower = _initialize_vision(
        model, tokenizer, model_args, data_args, training_args
    )
    _configure_trainable_parameters(model, tower, model_args)
    data_module = make_supervised_data_module(
        tokenizer, data_args, training_args
    )
    trainer = LLaDAGUITrainer(
        model=model,
        tokenizer=tokenizer,
        args=training_args,
        **data_module,
    )

    stop_value = os.environ.get("LLADA_GUI_STOP_AFTER_STEPS", "").strip()
    if stop_value:
        stop_step = int(stop_value)

        class StopCallback(transformers.TrainerCallback):
            def on_step_end(self, args, state, control, **kwargs):
                if state.global_step >= stop_step:
                    control.should_training_stop = True
                return control

        trainer.add_callback(StopCallback())

    checkpoints = list(Path(training_args.output_dir).glob("checkpoint-*"))
    trainer.train(resume_from_checkpoint=True if checkpoints else None)
    trainer.save_state()
    if _env_flag("LLADA_GUI_SKIP_FINAL_SAVE"):
        rank0_print("Smoke run completed; skipped final checkpoint save")
        return
    model.config.use_cache = True
    _safe_save(trainer, training_args.output_dir)
    rank0_print(f"Model saved to {training_args.output_dir}")


if __name__ == "__main__":
    train()
