"""Prompt-template selector for LLaDA-GUI."""

from dataclasses import dataclass


@dataclass(frozen=True)
class Conversation:
    version: str


conv_llava_llada = Conversation(version="llava_llada")
default_conversation = conv_llava_llada
conv_templates = {"llava_llada": conv_llava_llada}
