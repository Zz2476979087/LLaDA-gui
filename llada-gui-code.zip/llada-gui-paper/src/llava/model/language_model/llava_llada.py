#    Copyright 2023 Zebin You
#
#    Licensed under the Apache License, Version 2.0 (the "License");
#    you may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.


from typing import List, Optional, Tuple, Union

import torch
import torch.nn as nn

from transformers import AutoConfig, AutoModelForCausalLM

from transformers.modeling_outputs import CausalLMOutputWithPast

from llava.model.llava_arch import LlavaMetaModel, LlavaMetaForCausalLM
from llava.model.language_model.configuration_llada import LLaDAConfig
from llava.model.language_model.modeling_llada import LLaDAModel, LLaDAModelLM


class LlavaLLaDAConfig(LLaDAConfig):
    model_type = "llava_llada"      
    temperature: float = 0.0  # reset to 0.0, previously 0.9 for Vicuna
    max_new_tokens: int = 1024
    do_sample: bool = False
    top_p: Optional[float] = None
    # rope_scaling: Optional[dict] = {}


class LlavaLLaDAModel(LlavaMetaModel, LLaDAModel):
    config_class = LlavaLLaDAConfig

    def __init__(self, config: LLaDAConfig):
        super(LlavaLLaDAModel, self).__init__(config)


class LlavaLLaDAModelLM(LLaDAModelLM, LlavaMetaForCausalLM):
    config_class = LlavaLLaDAConfig

    def __init__(self, config):
        LLaDAModelLM.__init__(self, config)

        # configure default generation settings
        config.model_type = "llava_llada"
        # config.rope_scaling = None

        self.model = LlavaLLaDAModel(config)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)
        # Initialize weights and apply final processing
        self.post_init()
        if hasattr(self, "screen_state_action_field"):
            # The multimodal subclass runs post_init a second time. Restore the
            # grounding-specific gate/slot initialization after that global pass.
            self.screen_state_action_field.reset_parameters()

    def get_model(self):
        return self.model

    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[List[torch.FloatTensor]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        images: Optional[torch.FloatTensor] = None,
        image_sizes: Optional[List[List[int]]] = None,
        return_dict: Optional[bool] = None,
        modalities: Optional[List[str]] = None,
        cache_position=None,
        mdm_mask_positions: Optional[torch.LongTensor] = None,
        mdm_token_weights: Optional[torch.FloatTensor] = None,
        target_boxes_1000: Optional[torch.FloatTensor] = None,
        target_row_mask: Optional[torch.Tensor] = None,
        target_is_icon: Optional[torch.Tensor] = None,
        negative_boxes_1000: Optional[torch.FloatTensor] = None,
        negative_row_mask: Optional[torch.Tensor] = None,
        instruction_token_mask: Optional[torch.Tensor] = None,
        action_query_token_mask: Optional[torch.Tensor] = None,
        coordinate_token_mask: Optional[torch.Tensor] = None,
    ) -> Union[Tuple, CausalLMOutputWithPast]:

        modalities = modalities or ["image"]
        conversation_ids = None
        has_screen_state_controls = (
            mdm_token_weights is not None
            or mdm_mask_positions is not None
            or target_boxes_1000 is not None
            or target_row_mask is not None
            or target_is_icon is not None
            or negative_boxes_1000 is not None
            or negative_row_mask is not None
            or instruction_token_mask is not None
            or action_query_token_mask is not None
            or coordinate_token_mask is not None
        )
        if inputs_embeds is None and attention_mask is not None:
            prepared = self.prepare_inputs_labels_for_multimodal(
                input_ids,
                position_ids,
                attention_mask,
                past_key_values,
                labels,
                images,
                modalities,
                image_sizes,
                is_llada=True,
                mdm_token_weights=mdm_token_weights,
                mdm_mask_positions=mdm_mask_positions,
                target_boxes_1000=target_boxes_1000,
                target_row_mask=target_row_mask,
                target_is_icon=target_is_icon,
                negative_boxes_1000=negative_boxes_1000,
                negative_row_mask=negative_row_mask,
                instruction_token_mask=instruction_token_mask,
                action_query_token_mask=action_query_token_mask,
                coordinate_token_mask=coordinate_token_mask,
            )
            if has_screen_state_controls:
                (
                    input_ids,
                    position_ids,
                    attention_mask,
                    past_key_values,
                    inputs_embeds,
                    labels,
                    conversation_ids,
                    mdm_token_weights,
                    mdm_mask_positions,
                    _mdm_negative_labels,
                ) = prepared
            else:
                (input_ids, position_ids, attention_mask, past_key_values, inputs_embeds, labels, conversation_ids) = prepared
        elif inputs_embeds is None:
            prepared = self.prepare_inputs_labels_for_multimodal(
                input_ids,
                position_ids,
                attention_mask,
                past_key_values,
                labels,
                images,
                modalities,
                image_sizes,
                mdm_token_weights=mdm_token_weights,
                mdm_mask_positions=mdm_mask_positions,
                target_boxes_1000=target_boxes_1000,
                target_row_mask=target_row_mask,
                target_is_icon=target_is_icon,
                negative_boxes_1000=negative_boxes_1000,
                negative_row_mask=negative_row_mask,
                instruction_token_mask=instruction_token_mask,
                action_query_token_mask=action_query_token_mask,
                coordinate_token_mask=coordinate_token_mask,
            )
            if has_screen_state_controls:
                (
                    input_ids,
                    position_ids,
                    attention_mask,
                    past_key_values,
                    inputs_embeds,
                    labels,
                    mdm_token_weights,
                    mdm_mask_positions,
                    _mdm_negative_labels,
                ) = prepared
            else:
                (input_ids, position_ids, attention_mask, past_key_values, inputs_embeds, labels) = prepared
        return super().forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            labels=labels,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            conversation_ids=conversation_ids,
            mdm_mask_positions=mdm_mask_positions,
            mdm_token_weights=mdm_token_weights,
        )




AutoConfig.register("llava_llada", LlavaLLaDAConfig)
AutoModelForCausalLM.register(LlavaLLaDAConfig, LlavaLLaDAModelLM)
