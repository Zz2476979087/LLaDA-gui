from __future__ import annotations

import math
import os
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


class ScreenStateActionField(nn.Module):
    """Instruction-conditioned action field over a categorical screen state.

    The diffusion variables describe target-object support on the canonical
    high-resolution screen lattice.  Decimal coordinate digits are not
    diffusion variables: the final point is serialized once after the same
    semantic field has been denoised and decoded.

    The all-MASK field is the locator, not a disposable proposal module.  A
    partially denoised state can only condition that same field.  In
    particular, the MASK embedding is subtracted from every state embedding,
    making the all-MASK boundary exactly independent of the diffusion-state
    parameters.  The localization-first curriculum can therefore establish
    the all-MASK action field before optimizing state-conditioned recovery.
    """

    BACKGROUND = 0
    TARGET = 1
    MASK = 2
    POINTER_TEMPERATURE = 0.07
    DEFAULT_SUPPORT_LOGIT_BIAS = -1.5
    DEFAULT_TARGET_CLASS_BALANCE = 0.5
    MIN_DIFFUSION_TIME = 0.05
    VISUAL_BASIS = "contextual_and_fine_grained_screen_lattice"

    def __init__(
        self,
        hidden_size: int,
        grounding_dim: int = 256,
        num_heads: int = 8,
        dropout: float = 0.0,
        state_scale: Optional[float] = None,
        raw_residual_rms_limit: float = 0.25,
        raw_production_scale: float = 1.0,
    ) -> None:
        super().__init__()
        del dropout
        self.hidden_size = int(hidden_size)
        self.requested_grounding_dim = int(grounding_dim)
        # Grounding width is bounded by the language hidden size while keeping
        # the exact dimension recorded by a released checkpoint.
        self.grounding_dim = min(self.requested_grounding_dim, self.hidden_size)
        self.num_heads = max(1, min(int(num_heads), self.grounding_dim))
        while self.grounding_dim % self.num_heads != 0:
            self.num_heads -= 1
        configured_state_scale = (
            math.sqrt(float(self.grounding_dim))
            if state_scale is None
            else float(state_scale)
        )
        self.state_scale = float(
            os.environ.get(
                "LLADA_GUI_STATE_MIXER_SCALE",
                configured_state_scale,
            )
        )
        self.raw_residual_rms_limit = max(
            0.0, float(raw_residual_rms_limit)
        )
        # Fine-grained alignment can supervise the shared visual representation
        # without forcing its residual to alter the deployed action field.
        self.raw_production_scale = max(
            0.0, float(raw_production_scale)
        )

        # These local parameter names and shapes are checkpoint-stable.  They
        # implement the contextual feature stream used by the action energy.
        self.legacy_query_proj = nn.Linear(
            self.hidden_size, self.grounding_dim, bias=False
        )
        self.legacy_visual_proj = nn.Linear(
            self.hidden_size, self.grounding_dim, bias=False
        )
        self.legacy_query_norm = nn.LayerNorm(self.grounding_dim)
        self.legacy_visual_norm = nn.LayerNorm(self.grounding_dim)

        # Raw icon appearance, spatial state and geometry enter before the one
        # and only action energy is formed.
        self.raw_visual_proj = nn.Linear(
            self.hidden_size, self.grounding_dim, bias=False
        )
        self.raw_visual_norm = nn.LayerNorm(self.grounding_dim)
        self.position_proj = nn.Sequential(
            nn.Linear(10, self.grounding_dim),
            nn.GELU(),
            nn.Linear(self.grounding_dim, self.grounding_dim),
        )
        self.scale_embed = nn.Embedding(2, self.grounding_dim)
        self.state_embed = nn.Embedding(3, self.grounding_dim)

        self.visual_pre_norm = nn.LayerNorm(self.grounding_dim)
        self.visual_q = nn.Linear(
            self.grounding_dim, self.grounding_dim, bias=False
        )
        self.visual_k = nn.Linear(
            self.grounding_dim, self.grounding_dim, bias=False
        )
        self.visual_v = nn.Linear(
            self.grounding_dim, self.grounding_dim, bias=False
        )
        self.visual_o = nn.Linear(
            self.grounding_dim, self.grounding_dim, bias=False
        )
        self.visual_ffn_norm = nn.LayerNorm(self.grounding_dim)
        self.visual_ffn = nn.Sequential(
            nn.Linear(self.grounding_dim, self.grounding_dim * 4),
            nn.GELU(),
            nn.Linear(self.grounding_dim * 4, self.grounding_dim),
        )

        # The support probability uses the same scalar energy and therefore
        # cannot create a second patch ranking.
        self.support_logit_bias = nn.Parameter(
            torch.tensor(self.DEFAULT_SUPPORT_LOGIT_BIAS)
        )
        self.support_logit_log_scale = nn.Parameter(torch.tensor(0.0))

        # Sub-cell precision is predicted from the same state-conditioned
        # visual representation and semantic query.
        self.offset_query_proj = nn.Linear(
            self.grounding_dim, self.grounding_dim, bias=False
        )
        self.offset_head = nn.Linear(self.grounding_dim, 2)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        for module in (self.legacy_query_proj, self.legacy_visual_proj):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
        for module in (self.legacy_query_norm, self.legacy_visual_norm):
            nn.init.ones_(module.weight)
            nn.init.zeros_(module.bias)
        self.reset_extension_parameters()

    def reset_extension_parameters(self) -> None:
        for module in (
            self.visual_q,
            self.visual_k,
            self.visual_v,
            self.offset_query_proj,
        ):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
        for module in (
            self.raw_visual_norm,
            self.visual_pre_norm,
            self.visual_ffn_norm,
        ):
            nn.init.ones_(module.weight)
            nn.init.zeros_(module.bias)
        for module in (self.position_proj[0], self.visual_ffn[0]):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            nn.init.zeros_(module.bias)

        # A fresh/tied run starts at the exact proven contextual action field.
        # Raw alignment, geometry, state mixing and offsets receive gradients
        # immediately but cannot perturb that boundary before training.
        nn.init.zeros_(self.raw_visual_proj.weight)
        nn.init.zeros_(self.position_proj[-1].weight)
        nn.init.zeros_(self.position_proj[-1].bias)
        nn.init.zeros_(self.scale_embed.weight)
        nn.init.zeros_(self.state_embed.weight)
        nn.init.zeros_(self.visual_o.weight)
        nn.init.zeros_(self.visual_ffn[-1].weight)
        nn.init.zeros_(self.visual_ffn[-1].bias)
        nn.init.zeros_(self.offset_head.weight)
        nn.init.zeros_(self.offset_head.bias)
        with torch.no_grad():
            self.support_logit_bias.fill_(
                float(
                    os.environ.get(
                        "LLADA_GUI_TARGET_LOGIT_BIAS_INIT",
                        self.DEFAULT_SUPPORT_LOGIT_BIAS,
                    )
                )
            )

    @staticmethod
    def position_features(centers_1000: torch.Tensor) -> torch.Tensor:
        xy = centers_1000.float().clamp(0.0, 1000.0) / 1000.0
        x, y = xy.unbind(dim=-1)
        pi = math.pi
        return torch.stack(
            (
                x,
                y,
                x * y,
                x.square(),
                y.square(),
                torch.sin(pi * x),
                torch.cos(pi * x),
                torch.sin(pi * y),
                torch.cos(pi * y),
                torch.ones_like(x),
            ),
            dim=-1,
        )

    @staticmethod
    def field_indices(
        patch_count: int, base_length: int, device: torch.device
    ) -> torch.Tensor:
        count = int(patch_count)
        start = min(max(int(base_length), 0), count)
        if start >= count:
            start = 0
        return torch.arange(start, count, device=device, dtype=torch.long)

    @classmethod
    def sample_forward(
        cls,
        clean_state: torch.Tensor,
        t: Optional[torch.Tensor] = None,
        *,
        generator: Optional[torch.Generator] = None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        if t is None:
            t = torch.rand(
                (), device=clean_state.device, dtype=torch.float32, generator=generator
            )
        # Four-step spatial sampling never visits an infinitesimal-noise
        # regime.  Training on t -> 0 only adds rare 1/t gradient spikes and
        # does not teach a state used by inference.
        t = t.to(device=clean_state.device, dtype=torch.float32).clamp(
            cls.MIN_DIFFUSION_TIME, 1.0
        )
        masked = torch.rand(
            clean_state.shape,
            device=clean_state.device,
            generator=generator,
        ).lt(t)
        noisy = torch.where(masked, torch.full_like(clean_state, cls.MASK), clean_state)
        return noisy, masked, t

    @staticmethod
    def _frozen_layer_norm(
        value: torch.Tensor, module: nn.LayerNorm
    ) -> torch.Tensor:
        return F.layer_norm(
            value,
            module.normalized_shape,
            module.weight.detach() if module.weight is not None else None,
            module.bias.detach() if module.bias is not None else None,
            module.eps,
        )

    @staticmethod
    def _frozen_linear(value: torch.Tensor, module: nn.Linear) -> torch.Tensor:
        return F.linear(
            value,
            module.weight.detach(),
            module.bias.detach() if module.bias is not None else None,
        )

    def _self_mix(
        self, visual: torch.Tensor, *, frozen_parameters: bool = False
    ) -> torch.Tensor:
        normalized = (
            self._frozen_layer_norm(visual, self.visual_pre_norm)
            if frozen_parameters
            else self.visual_pre_norm(visual)
        )
        heads = self.num_heads
        head_dim = self.grounding_dim // heads

        def split(value: torch.Tensor) -> torch.Tensor:
            return value.reshape(value.shape[0], heads, head_dim).transpose(0, 1)

        project = self._frozen_linear if frozen_parameters else lambda x, m: m(x)
        query = split(project(normalized, self.visual_q)).unsqueeze(0)
        key = split(project(normalized, self.visual_k)).unsqueeze(0)
        value = split(project(normalized, self.visual_v)).unsqueeze(0)
        attended = F.scaled_dot_product_attention(
            query, key, value, dropout_p=0.0
        )
        attended = (
            attended.squeeze(0)
            .transpose(0, 1)
            .reshape(visual.shape[0], self.grounding_dim)
        )
        visual = visual + project(attended, self.visual_o)
        if not frozen_parameters:
            return visual + self.visual_ffn(self.visual_ffn_norm(visual))
        normalized_ffn = self._frozen_layer_norm(
            visual, self.visual_ffn_norm
        )
        hidden = F.gelu(
            self._frozen_linear(normalized_ffn, self.visual_ffn[0])
        )
        return visual + self._frozen_linear(hidden, self.visual_ffn[2])

    @staticmethod
    def _offset_limits(centers_1000: torch.Tensor) -> torch.Tensor:
        # Ten normalized pixels were verified to make every ScreenSpot icon,
        # including every tiny icon, reachable from an overlapping high-res
        # patch.  It is small enough to remain a sub-cell correction.
        return torch.full(
            (centers_1000.shape[0], 2),
            10.0,
            device=centers_1000.device,
            dtype=torch.float32,
        )

    def compute_action_field(
        self,
        *,
        query_hidden: torch.Tensor,
        visual_hidden: torch.Tensor,
        visual_raw_hidden: Optional[torch.Tensor],
        visual_centers_1000: torch.Tensor,
        base_length: int,
        noisy_state: Optional[torch.Tensor] = None,
        isolate_state_gradient: bool = False,
    ) -> dict[str, torch.Tensor]:
        if query_hidden.numel() == 0 or visual_hidden.numel() == 0:
            raise ValueError("unified spatial action diffusion needs query and visual states")
        if visual_hidden.shape[0] != visual_centers_1000.shape[0]:
            raise ValueError("visual states and visual centres must align")
        indices = self.field_indices(
            visual_hidden.shape[0], base_length, visual_hidden.device
        )
        if noisy_state is None:
            noisy_state = torch.full(
                (indices.numel(),),
                self.MASK,
                device=visual_hidden.device,
                dtype=torch.long,
            )
        noisy_state = noisy_state.to(
            device=visual_hidden.device, dtype=torch.long
        ).reshape(-1)
        if noisy_state.numel() != indices.numel():
            raise ValueError("spatial diffusion state and high-resolution field must align")

        query = self.legacy_query_norm(self.legacy_query_proj(query_hidden))
        contextual = self.legacy_visual_norm(
            self.legacy_visual_proj(visual_hidden)
        )
        if visual_raw_hidden is None:
            raise ValueError("raw-aligned spatial field requires raw visual states")
        if visual_raw_hidden.shape != visual_hidden.shape:
            raise ValueError("raw and contextual visual states must align")
        # A bounded fine-grained representation prevents feature magnitude from
        # dominating the cosine action energy on long visual sequences.
        (
            raw,
            _raw_aligned,
            raw_projected_rms,
            raw_alignment_mixed_rms,
        ) = self._mixed_raw_features(
            visual_raw_hidden,
            frozen_parameters=bool(isolate_state_gradient),
        )
        position = self.position_proj(
            self.position_features(visual_centers_1000).to(dtype=contextual.dtype)
        )
        scale_ids = torch.ones(
            visual_hidden.shape[0], device=visual_hidden.device, dtype=torch.long
        )
        scale_ids[: min(max(int(base_length), 0), visual_hidden.shape[0])] = 0
        state = torch.zeros_like(contextual)
        # Use relative state embeddings.  An all-MASK field receives exactly
        # zero state residual even after state_embed has been trained.
        relative_state = self.state_embed(noisy_state) - self.state_embed(
            torch.full_like(noisy_state, self.MASK)
        )
        state.index_copy_(
            0,
            indices,
            (
                relative_state
                * self.state_scale
            ).to(dtype=contextual.dtype),
        )
        scale = self.scale_embed(scale_ids)
        if isolate_state_gradient:
            # Auxiliary denoising must learn the spatial state residual without
            # rewriting the proven all-MASK locator.  Values are numerically
            # identical to the shared modules used at inference; only their
            # auxiliary gradients are frozen.
            query = query.detach()
            contextual = contextual.detach()
            raw = raw.detach()
            position = position.detach()
            scale = scale.detach()
        visual = contextual + raw + position + scale + state

        normalized_query = F.normalize(query.float(), dim=-1)
        normalized_visual = F.normalize(visual.float(), dim=-1)
        per_query_full = torch.matmul(
            normalized_query, normalized_visual.transpose(0, 1)
        ) / float(self.POINTER_TEMPERATURE)
        full_logits = torch.logsumexp(per_query_full, dim=0)
        full_logits = full_logits - math.log(max(int(per_query_full.shape[0]), 1))
        logits = full_logits.index_select(0, indices)
        per_query_logits = per_query_full.index_select(1, indices)
        field_visual = visual.index_select(0, indices)
        field_centers = visual_centers_1000.index_select(0, indices).float()

        pooled_query = normalized_query.mean(dim=0, keepdim=True).to(
            dtype=field_visual.dtype
        )
        offset_features = field_visual + self.offset_query_proj(
            field_visual * pooled_query.expand_as(field_visual)
        )
        limits = self._offset_limits(field_centers)
        offsets = torch.tanh(self.offset_head(offset_features).float()) * limits
        predicted_points = (field_centers + offsets).clamp(0.0, 1000.0)
        # The same scalar action energy serves two roles without creating a
        # second ranking: softmax(logits) locates the object, while a
        # per-screen log-mean-exp centering turns that energy into calibrated
        # TARGET-vs-BACKGROUND x0 logits for categorical mask diffusion.
        # Centering removes the arbitrary absolute cosine offset that differed
        # strongly between text and icon instructions.
        log_mean_exp = (
            torch.logsumexp(logits.float(), dim=-1)
            - math.log(max(int(logits.numel()), 1))
        )
        centered_energy = logits.float() - log_mean_exp
        # The all-MASK x0/support objective is genuine visual localization
        # supervision and must be allowed to shape the locator.  Only noisy
        # and self-conditioned auxiliary views isolate the already learned
        # locator parameters (above); their gradients still reach the state
        # residual through ``centered_energy``. Detaching this source would
        # remove dense Target/Background supervision from the all-MASK field.
        support_source = centered_energy
        support_scale = self.support_logit_log_scale.float().clamp(
            -4.0, 4.0
        ).exp()
        support_logits = (
            support_source * support_scale + self.support_logit_bias.float()
        )
        return {
            "logits": logits,
            "per_query_logits": per_query_logits,
            "full_logits": full_logits,
            "support_logits": support_logits,
            "support_probabilities": torch.sigmoid(support_logits),
            "support_logit_scale": support_scale,
            "field_indices": indices,
            "field_centers_1000": field_centers,
            "field_visual_states": field_visual,
            "offset_limits_1000": limits,
            "offsets_1000": offsets,
            "predicted_points_1000": predicted_points,
            "query_states": normalized_query,
            "visual_basis": self.VISUAL_BASIS,
            "contextual_primary_rms": contextual.float().square().mean().sqrt(),
            "raw_residual_rms": raw.float().square().mean().sqrt(),
            "raw_projected_rms": raw_projected_rms,
            "raw_alignment_mixed_rms": raw_alignment_mixed_rms,
            "raw_residual_rms_limit": raw.new_tensor(
                float(self.raw_residual_rms_limit)
            ),
            "raw_production_scale": raw.new_tensor(
                float(self.raw_production_scale)
            ),
        }

    def _bounded_raw_direction(
        self, visual_raw_hidden: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Project raw patches to the shared semantic field without norm races.

        Dividing by ``max(||r||_2, sqrt(d))`` gives every patch a vector with
        L2 norm at most one.  Unlike LayerNorm/F.normalize at an exactly zero
        bootstrap, its first derivative is finite (1/sqrt(d)); unlike an
        unnormalised dot product, its logits and gradients cannot grow by
        increasing feature magnitude.
        """

        raw_projected = (
            self.raw_visual_proj(visual_raw_hidden)
            * self.raw_visual_norm.weight
            + self.raw_visual_norm.bias
        )
        raw_norm = torch.linalg.vector_norm(
            raw_projected.float(), dim=-1, keepdim=True
        )
        denominator = raw_norm.clamp_min(
            math.sqrt(float(self.grounding_dim))
        )
        direction = raw_projected.float() / denominator
        return (
            direction.to(dtype=raw_projected.dtype),
            raw_projected.float().square().mean().sqrt(),
        )

    def _mixed_raw_features(
        self,
        visual_raw_hidden: torch.Tensor,
        *,
        frozen_parameters: bool = False,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """Return production and alignment views of one mixed raw feature.

        The contextual heatmap is already a useful semantic action field.
        Self-attention therefore belongs inside the fine-grained residual:
        it may discover and relate icon patches, while its bounded output can
        only correct the contextual field and cannot remap it.

        The same function is used by training-only context-MASK alignment and
        by production inference.  This remains one action field and one final
        ranking, rather than a proposal/verifier or a second prediction head.
        """

        raw_seed_direction, raw_projected_rms = self._bounded_raw_direction(
            visual_raw_hidden
        )
        raw_seed = raw_seed_direction * (
            math.sqrt(float(self.grounding_dim))
            * float(self.raw_residual_rms_limit)
        )
        raw_mixed = self._self_mix(
            raw_seed, frozen_parameters=bool(frozen_parameters)
        )
        raw_mixed_norm = torch.linalg.vector_norm(
            raw_mixed.float(), dim=-1, keepdim=True
        )
        alignment_direction = (
            raw_mixed.float() / raw_mixed_norm.clamp_min(1.0)
        )
        limit = float(self.raw_residual_rms_limit)
        if limit <= 0.0:
            production_residual = torch.zeros_like(raw_mixed)
        else:
            # Bound the mixed residual itself, rather than normalising it and
            # multiplying by sqrt(d)*limit a second time.  The latter has the
            # same maximum RMS but amplifies the derivative at the exact zero
            # bootstrap by sqrt(d)*limit (5.66 at d=512, limit=0.25), making
            # global clipping discard contextual gradients on the first
            # updates.  This form is identity below the limit and therefore
            # preserves a finite derivative at the zero initialization point.
            token_rms = raw_mixed_norm / math.sqrt(
                float(self.grounding_dim)
            )
            production_residual = raw_mixed.float() / torch.maximum(
                torch.ones_like(token_rms), token_rms / limit
            )
        production_residual = (
            production_residual * float(self.raw_production_scale)
        )
        return (
            production_residual.to(dtype=raw_mixed.dtype),
            alignment_direction.to(dtype=raw_mixed.dtype),
            raw_projected_rms,
            raw_mixed.float().square().mean().sqrt(),
        )

    def compute_fine_grained_alignment(
        self,
        *,
        query_hidden: torch.Tensor,
        visual_raw_hidden: torch.Tensor,
        base_length: int,
    ) -> dict[str, torch.Tensor]:
        """Compute the fine-grained feature-alignment view used by training.

        This is not a second inference head.  It is the production action
        field under a structured context corruption: the proven contextual
        stream is MASKed, while the same raw projection and raw visual mixer
        used by production must reconstruct the bbox heat target.  The query
        path is frozen
        only for this auxiliary gradient.  Finite
        ``max(||r||, sqrt(d))`` bounds remain differentiable at the zero
        bootstrap and prevent the projection-norm race of the unbounded view.
        """

        if query_hidden.numel() == 0 or visual_raw_hidden.numel() == 0:
            raise ValueError("raw alignment needs query and raw visual states")
        indices = self.field_indices(
            visual_raw_hidden.shape[0], base_length, visual_raw_hidden.device
        )
        query = self.legacy_query_norm(
            self.legacy_query_proj(query_hidden)
        ).detach()
        (
            _raw_production,
            raw_aligned,
            raw_projected_rms,
            raw_alignment_mixed_rms,
        ) = self._mixed_raw_features(
            visual_raw_hidden
        )
        normalized_query = F.normalize(query.float(), dim=-1)
        per_query_full = torch.matmul(
            normalized_query, raw_aligned.float().transpose(0, 1)
        ) / float(self.POINTER_TEMPERATURE)
        full_logits = torch.logsumexp(per_query_full, dim=0)
        full_logits = full_logits - math.log(max(int(per_query_full.shape[0]), 1))
        return {
            "logits": full_logits.index_select(0, indices),
            "per_query_logits": per_query_full.index_select(1, indices),
            "field_indices": indices,
            "raw_aligned_rms": raw_aligned.float().square().mean().sqrt(),
            "raw_projected_rms": raw_projected_rms,
            "raw_alignment_mixed_rms": raw_alignment_mixed_rms,
        }

    @staticmethod
    def target_point(target_box_1000: torch.Tensor) -> torch.Tensor:
        box = target_box_1000.float().reshape(-1)[:4]
        if box.numel() != 4:
            raise ValueError("target box must contain x1, y1, x2 and y2")
        x1, x2 = torch.minimum(box[0], box[2]), torch.maximum(box[0], box[2])
        y1, y2 = torch.minimum(box[1], box[3]), torch.maximum(box[1], box[3])
        return torch.stack(((x1 + x2) * 0.5, (y1 + y2) * 0.5))

    @classmethod
    def build_target_distribution(
        cls,
        object_distribution: torch.Tensor,
        centers_1000: torch.Tensor,
        target_box_1000: torch.Tensor,
        *,
        is_icon: bool,
    ) -> torch.Tensor:
        del cls, is_icon
        support = object_distribution.float().clamp_min(0.0)
        support_mask = support.gt(0)
        if not torch.any(support_mask):
            raise ValueError("action target has no overlapping visual patch")
        box = target_box_1000.float().reshape(-1)[:4]
        x1, x2 = torch.minimum(box[0], box[2]), torch.maximum(box[0], box[2])
        y1, y2 = torch.minimum(box[1], box[3]), torch.maximum(box[1], box[3])
        centers = centers_1000.float()
        point_valid = (
            support_mask
            & centers[:, 0].ge(x1)
            & centers[:, 0].le(x2)
            & centers[:, 1].ge(y1)
            & centers[:, 1].le(y2)
        )
        # Box-overlap labels define target support. Whenever an overlapping
        # patch centre is itself a valid click, we do
        # not supervise neighbouring outside-box centres as interchangeable.
        # Very tiny controls can lie between all patch centres; those rows keep
        # the complete overlap component so its weighted geometric centre is
        # still usable without a learned offset.
        effective = point_valid if torch.any(point_valid) else support_mask
        target = support * effective.to(dtype=support.dtype)
        return target / target.sum().clamp_min(1e-12)

    def compute_objective(
        self,
        *,
        query_hidden: torch.Tensor,
        visual_hidden: torch.Tensor,
        visual_raw_hidden: Optional[torch.Tensor],
        visual_centers_1000: torch.Tensor,
        base_length: int,
        object_distribution: torch.Tensor,
        explicit_negative_distribution: Optional[torch.Tensor] = None,
        target_box_1000: torch.Tensor,
        is_icon: bool,
        diffusion_t: Optional[torch.Tensor] = None,
        diffusion_weight: float = 1.0,
        support_dice_weight: float = 0.0,
        ranking_weight: float = 0.5,
        ranking_margin: float = 0.5,
        offset_weight: float = 1.0,
        counterfactual_weight: float = 1.0,
        counterfactual_margin: float = 0.5,
        action_query_count: int = 0,
        target_class_balance: float = DEFAULT_TARGET_CLASS_BALANCE,
        monotonic_weight: float = 1.0,
        monotonic_margin: float = 0.01,
        raw_alignment_weight: float = 0.5,
    ) -> dict[str, torch.Tensor]:
        indices = self.field_indices(
            visual_hidden.shape[0], base_length, visual_hidden.device
        )
        field_object = object_distribution.index_select(0, indices).float()
        field_centers = visual_centers_1000.index_select(0, indices).float()
        heat_target = self.build_target_distribution(
            field_object,
            field_centers,
            target_box_1000,
            is_icon=bool(is_icon),
        )
        clean_state = heat_target.gt(0).long()
        all_mask_state = torch.full_like(clean_state, self.MASK)
        discovery = self.compute_action_field(
            query_hidden=query_hidden,
            visual_hidden=visual_hidden,
            visual_raw_hidden=visual_raw_hidden,
            visual_centers_1000=visual_centers_1000,
            base_length=base_length,
            noisy_state=all_mask_state,
        )
        force_all_mask = bool(
            diffusion_t is not None
            and float(diffusion_t.detach().float().item()) >= 1.0 - 1e-6
        )
        no_seed_boundary = False
        if force_all_mask:
            noisy_state = all_mask_state
            masked = torch.ones_like(clean_state, dtype=torch.bool)
            t = clean_state.new_ones((), dtype=torch.float32)
            denoised = discovery
        else:
            noisy_state, masked, t = self.sample_forward(
                clean_state, diffusion_t
            )
            denoised = self.compute_action_field(
                query_hidden=query_hidden,
                visual_hidden=visual_hidden,
                visual_raw_hidden=visual_raw_hidden,
                visual_centers_1000=visual_centers_1000,
                base_length=base_length,
                noisy_state=noisy_state,
                isolate_state_gradient=True,
            )

        # Match the inference boundary with the same shared field.  This is
        # self-conditioning, not a verifier: the clean state is the denoiser's
        # detached categorical x0 prediction and the exact same parameters are
        # run once more.  No ground-truth support enters this state.
        if force_all_mask:
            predicted_clean_state = all_mask_state
            boundary = discovery
        else:
            predicted_clean_state = torch.where(
                denoised["support_probabilities"].detach().ge(0.5),
                torch.full_like(clean_state, self.TARGET),
                torch.full_like(clean_state, self.BACKGROUND),
            )
            boundary = self.compute_action_field(
                query_hidden=query_hidden,
                visual_hidden=visual_hidden,
                visual_raw_hidden=visual_raw_hidden,
                visual_centers_1000=visual_centers_1000,
                base_length=base_length,
                noisy_state=predicted_clean_state,
                isolate_state_gradient=True,
            )

        zero = discovery["logits"].sum() * 0.0
        all_sites = torch.ones_like(clean_state, dtype=torch.bool)
        action_query_count = min(
            max(int(action_query_count), 0),
            int(discovery["per_query_logits"].shape[0]),
        )

        def spatial_kl(
            field: dict[str, torch.Tensor], active: torch.Tensor
        ) -> tuple[torch.Tensor, torch.Tensor]:
            local_target = heat_target * active.float()
            local_mass = local_target.sum()
            if local_mass <= 0 or not torch.any(active):
                return zero, local_target
            local_target = local_target / local_mass
            return (
                F.kl_div(
                    F.log_softmax(field["logits"][active].float(), dim=-1),
                    local_target[active],
                    reduction="sum",
                ),
                local_target,
            )

        discovery_heat_loss, _ = spatial_kl(discovery, all_sites)
        raw_alignment = None
        raw_alignment_heat_loss = zero
        raw_alignment_aggregate_loss = zero
        raw_alignment_per_query_loss = zero
        raw_action_query_count = 0
        if float(raw_alignment_weight) > 0.0:
            if visual_raw_hidden is None:
                raise ValueError("raw alignment loss requires raw visual states")
            raw_alignment = self.compute_fine_grained_alignment(
                query_hidden=query_hidden,
                visual_raw_hidden=visual_raw_hidden,
                base_length=base_length,
            )
            raw_alignment_aggregate_loss, _ = spatial_kl(
                raw_alignment, all_sites
            )
            # Each action query is aligned with the target map. Applying KL only
            # after aggregation would let one query compensate for the others
            # and weaken the fine-grained visual representation.
            raw_action_query_count = min(
                action_query_count,
                int(raw_alignment["per_query_logits"].shape[0]),
            )
            if raw_action_query_count > 0:
                raw_alignment_per_query_loss = F.kl_div(
                    F.log_softmax(
                        raw_alignment["per_query_logits"][
                            :raw_action_query_count
                        ].float(),
                        dim=-1,
                    ),
                    heat_target.unsqueeze(0).expand(
                        raw_action_query_count, -1
                    ),
                    reduction="sum",
                ) / float(raw_action_query_count)
                raw_alignment_heat_loss = raw_alignment_per_query_loss
            else:
                raw_alignment_heat_loss = raw_alignment_aggregate_loss
        if force_all_mask:
            denoise_heat_loss = zero
            masked_heat_target = heat_target
        else:
            # Action-map normalization and hard-negative ranking must use the
            # same full spatial domain in discovery, denoising and inference.
            denoise_heat_loss, masked_heat_target = spatial_kl(
                denoised, all_sites
            )
        boundary_heat_loss = (
            zero if force_all_mask else spatial_kl(boundary, all_sites)[0]
        )
        heat_loss = (
            discovery_heat_loss
            + 0.5 * denoise_heat_loss
            + 0.5 * boundary_heat_loss
        )

        query_map_loss = zero
        if action_query_count > 0:
            query_map_loss = F.kl_div(
                F.log_softmax(
                    discovery["per_query_logits"][:action_query_count].float(),
                    dim=-1,
                ),
                heat_target.unsqueeze(0).expand(action_query_count, -1),
                reduction="sum",
            ) / float(max(action_query_count, 1))

        target_balance = min(max(float(target_class_balance), 0.05), 0.95)

        def spatial_x0_loss(
            field: dict[str, torch.Tensor],
            active: torch.Tensor,
            inverse_t: torch.Tensor,
        ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
            per_site = F.binary_cross_entropy_with_logits(
                field["support_logits"].float(),
                clean_state.float(),
                reduction="none",
            )
            positive = active & clean_state.eq(self.TARGET)
            negative = active & clean_state.eq(self.BACKGROUND)
            positive_mean = (
                per_site[positive].mean() if torch.any(positive) else zero
            )
            negative_mean = (
                per_site[negative].mean() if torch.any(negative) else zero
            )
            # Class means remove bbox-area bias.  A balanced default gives the
            # p(TARGET)=0.5 inference boundary the same meaning for a tiny icon
            # and a large text box.
            combined = (
                target_balance * positive_mean
                + (1.0 - target_balance) * negative_mean
            ) / inverse_t.clamp_min(1e-3)
            return combined, positive_mean, negative_mean

        discovery_diffusion, discovery_target_diffusion, discovery_background_diffusion = (
            spatial_x0_loss(
                discovery,
                all_sites,
                clean_state.new_ones((), dtype=torch.float32),
            )
        )
        if force_all_mask:
            denoise_diffusion = zero
            denoise_target_diffusion = zero
            denoise_background_diffusion = zero
        else:
            (
                denoise_diffusion,
                denoise_target_diffusion,
                denoise_background_diffusion,
            ) = spatial_x0_loss(denoised, masked, t)
        if force_all_mask:
            boundary_diffusion = zero
            boundary_target_diffusion = zero
            boundary_background_diffusion = zero
        else:
            (
                boundary_diffusion,
                boundary_target_diffusion,
                boundary_background_diffusion,
            ) = spatial_x0_loss(
                boundary,
                all_sites,
                clean_state.new_ones((), dtype=torch.float32),
            )
        diffusion_loss = (
            discovery_diffusion
            + denoise_diffusion
            + 0.5 * boundary_diffusion
        )
        target_diffusion = (
            discovery_target_diffusion
            + denoise_target_diffusion
            + 0.5 * boundary_target_diffusion
        )
        background_diffusion = (
            discovery_background_diffusion
            + denoise_background_diffusion
            + 0.5 * boundary_background_diffusion
        )

        def dice_loss(
            field: dict[str, torch.Tensor], active: torch.Tensor
        ) -> torch.Tensor:
            probabilities = field["support_probabilities"][active].float()
            truth = clean_state[active].float()
            if probabilities.numel() == 0:
                return zero
            overlap = torch.sum(probabilities * truth)
            return 1.0 - (2.0 * overlap + 1.0) / (
                probabilities.sum() + truth.sum() + 1.0
            )

        support_dice_loss = dice_loss(discovery, all_sites)
        if not force_all_mask:
            support_dice_loss = (
                support_dice_loss
                + 0.5 * dice_loss(denoised, all_sites)
                + 0.5 * dice_loss(boundary, all_sites)
            )

        def object_rank_loss(
            field: dict[str, torch.Tensor], active: torch.Tensor
        ) -> tuple[torch.Tensor, torch.Tensor]:
            positive = active & clean_state.eq(self.TARGET)
            negative = active & clean_state.eq(self.BACKGROUND)
            if not torch.any(positive) or not torch.any(negative):
                return zero, zero
            positive_score = torch.logsumexp(
                field["logits"][positive], dim=0
            ) - math.log(max(int(positive.sum().item()), 1))
            hard_k = min(32, int(negative.sum().item()))
            negative_score = torch.logsumexp(
                torch.topk(field["logits"][negative], k=hard_k).values,
                dim=0,
            ) - math.log(max(hard_k, 1))
            gap = positive_score - negative_score
            return F.softplus(-gap + float(ranking_margin)), gap

        discovery_rank_loss, discovery_gap = object_rank_loss(
            discovery, all_sites
        )
        if force_all_mask:
            denoise_rank_loss, denoise_gap = zero, discovery_gap
        else:
            denoise_rank_loss, denoise_gap = object_rank_loss(
                denoised, all_sites
            )
        if force_all_mask:
            boundary_rank_loss, boundary_gap = zero, discovery_gap
        else:
            boundary_rank_loss, boundary_gap = object_rank_loss(
                boundary, all_sites
            )
        ranking_loss = (
            discovery_rank_loss
            + 0.5 * denoise_rank_loss
            + 0.5 * boundary_rank_loss
        )
        monotonic_loss = zero
        if not force_all_mask and torch.isfinite(boundary_gap):
            reference_gap = torch.maximum(
                discovery_gap.detach(), denoise_gap.detach()
            )
            monotonic_loss = F.relu(
                reference_gap
                + float(monotonic_margin)
                - boundary_gap
            )

        counterfactual_loss = zero
        counterfactual_rank_loss = zero
        counterfactual_support_loss = zero
        explicit_negative_count = 0
        if explicit_negative_distribution is not None:
            field_negative = explicit_negative_distribution.index_select(
                0, indices
            ).float()
            explicit_negative = (
                field_negative.gt(0)
                & clean_state.eq(self.BACKGROUND)
            )
            explicit_negative_count = int(
                explicit_negative.sum().item()
            )
            positive_support = clean_state.eq(self.TARGET)
            if torch.any(explicit_negative) and torch.any(positive_support):
                positive_score = torch.logsumexp(
                    discovery["logits"][positive_support], dim=0
                ) - math.log(
                    max(int(positive_support.sum().item()), 1)
                )
                explicit_negative_score = torch.logsumexp(
                    discovery["logits"][explicit_negative], dim=0
                ) - math.log(max(explicit_negative_count, 1))
                counterfactual_rank_loss = F.softplus(
                    explicit_negative_score
                    - positive_score
                    + float(counterfactual_margin)
                )
                counterfactual_support_loss = (
                    F.binary_cross_entropy_with_logits(
                        discovery["support_logits"][explicit_negative].float(),
                        torch.zeros(
                            explicit_negative_count,
                            device=discovery["support_logits"].device,
                            dtype=torch.float32,
                        ),
                    )
                )
                counterfactual_loss = (
                    counterfactual_rank_loss
                    + 0.5 * counterfactual_support_loss
                )

        point = self.target_point(target_box_1000)
        raw_target_offsets = point[None, :] - discovery["field_centers_1000"]
        target_offsets = torch.maximum(
            torch.minimum(raw_target_offsets, discovery["offset_limits_1000"]),
            -discovery["offset_limits_1000"],
        )
        offset_per_patch = F.smooth_l1_loss(
            discovery["offsets_1000"] / discovery["offset_limits_1000"],
            target_offsets / discovery["offset_limits_1000"],
            reduction="none",
        ).mean(dim=-1)
        offset_zero = discovery["offsets_1000"].sum() * 0.0
        offset_loss = torch.sum(offset_per_patch * heat_target) + offset_zero

        map_loss = heat_loss + query_map_loss
        x0_loss = diffusion_loss
        regularization_loss = (
            float(support_dice_weight) * support_dice_loss
            + float(ranking_weight) * ranking_loss
            + float(monotonic_weight) * monotonic_loss
            + float(offset_weight) * offset_loss
            + float(counterfactual_weight) * counterfactual_loss
            + float(raw_alignment_weight) * raw_alignment_heat_loss
        )
        # Paper notation: L = L_map + lambda_x0 L_x0 + L_reg. L_MDM is
        # computed by the language-model forward and added outside this module.
        loss = map_loss + float(diffusion_weight) * x0_loss + regularization_loss
        discovery.update(
            {
                "loss": loss,
                "map_loss": map_loss,
                "x0_loss": x0_loss,
                "regularization_loss": regularization_loss,
                "heat_loss": heat_loss,
                "query_map_loss": query_map_loss,
                "diffusion_loss": diffusion_loss,
                "support_dice_loss": support_dice_loss,
                "target_diffusion_loss": target_diffusion,
                "background_diffusion_loss": background_diffusion,
                "ranking_loss": ranking_loss,
                "discovery_heat_loss": discovery_heat_loss,
                "denoise_heat_loss": denoise_heat_loss,
                "boundary_heat_loss": boundary_heat_loss,
                "discovery_ranking_gap": discovery_gap,
                "denoise_ranking_gap": denoise_gap,
                "boundary_ranking_gap": boundary_gap,
                "boundary_diffusion_loss": boundary_diffusion,
                "monotonic_loss": monotonic_loss,
                "counterfactual_loss": counterfactual_loss,
                "counterfactual_rank_loss": counterfactual_rank_loss,
                "counterfactual_support_loss": counterfactual_support_loss,
                "explicit_negative_count": discovery["logits"].new_tensor(
                    explicit_negative_count, dtype=torch.long
                ),
                "offset_loss": offset_loss,
                "raw_alignment_heat_loss": raw_alignment_heat_loss,
                "raw_alignment_aggregate_loss": raw_alignment_aggregate_loss,
                "raw_alignment_per_query_loss": raw_alignment_per_query_loss,
                "raw_alignment_action_query_count": discovery[
                    "logits"
                ].new_tensor(raw_action_query_count, dtype=torch.long),
                "raw_alignment_weight": discovery["logits"].new_tensor(
                    float(raw_alignment_weight)
                ),
                "raw_alignment_logits": (
                    raw_alignment["logits"]
                    if raw_alignment is not None
                    else discovery["logits"].detach()
                ),
                "raw_alignment_per_query_logits": (
                    raw_alignment["per_query_logits"]
                    if raw_alignment is not None
                    else discovery["per_query_logits"].detach()
                ),
                "raw_alignment_mixed_rms": (
                    raw_alignment["raw_alignment_mixed_rms"]
                    if raw_alignment is not None
                    else zero.detach()
                ),
                "heat_target": heat_target,
                "masked_heat_target": masked_heat_target,
                "clean_state": clean_state,
                "noisy_state": noisy_state,
                "predicted_clean_state": predicted_clean_state,
                "masked": masked,
                "t": t,
                "force_all_mask": discovery["logits"].new_tensor(
                    force_all_mask, dtype=torch.bool
                ),
                "no_seed_boundary": discovery["logits"].new_tensor(
                    no_seed_boundary, dtype=torch.bool
                ),
                "denoise_logits": denoised["logits"],
                "denoise_support_logits": denoised["support_logits"],
                "denoise_support_probabilities": denoised[
                    "support_probabilities"
                ],
                "boundary_logits": boundary["logits"],
                "boundary_support_logits": boundary["support_logits"],
                "boundary_support_probabilities": boundary[
                    "support_probabilities"
                ],
            }
        )
        return discovery

    @classmethod
    def commit_reverse_update(
        cls,
        noisy_state: torch.Tensor,
        support_probabilities: torch.Tensor,
        transfer_count: int,
        remaining_steps: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        unresolved = torch.nonzero(
            noisy_state.eq(cls.MASK), as_tuple=False
        ).flatten()
        committed = torch.zeros_like(noisy_state, dtype=torch.bool)
        if unresolved.numel() == 0 or int(transfer_count) <= 0:
            return noisy_state.clone(), committed
        probabilities = support_probabilities.index_select(0, unresolved)
        count = min(int(transfer_count), int(unresolved.numel()))
        predicts_target = probabilities.ge(0.5)
        target_local = torch.nonzero(
            predicts_target, as_tuple=False
        ).flatten()
        background_local = torch.nonzero(
            ~predicts_target, as_tuple=False
        ).flatten()
        # Binary spatial fields contain thousands of easy BACKGROUND sites.
        # A single global confidence sort commits only background until the
        # last step.  Transfer the same fraction of the currently predicted
        # TARGET class at every reverse step, then fill the step with the most
        # confident BACKGROUND predictions.  This is the binary-field analogue
        # of LLaDA confidence transfer and does not inject an anchor or size.
        rounds = max(int(remaining_steps), 1)
        target_count = min(
            int(math.ceil(int(target_local.numel()) / float(rounds))),
            count,
        )
        background_count = min(
            count - target_count, int(background_local.numel())
        )
        target_count = min(
            count - background_count, int(target_local.numel())
        )
        selected: list[torch.Tensor] = []
        if target_count > 0:
            selected.append(
                target_local.index_select(
                    0,
                    torch.topk(
                        probabilities.index_select(0, target_local),
                        k=target_count,
                    ).indices,
                )
            )
        if background_count > 0:
            selected.append(
                background_local.index_select(
                    0,
                    torch.topk(
                        1.0 - probabilities.index_select(0, background_local),
                        k=background_count,
                    ).indices,
                )
            )
        chosen_local = torch.cat(selected, dim=0)
        chosen = unresolved.index_select(0, chosen_local)
        next_state = noisy_state.clone()
        next_state[chosen] = predicts_target.index_select(
            0, chosen_local
        ).long()
        committed[chosen] = True
        return next_state, committed

    @torch.no_grad()
    def sample(
        self,
        *,
        query_hidden: torch.Tensor,
        visual_hidden: torch.Tensor,
        visual_raw_hidden: Optional[torch.Tensor],
        visual_centers_1000: torch.Tensor,
        base_length: int,
        steps: int = 4,
    ) -> dict[str, torch.Tensor | list[dict[str, int]]]:
        field_count = int(
            self.field_indices(
                visual_hidden.shape[0], base_length, visual_hidden.device
            ).numel()
        )
        state = torch.full(
            (field_count,),
            self.MASK,
            device=visual_hidden.device,
            dtype=torch.long,
        )
        steps = max(int(steps), 1)
        transfer_plan = [field_count // steps for _ in range(steps)]
        for index in range(field_count % steps):
            transfer_plan[index] += 1
        trajectory: list[dict[str, int]] = []
        output = None
        initial_top_index = None
        target_commit_probabilities = torch.zeros(
            field_count,
            device=visual_hidden.device,
            dtype=torch.float32,
        )
        for step, transfer_count in enumerate(transfer_plan):
            output = self.compute_action_field(
                query_hidden=query_hidden,
                visual_hidden=visual_hidden,
                visual_raw_hidden=visual_raw_hidden,
                visual_centers_1000=visual_centers_1000,
                base_length=base_length,
                noisy_state=state,
            )
            if initial_top_index is None:
                initial_top_index = int(
                    torch.argmax(output["logits"]).item()
                )
            before = int(state.eq(self.MASK).sum().item())
            state, committed = self.commit_reverse_update(
                state,
                output["support_probabilities"],
                transfer_count,
                steps - step,
            )
            committed_target = committed & state.eq(self.TARGET)
            target_commit_probabilities[committed_target] = output[
                "support_probabilities"
            ][committed_target].float()
            trajectory.append(
                {
                    "step": int(step),
                    "masked_before": before,
                    "committed": int(committed.sum().item()),
                    "committed_target": int(
                        (committed & state.eq(self.TARGET)).sum().item()
                    ),
                    "committed_background": int(
                        (committed & state.eq(self.BACKGROUND)).sum().item()
                    ),
                    "target_after": int(state.eq(self.TARGET).sum().item()),
                    "masked_after": int(state.eq(self.MASK).sum().item()),
                    "top_index": int(torch.argmax(output["logits"]).item()),
                    "initial_top_index": int(initial_top_index),
                }
            )
        # One final denoiser read produces one final semantic action map.
        output = self.compute_action_field(
            query_hidden=query_hidden,
            visual_hidden=visual_hidden,
            visual_raw_hidden=visual_raw_hidden,
            visual_centers_1000=visual_centers_1000,
            base_length=base_length,
            noisy_state=state,
        )
        output["state"] = state
        output["trajectory"] = trajectory
        output["forced_nonempty_target"] = False
        output["semantic_anchor_index"] = None
        output["initial_top_index"] = int(initial_top_index)
        output["target_commit_probabilities"] = (
            target_commit_probabilities
        )
        return output
