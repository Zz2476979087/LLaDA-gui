#    Copyright 2023 Haotian Liu
#
#    Licensed under the Apache License, Version 2.0 (the "License");
#    you may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.


from abc import ABC, abstractmethod

import math
import os
import re
import time
import torch
import torch.nn as nn
from .multimodal_encoder.builder import build_vision_tower
from .multimodal_resampler.builder import build_vision_resampler
from .multimodal_projector.builder import build_vision_projector

from llava.constants import IGNORE_INDEX, IMAGE_TOKEN_INDEX, DEFAULT_IMAGE_PATCH_TOKEN, DEFAULT_IM_START_TOKEN, DEFAULT_IM_END_TOKEN

from llava.mm_utils import get_anyres_image_grid_shape
from llava.utils import rank0_print, rank_print
import random


class LlavaMetaModel:

    def __init__(self, config):
        super(LlavaMetaModel, self).__init__(config)

        if hasattr(config, "mm_vision_tower"):
            delay_load = getattr(config, "delay_load", False)
            self.vision_tower = build_vision_tower(config, delay_load=delay_load)
            self.vision_resampler = build_vision_resampler(config, vision_tower=self.vision_tower)
            self.mm_projector = build_vision_projector(config, vision_cfg=self.vision_tower.config)

            if "unpad" in getattr(config, "mm_patch_merge_type", ""):
                self.image_newline = nn.Parameter(torch.empty(config.hidden_size, dtype=self.dtype))

    def get_vision_tower(self):
        vision_tower = getattr(self, "vision_tower", None)
        if type(vision_tower) is list:
            vision_tower = vision_tower[0]
        return vision_tower

    def initialize_vision_modules(self, model_args, fsdp=None):
        vision_tower = model_args.vision_tower
        mm_vision_select_layer = model_args.mm_vision_select_layer
        mm_vision_select_feature = model_args.mm_vision_select_feature
        pretrain_mm_mlp_adapter = model_args.pretrain_mm_mlp_adapter
        mm_patch_merge_type = model_args.mm_patch_merge_type

        self.config.mm_vision_tower = vision_tower
        self.config.vision_tower_pretrained = getattr(model_args, "vision_tower_pretrained", "")

        if self.get_vision_tower() is None:
            vision_tower = build_vision_tower(model_args)
            vision_resampler = build_vision_resampler(model_args, vision_tower=vision_tower)
            for k, v in vision_resampler.config.items():
                setattr(self.config, k, v)

            if fsdp is not None and len(fsdp) > 0:
                self.vision_tower = [vision_tower]
                self.vision_resampler = [vision_resampler]
            else:
                self.vision_tower = vision_tower
                self.vision_resampler = vision_resampler
        else:
            if fsdp is not None and len(fsdp) > 0:
                vision_resampler = self.vision_resampler[0]
                vision_tower = self.vision_tower[0]
            else:
                vision_resampler = self.vision_resampler
                vision_tower = self.vision_tower
            vision_tower.load_model()

            # In case it is frozen by LoRA
            for p in self.vision_resampler.parameters():
                p.requires_grad = True

        self.config.use_mm_proj = True
        self.config.mm_projector_type = getattr(model_args, "mm_projector_type", "linear")
        self.config.mm_hidden_size = getattr(vision_resampler, "hidden_size", vision_tower.hidden_size)
        self.config.mm_vision_select_layer = mm_vision_select_layer
        self.config.mm_vision_select_feature = mm_vision_select_feature
        self.config.mm_patch_merge_type = mm_patch_merge_type

        
        if not hasattr(self.config, 'add_faster_video'):
            if model_args.add_faster_video:
                embed_std = 1 / torch.sqrt(torch.tensor(self.config.hidden_size, dtype=self.dtype))
                self.faster_token = nn.Parameter(
                    torch.randn(self.config.hidden_size, dtype=self.dtype) * embed_std
                )

        if getattr(self, "mm_projector", None) is None:
            self.mm_projector = build_vision_projector(self.config, vision_cfg=vision_tower.config)

            if "unpad" in mm_patch_merge_type:
                embed_std = 1 / torch.sqrt(torch.tensor(self.config.hidden_size, dtype=self.dtype))
                self.image_newline = nn.Parameter(torch.randn(self.config.hidden_size, dtype=self.dtype) * embed_std)
        else:
            # In case it is frozen by LoRA
            for p in self.mm_projector.parameters():
                p.requires_grad = True

        if pretrain_mm_mlp_adapter is not None:
            mm_projector_weights = torch.load(pretrain_mm_mlp_adapter, map_location="cpu")

            def get_w(weights, keyword):
                return {k.split(keyword + ".")[1]: v for k, v in weights.items() if keyword in k}

            incompatible_keys = self.mm_projector.load_state_dict(get_w(mm_projector_weights, "mm_projector"))
            rank0_print(f"Loaded mm projector weights from {pretrain_mm_mlp_adapter}. Incompatible keys: {incompatible_keys}")
            incompatible_keys = self.vision_resampler.load_state_dict(get_w(mm_projector_weights, "vision_resampler"), strict=False)
            rank0_print(f"Loaded vision resampler weights from {pretrain_mm_mlp_adapter}. Incompatible keys: {incompatible_keys}")


def unpad_image(tensor, original_size):
    """
    Unpads a PyTorch tensor of a padded and resized image.

    Args:
    tensor (torch.Tensor): The image tensor, assumed to be in CxHxW format.
    original_size (tuple): The original size of the image (height, width).

    Returns:
    torch.Tensor: The unpadded image tensor.
    """
    original_width, original_height = original_size
    current_height, current_width = tensor.shape[1:]

    # Compute aspect ratios
    original_aspect_ratio = original_width / original_height
    current_aspect_ratio = current_width / current_height

    # Determine padding size and direction
    if original_aspect_ratio > current_aspect_ratio:
        # Padding was added to the height
        scale_factor = current_width / original_width
        new_height = int(original_height * scale_factor)
        padding = (current_height - new_height) // 2
        unpadded_tensor = tensor[:, padding : current_height - padding, :]
    else:
        # Padding was added to the width
        scale_factor = current_height / original_height
        new_width = int(original_width * scale_factor)
        padding = (current_width - new_width) // 2
        unpadded_tensor = tensor[:, :, padding : current_width - padding]

    return unpadded_tensor


class LlavaMetaForCausalLM(ABC):

    @abstractmethod
    def get_model(self):
        pass

    def get_vision_tower(self):
        return self.get_model().get_vision_tower()

    def get_2dPool(self, image_feature, stride=2):
        height = width = self.get_vision_tower().num_patches_per_side
        num_frames, num_tokens, num_dim = image_feature.shape
        image_feature = image_feature.view(num_frames, height, width, -1)
        image_feature = image_feature.permute(0, 3, 1, 2).contiguous()
        # image_feature = nn.functional.max_pool2d(image_feature, self.config.mm_spatial_pool_stride)
        if self.config.mm_spatial_pool_mode == "average":
            image_feature = nn.functional.avg_pool2d(image_feature, stride)
        elif self.config.mm_spatial_pool_mode == "max":
            image_feature = nn.functional.max_pool2d(image_feature, stride)
        elif self.config.mm_spatial_pool_mode == "bilinear":
            height, width = image_feature.shape[2:]
            scaled_shape = [math.ceil(height / stride), math.ceil(width / stride)]
            image_feature = nn.functional.interpolate(image_feature, size=scaled_shape, mode='bilinear')

        else:
            raise ValueError(f"Unexpected mm_spatial_pool_mode: {self.config.mm_spatial_pool_mode}")
        image_feature = image_feature.permute(0, 2, 3, 1)
        image_feature = image_feature.view(num_frames, -1, num_dim)
        return image_feature

    def encode_images(self, images):
        image_features = self.get_model().get_vision_tower()(images)
        # image_features = self.get_model().vision_resampler(image_features, images=images)
        image_features = self.get_model().mm_projector(image_features)
        return image_features
    
    def encode_multimodals(self, videos_or_images, video_idx_in_batch, split_sizes=None):
        videos_or_images_features = self.get_model().get_vision_tower()(videos_or_images)
        per_videos_or_images_features = torch.split(videos_or_images_features, split_sizes, dim=0)  # tuple, (dim_1, 576, 4096)
        all_videos_or_images_features = []
        all_faster_video_features = []
        cur_mm_spatial_pool_stride = self.config.mm_spatial_pool_stride

        for idx, feat in enumerate(per_videos_or_images_features):
            
            feat = self.get_model().mm_projector(feat)
            faster_video_feature = 0
            slower_img_feat = 0
            if idx in video_idx_in_batch and cur_mm_spatial_pool_stride > 1:
                slower_img_feat = self.get_2dPool(feat,cur_mm_spatial_pool_stride)
                if self.config.add_faster_video:
                    cur_mm_spatial_pool_stride = cur_mm_spatial_pool_stride * 2
                    faster_video_feature = self.get_2dPool(feat,cur_mm_spatial_pool_stride)
            if slower_img_feat != 0:
                all_videos_or_images_features.append(slower_img_feat)
            else:
                all_videos_or_images_features.append(feat)
            all_faster_video_features.append(faster_video_feature)
        return all_videos_or_images_features,all_faster_video_features

    def add_token_per_grid(self, image_feature):
        resize_h = int(math.sqrt(image_feature.shape[1]))
        num_frames = image_feature.shape[0]
        feature_dim = image_feature.shape[-1]

        image_feature = image_feature.view(num_frames, 1, resize_h, resize_h, -1)
        image_feature = image_feature.permute(4, 0, 2, 1, 3).contiguous()
        image_feature = image_feature.flatten(1, 2).flatten(2, 3)
        image_feature = torch.cat((image_feature, self.model.image_newline[:, None, None].expand(*image_feature.shape[:-1], 1).to(image_feature.device)), dim=-1)
        if getattr(self.config, "add_faster_video", False):
            # import pdb; pdb.set_trace()
            # (3584, 832, 14) -> (3584, 64, 13, 14)
            image_feature = image_feature.view(feature_dim, num_frames,resize_h, -1)
            #  (3584, 64, 13, 14) -> (64, 13, 14, 3584)
            image_feature = image_feature.permute(1, 2, 3, 0).contiguous()
            # (64, 13, 14, 3584) -> (64, 13*14, 3584)
            image_feature = image_feature.flatten(1, 2)
            # import pdb; pdb.set_trace()
            return image_feature
        # import pdb; pdb.set_trace()
        image_feature = image_feature.flatten(1, 2).transpose(0, 1)
        return image_feature

    def add_token_per_frame(self, image_feature):
        image_feature = image_feature.permute(2, 0, 1).contiguous()
        image_feature =  torch.cat((image_feature, self.model.image_newline[:, None, None].expand(*image_feature.shape[:-1], 1).to(image_feature.device)), dim=-1)
        image_feature = image_feature.permute(1, 2, 0).contiguous()
        return image_feature

    def generate_conversation_ids(self, labels):
        """
        Args:
            labels: Label tensor, can be one-dimensional or two-dimensional
        Returns:
            Conversation ID tensor with the same shape as labels
        """
        # Process input dimensions
        original_shape = labels.shape
        if labels.ndim == 1:
            labels = labels.unsqueeze(0)

        batch_size, seq_len = labels.shape
        device = labels.device
        conversation_ids = torch.zeros_like(labels)
        
        # Special token IDs
        start_header_id = 126346
        eot_id = 126348
        assistant_role_id1 = 598
        
        # Process all sequences in batch
        for b in range(batch_size):
            # Pre-search all special token positions to reduce repeated searches
            start_positions = (labels[b] == start_header_id).nonzero(as_tuple=True)[0]
            end_positions = (labels[b] == eot_id).nonzero(as_tuple=True)[0]
            
            # If no boundaries are found, continue to the next sequence
            if len(start_positions) == 0 or len(end_positions) == 0:
                continue
            
            # Pair all message start and end positions
            message_boundaries = []
            for start_pos in start_positions:
                # Find the nearest end position
                end_indices = (end_positions >= start_pos).nonzero(as_tuple=True)[0]
                if len(end_indices) == 0:
                    continue
                
                end_pos = end_positions[end_indices[0]]
                
                # Quickly check if it's an assistant message
                start_idx = start_pos.item()
                is_assistant = (start_idx + 1 < seq_len and 
                            labels[b, start_idx + 1] == assistant_role_id1)
                
                message_boundaries.append((start_idx, end_pos.item(), is_assistant))
            
            # Sort by start position
            message_boundaries.sort(key=lambda x: x[0])
            
            # Determine if there is a system message
            has_system = len(message_boundaries) > 0 and not message_boundaries[0][2]
            
            # Assign conversation turn IDs
            current_turn = 0
            prev_was_assistant = False
            
            # Efficiently handle BOS token (usually at the start of the sequence)
            if labels[b, 0] == 126080:  # BOS ID
                conversation_ids[b, 0] = 0
            
            # Assign IDs to all messages at once
            for i, (start_pos, end_pos, is_assistant) in enumerate(message_boundaries):
                # The first non-assistant message is a system message
                is_system = i == 0 and not is_assistant and has_system
                
                if is_system:
                    # System message belongs to the first conversation turn
                    conversation_ids[b, start_pos:end_pos+1] = 0
                else:
                    # If it's a user message and the previous one was an assistant message, increase the turn
                    if not is_assistant and prev_was_assistant:
                        current_turn += 1
                    
                    # Assign ID to the entire message block at once
                    conversation_ids[b, start_pos:end_pos+1] = current_turn
                
                prev_was_assistant = is_assistant
            
            # Fill gaps between messages - use cumulative max method
            # This is much faster than looping element by element
            for i in range(1, seq_len):
                if conversation_ids[b, i] == 0 and conversation_ids[b, i-1] > 0:
                    conversation_ids[b, i] = conversation_ids[b, i-1]
            
            # New: Handle end padding
            non_zero_mask = (conversation_ids[b] != 0)
            if non_zero_mask.any():
                last_non_zero_idx = torch.nonzero(non_zero_mask, as_tuple=True)[0][-1]
                last_turn = conversation_ids[b, last_non_zero_idx]
                conversation_ids[b, last_non_zero_idx+1:] = last_turn
        
        # Return a tensor with the same dimensions as the input
        if len(original_shape) == 1:
            return conversation_ids.squeeze(0)
        
        return conversation_ids

    def _env_bool(self, name, default=False):
        value = os.environ.get(name)
        if value is None or value == "":
            return default
        return value.strip().lower() in {"1", "true", "yes", "y"}

    def _target_label_dilation(self):
        try:
            return max(0, int(os.environ.get("LLADA_GUI_TARGET_LABEL_DILATION", "0") or 0))
        except ValueError:
            return 0

    def _rasterize_box_support(self, rows, cols, box, device, dtype, dilation=0):
        rows = int(rows)
        cols = int(cols)
        patch_labels = torch.zeros((rows, cols), device=device, dtype=dtype)
        if box is None or rows <= 0 or cols <= 0:
            return patch_labels
        coords = torch.as_tensor(box, device=device, dtype=dtype).flatten()
        if coords.numel() < 4:
            return patch_labels
        x1 = torch.clamp(torch.minimum(coords[0], coords[2]), 0.0, 1000.0)
        y1 = torch.clamp(torch.minimum(coords[1], coords[3]), 0.0, 1000.0)
        x2 = torch.clamp(torch.maximum(coords[0], coords[2]), 0.0, 1000.0)
        y2 = torch.clamp(torch.maximum(coords[1], coords[3]), 0.0, 1000.0)
        if (x2 - x1) < 1.0:
            x1 = torch.clamp(x1 - 0.5, 0.0, 1000.0)
            x2 = torch.clamp(x2 + 0.5, 0.0, 1000.0)
        if (y2 - y1) < 1.0:
            y1 = torch.clamp(y1 - 0.5, 0.0, 1000.0)
            y2 = torch.clamp(y2 + 0.5, 0.0, 1000.0)

        if self._env_bool("LLADA_GUI_TARGET_LABEL_SOFT_GAUSSIAN", False):
            try:
                sigma_box_frac = max(
                    0.01,
                    float(os.environ.get("LLADA_GUI_TARGET_LABEL_SOFT_GAUSSIAN_SIGMA_BOX", "0.45") or 0.45),
                )
            except ValueError:
                sigma_box_frac = 0.45
            try:
                sigma_patch_frac = max(
                    0.01,
                    float(os.environ.get("LLADA_GUI_TARGET_LABEL_SOFT_GAUSSIAN_SIGMA_PATCH", "0.65") or 0.65),
                )
            except ValueError:
                sigma_patch_frac = 0.65
            try:
                min_sigma = max(
                    1e-3,
                    float(os.environ.get("LLADA_GUI_TARGET_LABEL_SOFT_GAUSSIAN_MIN_SIGMA", "1.0") or 1.0),
                )
            except ValueError:
                min_sigma = 1.0
            try:
                topk = int(os.environ.get("LLADA_GUI_TARGET_LABEL_SOFT_GAUSSIAN_TOPK", "9") or 9)
            except ValueError:
                topk = 9
            try:
                min_rel = max(
                    0.0,
                    min(
                        1.0,
                        float(os.environ.get("LLADA_GUI_TARGET_LABEL_SOFT_GAUSSIAN_MIN_REL", "0.08") or 0.08),
                    ),
                )
            except ValueError:
                min_rel = 0.08
            try:
                coverage_mix = max(
                    0.0,
                    float(os.environ.get("LLADA_GUI_TARGET_LABEL_SOFT_GAUSSIAN_COVERAGE_MIX", "0.20") or 0.20),
                )
            except ValueError:
                coverage_mix = 0.20

            centers = self._screen_grid_centers(rows, cols, device, dtype).reshape(rows, cols, 2)
            cx = (x1 + x2) * 0.5
            cy = (y1 + y2) * 0.5
            patch_w = torch.as_tensor(1000.0 / max(cols, 1), device=device, dtype=dtype)
            patch_h = torch.as_tensor(1000.0 / max(rows, 1), device=device, dtype=dtype)
            box_w = torch.clamp(x2 - x1, min=1.0)
            box_h = torch.clamp(y2 - y1, min=1.0)
            min_sigma_tensor = torch.as_tensor(min_sigma, device=device, dtype=dtype)
            sigma_x = torch.maximum(
                torch.maximum(box_w * sigma_box_frac, patch_w * sigma_patch_frac),
                min_sigma_tensor,
            )
            sigma_y = torch.maximum(
                torch.maximum(box_h * sigma_box_frac, patch_h * sigma_patch_frac),
                min_sigma_tensor,
            )
            dx = (centers[..., 0] - cx) / sigma_x
            dy = (centers[..., 1] - cy) / sigma_y
            scores = torch.exp(-0.5 * (dx * dx + dy * dy))

            if coverage_mix > 0:
                edges_x = torch.linspace(0.0, 1000.0, cols + 1, device=device, dtype=dtype)
                edges_y = torch.linspace(0.0, 1000.0, rows + 1, device=device, dtype=dtype)
                left = edges_x[:-1][None, :]
                right = edges_x[1:][None, :]
                top = edges_y[:-1][:, None]
                bottom = edges_y[1:][:, None]
                overlap_w = torch.clamp(torch.minimum(right, x2) - torch.maximum(left, x1), min=0.0)
                overlap_h = torch.clamp(torch.minimum(bottom, y2) - torch.maximum(top, y1), min=0.0)
                coverage_scores = torch.clamp((overlap_w * overlap_h) / (patch_w * patch_h), min=0.0)
                scores = scores + float(coverage_mix) * coverage_scores

            flat_scores = scores.flatten()
            keep = torch.zeros_like(flat_scores, dtype=torch.bool)
            if topk > 0:
                k = min(int(topk), int(flat_scores.numel()))
                _values, top_indices = torch.topk(flat_scores, k=k)
                keep[top_indices] = True
                if min_rel > 0:
                    keep = keep & flat_scores.ge(torch.max(flat_scores) * min_rel)
            elif min_rel > 0:
                keep = flat_scores.ge(torch.max(flat_scores) * min_rel)
            else:
                keep = flat_scores.gt(0)
            if not torch.any(keep):
                keep[torch.argmax(flat_scores)] = True
            return torch.where(keep.reshape(rows, cols), scores, torch.zeros_like(scores)).to(dtype)

        if self._env_bool("LLADA_GUI_TARGET_LABEL_TINY_SOFT_CENTER", False):
            try:
                tiny_short_side = float(os.environ.get("LLADA_GUI_TARGET_LABEL_TINY_SOFT_MAX_SHORT", "25") or 25)
            except ValueError:
                tiny_short_side = 25.0
            short_side = torch.minimum(x2 - x1, y2 - y1)
            if tiny_short_side > 0 and float(short_side.detach().float().item()) <= tiny_short_side:
                try:
                    sigma_patch = max(
                        1e-3,
                        float(os.environ.get("LLADA_GUI_TARGET_LABEL_TINY_SOFT_SIGMA_PATCH", "0.75") or 0.75),
                    )
                except ValueError:
                    sigma_patch = 0.75
                try:
                    topk = int(os.environ.get("LLADA_GUI_TARGET_LABEL_TINY_SOFT_TOPK", "9") or 9)
                except ValueError:
                    topk = 9
                try:
                    min_rel = max(
                        0.0,
                        min(1.0, float(os.environ.get("LLADA_GUI_TARGET_LABEL_TINY_SOFT_MIN_REL", "0.05") or 0.05)),
                    )
                except ValueError:
                    min_rel = 0.05
                centers = self._screen_grid_centers(rows, cols, device, dtype).reshape(rows, cols, 2)
                cx = (x1 + x2) * 0.5
                cy = (y1 + y2) * 0.5
                patch_w = torch.as_tensor(1000.0 / max(cols, 1), device=device, dtype=dtype)
                patch_h = torch.as_tensor(1000.0 / max(rows, 1), device=device, dtype=dtype)
                dx = (centers[..., 0] - cx) / patch_w
                dy = (centers[..., 1] - cy) / patch_h
                scores = torch.exp(-0.5 * (dx * dx + dy * dy) / (sigma_patch * sigma_patch))
                flat_scores = scores.flatten()
                keep = torch.zeros_like(flat_scores, dtype=torch.bool)
                if topk > 0:
                    k = min(int(topk), int(flat_scores.numel()))
                    _values, top_indices = torch.topk(flat_scores, k=k)
                    keep[top_indices] = True
                    if min_rel > 0:
                        keep = keep & flat_scores.ge(torch.max(flat_scores) * min_rel)
                    if not torch.any(keep):
                        keep[top_indices[:1]] = True
                else:
                    keep = flat_scores.ge(torch.max(flat_scores) * min_rel)
                    if not torch.any(keep):
                        keep[torch.argmax(flat_scores)] = True
                patch_labels = torch.where(keep.reshape(rows, cols), scores, torch.zeros_like(scores)).to(dtype)
                try:
                    tiny_dilation = max(0, int(os.environ.get("LLADA_GUI_TARGET_LABEL_TINY_DILATION", "0") or 0))
                except ValueError:
                    tiny_dilation = 0
                if tiny_dilation > 0 and torch.any(patch_labels.gt(0)):
                    kernel = 2 * int(tiny_dilation) + 1
                    patch_labels = nn.functional.max_pool2d(
                        patch_labels[None, None].float(),
                        kernel_size=kernel,
                        stride=1,
                        padding=int(tiny_dilation),
                    )[0, 0].to(dtype)
                return patch_labels

        edges_x = torch.linspace(0.0, 1000.0, cols + 1, device=device, dtype=dtype)
        edges_y = torch.linspace(0.0, 1000.0, rows + 1, device=device, dtype=dtype)
        left = edges_x[:-1][None, :]
        right = edges_x[1:][None, :]
        top = edges_y[:-1][:, None]
        bottom = edges_y[1:][:, None]
        overlap_w = torch.clamp(torch.minimum(right, x2) - torch.maximum(left, x1), min=0.0)
        overlap_h = torch.clamp(torch.minimum(bottom, y2) - torch.maximum(top, y1), min=0.0)
        patch_labels = (overlap_w * overlap_h).gt(0).to(dtype)

        if not torch.any(patch_labels.gt(0)):
            cx = (x1 + x2) * 0.5
            cy = (y1 + y2) * 0.5
            col = torch.clamp(torch.floor(cx / (1000.0 / cols)).to(torch.long), 0, cols - 1)
            row = torch.clamp(torch.floor(cy / (1000.0 / rows)).to(torch.long), 0, rows - 1)
            patch_labels[row, col] = 1.0

        if dilation > 0 and torch.any(patch_labels.gt(0)):
            kernel = 2 * int(dilation) + 1
            patch_labels = nn.functional.max_pool2d(
                patch_labels[None, None].float(),
                kernel_size=kernel,
                stride=1,
                padding=int(dilation),
            )[0, 0].gt(0).to(dtype)
        return patch_labels

    def _screen_grid_centers(self, rows, cols, device, dtype):
        rows = int(rows)
        cols = int(cols)
        if rows <= 0 or cols <= 0:
            return torch.empty((0, 2), device=device, dtype=dtype)
        x_centers = (torch.arange(cols, device=device, dtype=dtype) + 0.5) * (1000.0 / cols)
        y_centers = (torch.arange(rows, device=device, dtype=dtype) + 0.5) * (1000.0 / rows)
        grid_y, grid_x = torch.meshgrid(y_centers, x_centers, indexing="ij")
        return torch.stack((grid_x, grid_y), dim=-1).reshape(rows * cols, 2)

    def _env_float(self, name, default):
        try:
            return float(os.environ.get(name, str(default)) or default)
        except Exception:
            return float(default)

    def _box_area_and_short_side(self, box):
        try:
            x1, y1, x2, y2 = [float(v) for v in box[:4]]
        except Exception:
            return 0.0, 0.0
        width = max(0.0, x2 - x1)
        height = max(0.0, y2 - y1)
        return (width * height) / 1_000_000.0, min(width, height)

    def _base_lattice_target_weight(self, box):
        base_weight = max(0.0, self._env_float("LLADA_GUI_TARGET_LABEL_ANYRES_BASE_WEIGHT", 1.0))
        small_weight_raw = os.environ.get("LLADA_GUI_TARGET_LABEL_ANYRES_SMALL_BASE_WEIGHT", "")
        if small_weight_raw == "":
            return base_weight
        try:
            small_weight = max(0.0, float(small_weight_raw))
        except Exception:
            return base_weight
        area_threshold = max(0.0, self._env_float("LLADA_GUI_TARGET_LABEL_ANYRES_SMALL_AREA", 0.001))
        short_threshold = max(0.0, self._env_float("LLADA_GUI_TARGET_LABEL_ANYRES_SMALL_SHORT", 20.0))
        area, short_side = self._box_area_and_short_side(box)
        if (area_threshold > 0 and area <= area_threshold) or (short_threshold > 0 and short_side <= short_threshold):
            return small_weight
        return base_weight

    def _high_resolution_grid_shape(self, image_size, feature_len, base_len, side):
        if image_size is None or int(feature_len) <= int(base_len):
            return None
        mm_patch_merge_type = getattr(self.config, "mm_patch_merge_type", "flat")
        image_aspect_ratio = getattr(self.config, "image_aspect_ratio", "")
        if not (
            isinstance(mm_patch_merge_type, str)
            and mm_patch_merge_type.startswith("spatial")
            and "unpad" in mm_patch_merge_type
            and ("anyres" in str(image_aspect_ratio))
        ):
            return None
        try:
            if hasattr(image_size, "tolist"):
                image_size = image_size.tolist()
            original_width, original_height = int(image_size[0]), int(image_size[1])
        except Exception:
            return None
        if original_width <= 0 or original_height <= 0:
            return None
        try:
            vision_tower_image_size = self.get_vision_tower().image_size
            num_patch_width, num_patch_height = get_anyres_image_grid_shape(
                (original_width, original_height),
                self.config.image_grid_pinpoints,
                vision_tower_image_size,
            )
        except Exception:
            return None
        grid_h = int(num_patch_height) * int(side)
        grid_w = int(num_patch_width) * int(side)
        if grid_h <= 0 or grid_w <= 0:
            return None

        original_aspect_ratio = original_width / original_height
        current_aspect_ratio = grid_w / grid_h
        if original_aspect_ratio > current_aspect_ratio:
            new_h = int(original_height * (grid_w / original_width))
            padding = max(0, (grid_h - new_h) // 2)
            grid_h = max(1, grid_h - 2 * padding)
        else:
            new_w = int(original_width * (grid_h / original_height))
            padding = max(0, (grid_w - new_w) // 2)
            grid_w = max(1, grid_w - 2 * padding)

        matched_anyres_max_num_patches = re.match(r"anyres_max_(\d+)", str(image_aspect_ratio))
        if matched_anyres_max_num_patches:
            max_num_patches = int(matched_anyres_max_num_patches.group(1))
            times = math.sqrt((grid_h * grid_w) / max(1.0, float(max_num_patches * side * side)))
            if times > 1.1:
                grid_h = max(1, int(grid_h // times))
                grid_w = max(1, int(grid_w // times))

        remaining = int(feature_len) - int(base_len)
        if remaining == grid_h * (grid_w + 1):
            return grid_h, grid_w, True
        if remaining == grid_h * grid_w:
            return grid_h, grid_w, False
        return None

    def _target_support_for_box(self, feature_len, box, device, dtype, image_size=None):
        labels = torch.full((int(feature_len),), -1.0, device=device, dtype=dtype)
        if box is None or int(feature_len) <= 0:
            return labels
        try:
            side = int(self.get_vision_tower().num_patches_per_side)
        except Exception:
            side = 27
        if side <= 0:
            return labels
        base_len = min(int(feature_len), side * side)
        if base_len <= 0:
            return labels

        dilation = self._target_label_dilation()
        patch_labels = self._rasterize_box_support(side, side, box, device, dtype, dilation=dilation)
        base_weight = 1.0
        if self._env_bool("LLADA_GUI_TARGET_LABEL_ANYRES", False):
            base_weight = self._base_lattice_target_weight(box)
        labels[:base_len] = patch_labels.flatten()[:base_len] * float(base_weight)
        if not self._env_bool("LLADA_GUI_TARGET_LABEL_ANYRES", False):
            return labels

        grid_shape = self._high_resolution_grid_shape(image_size, int(feature_len), base_len, side)
        if grid_shape is None:
            return labels
        grid_h, grid_w, has_newline = grid_shape
        crop_labels = self._rasterize_box_support(grid_h, grid_w, box, device, dtype, dilation=dilation)
        crop_weight = max(0.0, self._env_float("LLADA_GUI_TARGET_LABEL_ANYRES_CROP_WEIGHT", 1.0))
        crop_labels = crop_labels * float(crop_weight)
        if has_newline:
            crop_with_newline = torch.full(
                (grid_h, grid_w + 1),
                -1.0,
                device=device,
                dtype=dtype,
            )
            crop_with_newline[:, :grid_w] = crop_labels
            flat_crop_labels = crop_with_newline.flatten()
        else:
            flat_crop_labels = crop_labels.flatten()
        end = min(int(feature_len), base_len + flat_crop_labels.numel())
        labels[base_len:end] = flat_crop_labels[: end - base_len]
        return labels

    def _screen_cell_centers_for_feature(self, feature_len, device, dtype, image_size=None):
        centers = torch.full((int(feature_len), 2), -1.0, device=device, dtype=dtype)
        if int(feature_len) <= 0:
            return centers
        try:
            side = int(self.get_vision_tower().num_patches_per_side)
        except Exception:
            side = 27
        if side <= 0:
            return centers
        base_len = min(int(feature_len), side * side)
        if base_len > 0:
            base_centers = self._screen_grid_centers(side, side, device, dtype)
            centers[:base_len] = base_centers[:base_len]

        use_anyres_centers_default = bool(
            self._env_bool("LLADA_GUI_TARGET_LABEL_ANYRES", False)
            or hasattr(self, "screen_state_action_field")
        )
        use_anyres_centers = self._env_bool(
            "LLADA_GUI_CANONICAL_CENTERS",
            use_anyres_centers_default,
        )
        if not use_anyres_centers:
            return centers

        grid_shape = self._high_resolution_grid_shape(image_size, int(feature_len), base_len, side)
        if grid_shape is None:
            return centers
        grid_h, grid_w, has_newline = grid_shape
        crop_centers = self._screen_grid_centers(grid_h, grid_w, device, dtype)
        if has_newline:
            crop_with_newline = torch.full(
                (grid_h, grid_w + 1, 2),
                -1.0,
                device=device,
                dtype=dtype,
            )
            crop_with_newline[:, :grid_w] = crop_centers.view(grid_h, grid_w, 2)
            flat_crop_centers = crop_with_newline.reshape(-1, 2)
        else:
            flat_crop_centers = crop_centers
        end = min(int(feature_len), base_len + flat_crop_centers.shape[0])
        centers[base_len:end] = flat_crop_centers[: end - base_len]
        return centers

    def prepare_inputs_labels_for_multimodal(
        self,
        input_ids,
        position_ids,
        attention_mask,
        past_key_values,
        labels,
        images,
        modalities=["image"],
        image_sizes=None,
        is_llada=False,
        mdm_token_weights=None,
        mdm_mask_positions=None,
        mdm_negative_labels=None,
        target_boxes_1000=None,
        target_row_mask=None,
        target_is_icon=None,
        negative_boxes_1000=None,
        negative_row_mask=None,
        instruction_token_mask=None,
        action_query_token_mask=None,
        coordinate_token_mask=None,
    ):
        self._target_support_labels = None
        self._negative_support_labels = None
        self._screen_cell_centers = None
        self._target_row_mask = None
        self._target_is_icon = None
        self._instruction_token_mask = None
        self._instruction_labels = None
        self._action_query_token_mask = None
        self._coordinate_token_mask = None
        # The action field consumes one coordinate per visual token. Target
        # support uses the same canonical geometry during training.
        track_visual_token_centers = bool(
            hasattr(self, "screen_state_action_field")
            or target_boxes_1000 is not None
        )
        vision_tower = self.get_vision_tower()
        has_screen_state_controls = (
            mdm_token_weights is not None
            or mdm_mask_positions is not None
            or mdm_negative_labels is not None
            or target_boxes_1000 is not None
            or target_row_mask is not None
            or target_is_icon is not None
            or negative_boxes_1000 is not None
            or negative_row_mask is not None
            or instruction_token_mask is not None
            or action_query_token_mask is not None
            or coordinate_token_mask is not None
        )
        if vision_tower is None or images is None or input_ids.shape[1] == 1:
            if has_screen_state_controls:
                if is_llada:
                    return input_ids, position_ids, attention_mask, past_key_values, None, labels, None, mdm_token_weights, mdm_mask_positions, mdm_negative_labels
                return input_ids, position_ids, attention_mask, past_key_values, None, labels, mdm_token_weights, mdm_mask_positions, mdm_negative_labels
            return input_ids, position_ids, attention_mask, past_key_values, None, labels

        if isinstance(modalities, str):
            modalities = [modalities]

        # import pdb; pdb.set_trace()
        if type(images) is list or images.ndim == 5:
            if type(images) is list:
                images = [x.unsqueeze(0) if x.ndim == 3 else x for x in images]

            video_idx_in_batch = []
            for _ in range(len(modalities)):
                if modalities[_] == "video":
                    video_idx_in_batch.append(_)

            images_list = []
            for image in images:
                if image.ndim == 4:
                    images_list.append(image)
                else:
                    images_list.append(image.unsqueeze(0))

            concat_images = torch.cat([image for image in images_list], dim=0)
            split_sizes = [image.shape[0] for image in images_list]
            encoded_image_features = self.encode_images(concat_images)
            # image_features,all_faster_video_features = self.encode_multimodals(concat_images, video_idx_in_batch, split_sizes)

            # This is a list, each element is [num_images, patch * patch, dim]
            # rank_print(f"Concat images : {concat_images.shape}")
            encoded_image_features = torch.split(encoded_image_features, split_sizes)
            image_features = []
            for idx, image_feat in enumerate(encoded_image_features):
                if idx in video_idx_in_batch:
                    image_features.append(self.get_2dPool(image_feat))
                else:
                    image_features.append(image_feat)
            # image_features = self.encode_multimodals(concat_images, video_idx_in_batch, split_sizes)
            # rank_print(f"Encoded image feats : {[x.shape for x in image_features]}")
            # image_features = torch.split(image_features, split_sizes, dim=0)
            mm_patch_merge_type = getattr(self.config, "mm_patch_merge_type", "flat")
            image_aspect_ratio = getattr(self.config, "image_aspect_ratio", "square")
            mm_newline_position = getattr(self.config, "mm_newline_position", "one_token")

            if mm_patch_merge_type == "flat":
                image_features = [x.flatten(0, 1) for x in image_features]

            elif mm_patch_merge_type.startswith("spatial"):
                new_image_features = []
                for image_idx, image_feature in enumerate(image_features):
                    # FIXME: now assume the image is square, and split to 2x2 patches
                    # num_patches = h * w, where h = w = sqrt(num_patches)
                    # currently image_feature is a tensor of shape (4, num_patches, hidden_size)
                    # we want to first unflatten it to (2, 2, h, w, hidden_size)
                    # rank0_print("At least we are reaching here")
                    # import pdb; pdb.set_trace()
                    if image_idx in video_idx_in_batch:  # video operations
                        # rank0_print("Video")
                        if mm_newline_position == "grid":
                            # Grid-wise
                            image_feature = self.add_token_per_grid(image_feature)
                            if getattr(self.config, "add_faster_video", False):
                                faster_video_feature = self.add_token_per_grid(all_faster_video_features[image_idx])
                                # Add a token for each frame
                                concat_slow_fater_token = []
                                # import pdb; pdb.set_trace()
                                for _ in range(image_feature.shape[0]):
                                    if _ % self.config.faster_token_stride == 0:
                                        concat_slow_fater_token.append(torch.cat((image_feature[_], self.model.faster_token[None].to(image_feature.device)), dim=0))
                                    else:
                                        concat_slow_fater_token.append(torch.cat((faster_video_feature[_], self.model.faster_token[None].to(image_feature.device)), dim=0))
                                # import pdb; pdb.set_trace()
                                image_feature = torch.cat(concat_slow_fater_token)

                                # print("!!!!!!!!!!!!")
                        
                            new_image_features.append(image_feature)
                        elif mm_newline_position == "frame":
                            # Frame-wise
                            image_feature = self.add_token_per_frame(image_feature)

                            new_image_features.append(image_feature.flatten(0, 1))
                            
                        elif mm_newline_position == "one_token":
                            # one-token
                            image_feature = image_feature.flatten(0, 1)
                            if 'unpad' in mm_patch_merge_type:
                                image_feature = torch.cat((
                                    image_feature,
                                    self.model.image_newline[None].to(image_feature.device)
                                ), dim=0)
                            new_image_features.append(image_feature)      
                        elif mm_newline_position == "no_token":
                            new_image_features.append(image_feature.flatten(0, 1))
                        else:
                            raise ValueError(f"Unexpected mm_newline_position: {mm_newline_position}")
                    elif image_feature.shape[0] > 1:  # multi patches and multi images operations
                        # rank0_print("Single-images")
                        base_image_feature = image_feature[0]
                        image_feature = image_feature[1:]
                        height = width = self.get_vision_tower().num_patches_per_side
                        assert height * width == base_image_feature.shape[0]

                        if "anyres_max" in image_aspect_ratio:
                            matched_anyres_max_num_patches = re.match(r"anyres_max_(\d+)", image_aspect_ratio)
                            if matched_anyres_max_num_patches:
                                max_num_patches = int(matched_anyres_max_num_patches.group(1))

                        if image_aspect_ratio == "anyres" or "anyres_max" in image_aspect_ratio:
                            if hasattr(self.get_vision_tower(), "image_size"):
                                vision_tower_image_size = self.get_vision_tower().image_size
                            else:
                                raise ValueError("vision_tower_image_size is not found in the vision tower.")
                            try:
                                num_patch_width, num_patch_height = get_anyres_image_grid_shape(image_sizes[image_idx], self.config.image_grid_pinpoints, vision_tower_image_size)
                            except Exception as e:
                                rank0_print(f"Error: {e}")
                                num_patch_width, num_patch_height = 2, 2
                            image_feature = image_feature.view(num_patch_height, num_patch_width, height, width, -1)
                        else:
                            image_feature = image_feature.view(2, 2, height, width, -1)

                        if "maxpool2x2" in mm_patch_merge_type:
                            image_feature = image_feature.permute(4, 0, 2, 1, 3).contiguous()
                            image_feature = image_feature.flatten(1, 2).flatten(2, 3)
                            image_feature = nn.functional.max_pool2d(image_feature, 2)
                            image_feature = image_feature.flatten(1, 2).transpose(0, 1)
                        elif "unpad" in mm_patch_merge_type and "anyres_max" in image_aspect_ratio and matched_anyres_max_num_patches:
                            unit = image_feature.shape[2]
                            image_feature = image_feature.permute(4, 0, 2, 1, 3).contiguous()
                            image_feature = image_feature.flatten(1, 2).flatten(2, 3)
                            image_feature = unpad_image(image_feature, image_sizes[image_idx])
                            c, h, w = image_feature.shape
                            times = math.sqrt(h * w / (max_num_patches * unit**2))
                            if times > 1.1:
                                image_feature = image_feature[None]
                                image_feature = nn.functional.interpolate(image_feature, [int(h // times), int(w // times)], mode="bilinear")[0]
                            image_feature = torch.cat((image_feature, self.model.image_newline[:, None, None].expand(*image_feature.shape[:-1], 1).to(image_feature.device)), dim=-1)
                            image_feature = image_feature.flatten(1, 2).transpose(0, 1)
                        elif "unpad" in mm_patch_merge_type:
                            image_feature = image_feature.permute(4, 0, 2, 1, 3).contiguous()
                            image_feature = image_feature.flatten(1, 2).flatten(2, 3)
                            image_feature = unpad_image(image_feature, image_sizes[image_idx])
                            image_feature = torch.cat((image_feature, self.model.image_newline[:, None, None].expand(*image_feature.shape[:-1], 1).to(image_feature.device)), dim=-1)
                            image_feature = image_feature.flatten(1, 2).transpose(0, 1)
                        else:
                            image_feature = image_feature.permute(0, 2, 1, 3, 4).contiguous()
                            image_feature = image_feature.flatten(0, 3)
                        if "nobase" in mm_patch_merge_type:
                            pass
                        else:
                            image_feature = torch.cat((base_image_feature, image_feature), dim=0)
                        new_image_features.append(image_feature)
                    else:  # single image operations
                        image_feature = image_feature[0]
                        if "unpad" in mm_patch_merge_type:
                            image_feature = torch.cat((image_feature, self.model.image_newline[None]), dim=0)

                        new_image_features.append(image_feature)
                image_features = new_image_features
            else:
                raise ValueError(f"Unexpected mm_patch_merge_type: {self.config.mm_patch_merge_type}")
        else:
            image_features = self.encode_images(images)

        # TODO: image start / end is not implemented here to support pretraining.
        if getattr(self.config, "tune_mm_mlp_adapter", False) and getattr(self.config, "mm_use_im_start_end", False):
            raise NotImplementedError
        # rank_print(f"Total images : {len(image_features)}")

        # Let's just add dummy tensors if they do not exist,
        # it is a headache to deal with None all the time.
        # But it is not ideal, and if you have a better idea,
        # please open an issue / submit a PR, thanks.
        _labels = labels
        _position_ids = position_ids
        _attention_mask = attention_mask
        _mdm_token_weights = mdm_token_weights
        _mdm_mask_positions = mdm_mask_positions
        _mdm_negative_labels = mdm_negative_labels
        _target_boxes_1000 = target_boxes_1000
        _target_row_mask = target_row_mask
        _negative_boxes_1000 = negative_boxes_1000
        _negative_row_mask = negative_row_mask
        _instruction_token_mask = instruction_token_mask
        _action_query_token_mask = action_query_token_mask
        _coordinate_token_mask = coordinate_token_mask
        if attention_mask is None:
            attention_mask = torch.ones_like(input_ids, dtype=torch.bool)
        else:
            attention_mask = attention_mask.bool()
        if position_ids is None:
            position_ids = torch.arange(0, input_ids.shape[1], dtype=torch.long, device=input_ids.device)
        if labels is None:
            labels = torch.full_like(input_ids, IGNORE_INDEX)
        if mdm_token_weights is not None:
            mdm_token_weights = mdm_token_weights.to(device=input_ids.device)
        if mdm_mask_positions is not None:
            mdm_mask_positions = mdm_mask_positions.to(device=input_ids.device)
        if mdm_negative_labels is not None:
            mdm_negative_labels = mdm_negative_labels.to(device=input_ids.device)
        if instruction_token_mask is not None:
            instruction_token_mask = instruction_token_mask.to(device=input_ids.device, dtype=torch.bool)
        if action_query_token_mask is not None:
            action_query_token_mask = action_query_token_mask.to(device=input_ids.device, dtype=torch.bool)
        if coordinate_token_mask is not None:
            coordinate_token_mask = coordinate_token_mask.to(device=input_ids.device, dtype=torch.bool)
        if target_boxes_1000 is not None:
            target_boxes_1000 = target_boxes_1000.to(device=input_ids.device, dtype=torch.float32)
        if target_row_mask is not None:
            target_row_mask = target_row_mask.to(device=input_ids.device, dtype=torch.bool)
        if target_is_icon is not None:
            target_is_icon = target_is_icon.to(device=input_ids.device, dtype=torch.bool)
        if negative_boxes_1000 is not None:
            negative_boxes_1000 = negative_boxes_1000.to(device=input_ids.device, dtype=torch.float32)
        if negative_row_mask is not None:
            negative_row_mask = negative_row_mask.to(device=input_ids.device, dtype=torch.bool)

        # remove the padding using attention_mask -- FIXME
        _input_ids = input_ids
        input_ids = [cur_input_ids[cur_attention_mask] for cur_input_ids, cur_attention_mask in zip(input_ids, attention_mask)]
        labels = [cur_labels[cur_attention_mask] for cur_labels, cur_attention_mask in zip(labels, attention_mask)]
        if mdm_token_weights is not None:
            mdm_token_weights = [cur_weights[cur_attention_mask] for cur_weights, cur_attention_mask in zip(mdm_token_weights, attention_mask)]
        if mdm_mask_positions is not None:
            mdm_mask_positions = [cur_positions[cur_attention_mask] for cur_positions, cur_attention_mask in zip(mdm_mask_positions, attention_mask)]
        if mdm_negative_labels is not None:
            mdm_negative_labels = [cur_labels[cur_attention_mask] for cur_labels, cur_attention_mask in zip(mdm_negative_labels, attention_mask)]
        if instruction_token_mask is not None:
            instruction_token_mask = [
                cur_mask[cur_attention_mask]
                for cur_mask, cur_attention_mask in zip(instruction_token_mask, attention_mask)
            ]
        if action_query_token_mask is not None:
            action_query_token_mask = [
                cur_mask[cur_attention_mask]
                for cur_mask, cur_attention_mask in zip(action_query_token_mask, attention_mask)
            ]
        if coordinate_token_mask is not None:
            coordinate_token_mask = [
                cur_mask[cur_attention_mask]
                for cur_mask, cur_attention_mask in zip(coordinate_token_mask, attention_mask)
            ]

        new_input_embeds = []
        new_labels = []
        new_mdm_token_weights = []
        new_mdm_mask_positions = []
        new_mdm_negative_labels = []
        new_instruction_token_mask = []
        new_instruction_labels = []
        new_action_query_token_mask = []
        new_coordinate_token_mask = []
        new_target_support_labels = []
        new_negative_support_labels = []
        new_screen_cell_centers = []
        cur_image_idx = 0
        # rank_print("Inserting Images embedding")
        for batch_idx, cur_input_ids in enumerate(input_ids):
            num_images = (cur_input_ids == IMAGE_TOKEN_INDEX).sum()
            # rank0_print(num_images)
            if num_images == 0:
                cur_image_features = image_features[cur_image_idx]
                cur_input_embeds_1 = self.get_model().embed_tokens(cur_input_ids)
                cur_input_embeds = torch.cat([cur_input_embeds_1, cur_image_features[0:0]], dim=0)
                new_input_embeds.append(cur_input_embeds)
                new_labels.append(labels[batch_idx])
                if mdm_token_weights is not None:
                    new_mdm_token_weights.append(mdm_token_weights[batch_idx])
                if mdm_mask_positions is not None:
                    new_mdm_mask_positions.append(mdm_mask_positions[batch_idx])
                if mdm_negative_labels is not None:
                    new_mdm_negative_labels.append(mdm_negative_labels[batch_idx])
                if instruction_token_mask is not None:
                    new_instruction_token_mask.append(instruction_token_mask[batch_idx])
                    new_instruction_labels.append(
                        torch.where(
                            instruction_token_mask[batch_idx].to(device=cur_input_ids.device, dtype=torch.bool),
                            cur_input_ids,
                            torch.full_like(cur_input_ids, IGNORE_INDEX),
                        )
                    )
                if action_query_token_mask is not None:
                    new_action_query_token_mask.append(action_query_token_mask[batch_idx])
                if coordinate_token_mask is not None:
                    new_coordinate_token_mask.append(coordinate_token_mask[batch_idx])
                if target_boxes_1000 is not None:
                    new_target_support_labels.append(
                        torch.full(
                            (cur_input_embeds.shape[0],),
                            -1.0,
                            device=cur_input_embeds.device,
                            dtype=torch.float32,
                        )
                    )
                if negative_boxes_1000 is not None:
                    new_negative_support_labels.append(
                        torch.full(
                            (cur_input_embeds.shape[0],),
                            -1.0,
                            device=cur_input_embeds.device,
                            dtype=torch.float32,
                        )
                    )
                if track_visual_token_centers:
                    new_screen_cell_centers.append(
                        torch.full(
                            (cur_input_embeds.shape[0], 2),
                            -1.0,
                            device=cur_input_embeds.device,
                            dtype=torch.float32,
                        )
                    )
                cur_image_idx += 1
                continue

            image_token_indices = [-1] + torch.where(cur_input_ids == IMAGE_TOKEN_INDEX)[0].tolist() + [cur_input_ids.shape[0]]
            cur_input_ids_noim = []
            cur_labels = labels[batch_idx]
            cur_labels_noim = []
            cur_weights_noim = []
            cur_mask_positions_noim = []
            cur_negative_labels_noim = []
            cur_instruction_mask_noim = []
            cur_instruction_labels_noim = []
            cur_action_query_mask_noim = []
            cur_coord_mask_noim = []
            for i in range(len(image_token_indices) - 1):
                cur_input_ids_piece = cur_input_ids[image_token_indices[i] + 1 : image_token_indices[i + 1]]
                cur_input_ids_noim.append(cur_input_ids_piece)
                cur_labels_noim.append(cur_labels[image_token_indices[i] + 1 : image_token_indices[i + 1]])
                if mdm_token_weights is not None:
                    cur_weights = mdm_token_weights[batch_idx]
                    cur_weights_noim.append(cur_weights[image_token_indices[i] + 1 : image_token_indices[i + 1]])
                if mdm_mask_positions is not None:
                    cur_positions = mdm_mask_positions[batch_idx]
                    cur_mask_positions_noim.append(cur_positions[image_token_indices[i] + 1 : image_token_indices[i + 1]])
                if mdm_negative_labels is not None:
                    cur_negative_labels = mdm_negative_labels[batch_idx]
                    cur_negative_labels_noim.append(cur_negative_labels[image_token_indices[i] + 1 : image_token_indices[i + 1]])
                if instruction_token_mask is not None:
                    cur_instruction_mask = instruction_token_mask[batch_idx]
                    cur_instruction_mask_piece = cur_instruction_mask[
                        image_token_indices[i] + 1 : image_token_indices[i + 1]
                    ]
                    cur_instruction_mask_noim.append(cur_instruction_mask_piece)
                    cur_instruction_labels_noim.append(
                        torch.where(
                            cur_instruction_mask_piece.to(device=cur_input_ids_piece.device, dtype=torch.bool),
                            cur_input_ids_piece,
                            torch.full_like(cur_input_ids_piece, IGNORE_INDEX),
                        )
                    )
                if action_query_token_mask is not None:
                    cur_action_query_mask = action_query_token_mask[batch_idx]
                    cur_action_query_mask_noim.append(cur_action_query_mask[image_token_indices[i] + 1 : image_token_indices[i + 1]])
                if coordinate_token_mask is not None:
                    cur_coord_mask = coordinate_token_mask[batch_idx]
                    cur_coord_mask_noim.append(cur_coord_mask[image_token_indices[i] + 1 : image_token_indices[i + 1]])
            split_sizes = [x.shape[0] for x in cur_labels_noim]
            cur_input_embeds = self.get_model().embed_tokens(torch.cat(cur_input_ids_noim))
            cur_input_embeds_no_im = torch.split(cur_input_embeds, split_sizes, dim=0)
            cur_new_input_embeds = []
            cur_new_labels = []
            cur_new_mdm_token_weights = []
            cur_new_mdm_mask_positions = []
            cur_new_mdm_negative_labels = []
            cur_new_instruction_token_mask = []
            cur_new_instruction_labels = []
            cur_new_action_query_token_mask = []
            cur_new_coordinate_token_mask = []
            cur_new_target_support_labels = []
            cur_new_negative_support_labels = []
            cur_new_screen_cell_centers = []

            for i in range(num_images + 1):
                cur_new_input_embeds.append(cur_input_embeds_no_im[i])
                cur_new_labels.append(cur_labels_noim[i])
                if track_visual_token_centers:
                    cur_new_screen_cell_centers.append(
                        torch.full(
                            (cur_input_embeds_no_im[i].shape[0], 2),
                            -1.0,
                            device=cur_input_embeds_no_im[i].device,
                            dtype=torch.float32,
                        )
                    )
                if target_boxes_1000 is not None:
                    cur_new_target_support_labels.append(
                        torch.full(
                            (cur_input_embeds_no_im[i].shape[0],),
                            -1.0,
                            device=cur_input_embeds_no_im[i].device,
                            dtype=torch.float32,
                        )
                    )
                if negative_boxes_1000 is not None:
                    cur_new_negative_support_labels.append(
                        torch.full(
                            (cur_input_embeds_no_im[i].shape[0],),
                            -1.0,
                            device=cur_input_embeds_no_im[i].device,
                            dtype=torch.float32,
                        )
                    )
                if mdm_token_weights is not None:
                    cur_new_mdm_token_weights.append(cur_weights_noim[i])
                if mdm_mask_positions is not None:
                    cur_new_mdm_mask_positions.append(cur_mask_positions_noim[i])
                if mdm_negative_labels is not None:
                    cur_new_mdm_negative_labels.append(cur_negative_labels_noim[i])
                if instruction_token_mask is not None:
                    cur_new_instruction_token_mask.append(cur_instruction_mask_noim[i])
                    cur_new_instruction_labels.append(cur_instruction_labels_noim[i])
                if action_query_token_mask is not None:
                    cur_new_action_query_token_mask.append(cur_action_query_mask_noim[i])
                if coordinate_token_mask is not None:
                    cur_new_coordinate_token_mask.append(cur_coord_mask_noim[i])
                if i < num_images:
                    try:
                        cur_image_size_for_gui = image_sizes[cur_image_idx] if image_sizes is not None else None
                        cur_image_features = image_features[cur_image_idx]
                    except IndexError:
                        cur_image_size_for_gui = image_sizes[cur_image_idx - 1] if image_sizes is not None else None
                        cur_image_features = image_features[cur_image_idx - 1]
                    cur_image_idx += 1
                    cur_new_input_embeds.append(cur_image_features)
                    cur_new_labels.append(torch.full((cur_image_features.shape[0],), IGNORE_INDEX, device=cur_labels.device, dtype=cur_labels.dtype))
                    if target_boxes_1000 is not None:
                        pointer_active = (
                            target_row_mask is None
                            or bool(target_row_mask[batch_idx].item())
                        )
                        if pointer_active:
                            visual_labels = self._target_support_for_box(
                                cur_image_features.shape[0],
                                target_boxes_1000[batch_idx],
                                cur_image_features.device,
                                torch.float32,
                                image_size=cur_image_size_for_gui,
                            )
                        else:
                            visual_labels = torch.full(
                                (cur_image_features.shape[0],),
                                0.0,
                                device=cur_image_features.device,
                                dtype=torch.float32,
                            )
                        cur_new_target_support_labels.append(visual_labels)
                    if negative_boxes_1000 is not None:
                        negative_pointer_active = (
                            negative_row_mask is None
                            or bool(negative_row_mask[batch_idx].item())
                        )
                        if negative_pointer_active:
                            negative_visual_labels = self._target_support_for_box(
                                cur_image_features.shape[0],
                                negative_boxes_1000[batch_idx],
                                cur_image_features.device,
                                torch.float32,
                                image_size=cur_image_size_for_gui,
                            )
                        else:
                            negative_visual_labels = torch.full(
                                (cur_image_features.shape[0],),
                                -1.0,
                                device=cur_image_features.device,
                                dtype=torch.float32,
                            )
                        cur_new_negative_support_labels.append(negative_visual_labels)
                    if track_visual_token_centers:
                        cur_new_screen_cell_centers.append(
                            self._screen_cell_centers_for_feature(
                                cur_image_features.shape[0],
                                cur_image_features.device,
                                torch.float32,
                                image_size=cur_image_size_for_gui,
                            )
                        )
                    if mdm_token_weights is not None:
                        cur_new_mdm_token_weights.append(torch.ones((cur_image_features.shape[0],), device=cur_labels.device, dtype=mdm_token_weights[batch_idx].dtype))
                    if mdm_mask_positions is not None:
                        cur_new_mdm_mask_positions.append(torch.zeros((cur_image_features.shape[0],), device=cur_labels.device, dtype=mdm_mask_positions[batch_idx].dtype))
                    if mdm_negative_labels is not None:
                        cur_new_mdm_negative_labels.append(
                            torch.full(
                                (cur_image_features.shape[0],),
                                IGNORE_INDEX,
                                device=cur_labels.device,
                                dtype=mdm_negative_labels[batch_idx].dtype,
                            )
                        )
                    if instruction_token_mask is not None:
                        cur_new_instruction_token_mask.append(
                            torch.zeros(
                                (cur_image_features.shape[0],),
                                device=cur_labels.device,
                                dtype=torch.bool,
                            )
                        )
                        cur_new_instruction_labels.append(
                            torch.full(
                                (cur_image_features.shape[0],),
                                IGNORE_INDEX,
                                device=cur_labels.device,
                                dtype=cur_labels.dtype,
                            )
                        )
                    if action_query_token_mask is not None:
                        cur_new_action_query_token_mask.append(
                            torch.zeros(
                                (cur_image_features.shape[0],),
                                device=cur_labels.device,
                                dtype=torch.bool,
                            )
                        )
                    if coordinate_token_mask is not None:
                        cur_new_coordinate_token_mask.append(
                            torch.zeros(
                                (cur_image_features.shape[0],),
                                device=cur_labels.device,
                                dtype=torch.bool,
                            )
                        )

            cur_new_input_embeds = [x.to(self.device) for x in cur_new_input_embeds]

            # import pdb; pdb.set_trace()
            cur_new_input_embeds = torch.cat(cur_new_input_embeds)
            cur_new_labels = torch.cat(cur_new_labels)
            if mdm_token_weights is not None:
                cur_new_mdm_token_weights = torch.cat(cur_new_mdm_token_weights)
            if mdm_mask_positions is not None:
                cur_new_mdm_mask_positions = torch.cat(cur_new_mdm_mask_positions)
            if mdm_negative_labels is not None:
                cur_new_mdm_negative_labels = torch.cat(cur_new_mdm_negative_labels)
            if instruction_token_mask is not None:
                cur_new_instruction_token_mask = torch.cat(cur_new_instruction_token_mask)
                cur_new_instruction_labels = torch.cat(cur_new_instruction_labels)
            if action_query_token_mask is not None:
                cur_new_action_query_token_mask = torch.cat(cur_new_action_query_token_mask)
            if coordinate_token_mask is not None:
                cur_new_coordinate_token_mask = torch.cat(cur_new_coordinate_token_mask)
            if target_boxes_1000 is not None:
                cur_new_target_support_labels = torch.cat(cur_new_target_support_labels)
            if negative_boxes_1000 is not None:
                cur_new_negative_support_labels = torch.cat(cur_new_negative_support_labels)
            if track_visual_token_centers:
                cur_new_screen_cell_centers = torch.cat(cur_new_screen_cell_centers)

            new_input_embeds.append(cur_new_input_embeds)
            new_labels.append(cur_new_labels)
            if mdm_token_weights is not None:
                new_mdm_token_weights.append(cur_new_mdm_token_weights)
            if mdm_mask_positions is not None:
                new_mdm_mask_positions.append(cur_new_mdm_mask_positions)
            if mdm_negative_labels is not None:
                new_mdm_negative_labels.append(cur_new_mdm_negative_labels)
            if instruction_token_mask is not None:
                new_instruction_token_mask.append(cur_new_instruction_token_mask)
                new_instruction_labels.append(cur_new_instruction_labels)
            if action_query_token_mask is not None:
                new_action_query_token_mask.append(cur_new_action_query_token_mask)
            if coordinate_token_mask is not None:
                new_coordinate_token_mask.append(cur_new_coordinate_token_mask)
            if target_boxes_1000 is not None:
                new_target_support_labels.append(cur_new_target_support_labels)
            if negative_boxes_1000 is not None:
                new_negative_support_labels.append(cur_new_negative_support_labels)
            if track_visual_token_centers:
                new_screen_cell_centers.append(cur_new_screen_cell_centers)

        # Truncate sequences to max length as image embeddings can make the sequence longer
        tokenizer_model_max_length = getattr(self.config, "tokenizer_model_max_length", None)
        # rank_print("Finishing Inserting")

        new_input_embeds = [x[:tokenizer_model_max_length] for x, modality in zip(new_input_embeds, modalities)]
        new_labels = [x[:tokenizer_model_max_length] for x, modality in zip(new_labels, modalities)]
        if mdm_token_weights is not None:
            new_mdm_token_weights = [x[:tokenizer_model_max_length] for x, modality in zip(new_mdm_token_weights, modalities)]
        if mdm_mask_positions is not None:
            new_mdm_mask_positions = [x[:tokenizer_model_max_length] for x, modality in zip(new_mdm_mask_positions, modalities)]
        if mdm_negative_labels is not None:
            new_mdm_negative_labels = [x[:tokenizer_model_max_length] for x, modality in zip(new_mdm_negative_labels, modalities)]
        if instruction_token_mask is not None:
            new_instruction_token_mask = [
                x[:tokenizer_model_max_length]
                for x, modality in zip(new_instruction_token_mask, modalities)
            ]
            new_instruction_labels = [
                x[:tokenizer_model_max_length]
                for x, modality in zip(new_instruction_labels, modalities)
            ]
        if action_query_token_mask is not None:
            new_action_query_token_mask = [
                x[:tokenizer_model_max_length]
                for x, modality in zip(new_action_query_token_mask, modalities)
            ]
        if coordinate_token_mask is not None:
            new_coordinate_token_mask = [
                x[:tokenizer_model_max_length]
                for x, modality in zip(new_coordinate_token_mask, modalities)
            ]
        if target_boxes_1000 is not None:
            new_target_support_labels = [x[:tokenizer_model_max_length] for x, modality in zip(new_target_support_labels, modalities)]
        if negative_boxes_1000 is not None:
            new_negative_support_labels = [x[:tokenizer_model_max_length] for x, modality in zip(new_negative_support_labels, modalities)]
        if track_visual_token_centers:
            new_screen_cell_centers = [
                x[:tokenizer_model_max_length]
                for x, modality in zip(new_screen_cell_centers, modalities)
            ]
        # TODO: Hard code for control loss spike
        # if tokenizer_model_max_length is not None:
        #     new_input_embeds = [x[:4096] if modality != "video" else x[:tokenizer_model_max_length] for x, modality in zip(new_input_embeds, modalities)]
        #     new_labels = [x[:4096] if modality != "video" else x[:tokenizer_model_max_length] for x, modality in zip(new_labels, modalities)]

        # Combine them
        max_len = max(x.shape[0] for x in new_input_embeds)
        batch_size = len(new_input_embeds)

        new_input_embeds_padded = []
        new_labels_padded = torch.full((batch_size, max_len), IGNORE_INDEX, dtype=new_labels[0].dtype, device=new_labels[0].device)
        new_mdm_token_weights_padded = None
        new_mdm_mask_positions_padded = None
        new_mdm_negative_labels_padded = None
        new_instruction_token_mask_padded = None
        new_instruction_labels_padded = None
        new_action_query_token_mask_padded = None
        new_coordinate_token_mask_padded = None
        new_target_support_labels_padded = None
        new_negative_support_labels_padded = None
        new_screen_cell_centers_padded = None
        if mdm_token_weights is not None:
            new_mdm_token_weights_padded = torch.ones((batch_size, max_len), dtype=new_mdm_token_weights[0].dtype, device=new_mdm_token_weights[0].device)
        if mdm_mask_positions is not None:
            new_mdm_mask_positions_padded = torch.zeros((batch_size, max_len), dtype=new_mdm_mask_positions[0].dtype, device=new_mdm_mask_positions[0].device)
        if mdm_negative_labels is not None:
            new_mdm_negative_labels_padded = torch.full(
                (batch_size, max_len),
                IGNORE_INDEX,
                dtype=new_mdm_negative_labels[0].dtype,
                device=new_mdm_negative_labels[0].device,
            )
        if instruction_token_mask is not None:
            new_instruction_token_mask_padded = torch.zeros(
                (batch_size, max_len),
                dtype=torch.bool,
                device=new_input_embeds[0].device,
            )
            new_instruction_labels_padded = torch.full(
                (batch_size, max_len),
                IGNORE_INDEX,
                dtype=new_labels[0].dtype,
                device=new_labels[0].device,
            )
        if action_query_token_mask is not None:
            new_action_query_token_mask_padded = torch.zeros(
                (batch_size, max_len),
                dtype=torch.bool,
                device=new_input_embeds[0].device,
            )
        if coordinate_token_mask is not None:
            new_coordinate_token_mask_padded = torch.zeros(
                (batch_size, max_len),
                dtype=torch.bool,
                device=new_input_embeds[0].device,
            )
        if target_boxes_1000 is not None:
            new_target_support_labels_padded = torch.full(
                (batch_size, max_len),
                -1.0,
                dtype=torch.float32,
                device=new_input_embeds[0].device,
            )
        if negative_boxes_1000 is not None:
            new_negative_support_labels_padded = torch.full(
                (batch_size, max_len),
                -1.0,
                dtype=torch.float32,
                device=new_input_embeds[0].device,
            )
        if track_visual_token_centers:
            new_screen_cell_centers_padded = torch.full(
                (batch_size, max_len, 2),
                -1.0,
                dtype=torch.float32,
                device=new_input_embeds[0].device,
            )
        attention_mask = torch.zeros((batch_size, max_len), dtype=attention_mask.dtype, device=attention_mask.device)
        position_ids = torch.zeros((batch_size, max_len), dtype=position_ids.dtype, device=position_ids.device)
        # rank0_print("Prepare pos id")

        for i, (cur_new_embed, cur_new_labels) in enumerate(zip(new_input_embeds, new_labels)):
            cur_len = cur_new_embed.shape[0]
            if getattr(self.config, "tokenizer_padding_side", "right") == "left":
                new_input_embeds_padded.append(torch.cat((torch.zeros((max_len - cur_len, cur_new_embed.shape[1]), dtype=cur_new_embed.dtype, device=cur_new_embed.device), cur_new_embed), dim=0))
                if cur_len > 0:
                    new_labels_padded[i, -cur_len:] = cur_new_labels
                    if new_mdm_token_weights_padded is not None:
                        new_mdm_token_weights_padded[i, -cur_len:] = new_mdm_token_weights[i]
                    if new_mdm_mask_positions_padded is not None:
                        new_mdm_mask_positions_padded[i, -cur_len:] = new_mdm_mask_positions[i]
                    if new_mdm_negative_labels_padded is not None:
                        new_mdm_negative_labels_padded[i, -cur_len:] = new_mdm_negative_labels[i]
                    if new_instruction_token_mask_padded is not None:
                        new_instruction_token_mask_padded[i, -cur_len:] = new_instruction_token_mask[i]
                    if new_instruction_labels_padded is not None:
                        new_instruction_labels_padded[i, -cur_len:] = new_instruction_labels[i]
                    if new_action_query_token_mask_padded is not None:
                        new_action_query_token_mask_padded[i, -cur_len:] = new_action_query_token_mask[i]
                    if new_coordinate_token_mask_padded is not None:
                        new_coordinate_token_mask_padded[i, -cur_len:] = new_coordinate_token_mask[i]
                    if new_target_support_labels_padded is not None:
                        new_target_support_labels_padded[i, -cur_len:] = new_target_support_labels[i]
                    if new_negative_support_labels_padded is not None:
                        new_negative_support_labels_padded[i, -cur_len:] = new_negative_support_labels[i]
                    if new_screen_cell_centers_padded is not None:
                        new_screen_cell_centers_padded[i, -cur_len:] = new_screen_cell_centers[i]
                    attention_mask[i, -cur_len:] = True
                    position_ids[i, -cur_len:] = torch.arange(0, cur_len, dtype=position_ids.dtype, device=position_ids.device)
            else:
                new_input_embeds_padded.append(torch.cat((cur_new_embed, torch.zeros((max_len - cur_len, cur_new_embed.shape[1]), dtype=cur_new_embed.dtype, device=cur_new_embed.device)), dim=0))
                if cur_len > 0:
                    new_labels_padded[i, :cur_len] = cur_new_labels
                    if new_mdm_token_weights_padded is not None:
                        new_mdm_token_weights_padded[i, :cur_len] = new_mdm_token_weights[i]
                    if new_mdm_mask_positions_padded is not None:
                        new_mdm_mask_positions_padded[i, :cur_len] = new_mdm_mask_positions[i]
                    if new_mdm_negative_labels_padded is not None:
                        new_mdm_negative_labels_padded[i, :cur_len] = new_mdm_negative_labels[i]
                    if new_instruction_token_mask_padded is not None:
                        new_instruction_token_mask_padded[i, :cur_len] = new_instruction_token_mask[i]
                    if new_instruction_labels_padded is not None:
                        new_instruction_labels_padded[i, :cur_len] = new_instruction_labels[i]
                    if new_action_query_token_mask_padded is not None:
                        new_action_query_token_mask_padded[i, :cur_len] = new_action_query_token_mask[i]
                    if new_coordinate_token_mask_padded is not None:
                        new_coordinate_token_mask_padded[i, :cur_len] = new_coordinate_token_mask[i]
                    if new_target_support_labels_padded is not None:
                        new_target_support_labels_padded[i, :cur_len] = new_target_support_labels[i]
                    if new_negative_support_labels_padded is not None:
                        new_negative_support_labels_padded[i, :cur_len] = new_negative_support_labels[i]
                    if new_screen_cell_centers_padded is not None:
                        new_screen_cell_centers_padded[i, :cur_len] = new_screen_cell_centers[i]
                    attention_mask[i, :cur_len] = True
                    position_ids[i, :cur_len] = torch.arange(0, cur_len, dtype=position_ids.dtype, device=position_ids.device)

        new_input_embeds = torch.stack(new_input_embeds_padded, dim=0)
        # rank0_print("tokenizer padding")

        if _labels is None:
            new_labels = None
        else:
            new_labels = new_labels_padded

        if _attention_mask is None:
            attention_mask = None
        else:
            attention_mask = attention_mask.to(dtype=_attention_mask.dtype)

        if _position_ids is None:
            position_ids = None
        if _target_boxes_1000 is not None:
            self._target_support_labels = new_target_support_labels_padded
            self._target_boxes_1000 = _target_boxes_1000.to(
                device=new_input_embeds.device,
                dtype=torch.float32,
            )
            self._target_row_mask = (
                _target_row_mask.to(device=new_input_embeds.device, dtype=torch.bool)
                if _target_row_mask is not None
                else torch.ones((batch_size,), device=new_input_embeds.device, dtype=torch.bool)
            )
            self._target_is_icon = (
                target_is_icon.to(device=new_input_embeds.device, dtype=torch.bool)
                if target_is_icon is not None
                else torch.zeros((batch_size,), device=new_input_embeds.device, dtype=torch.bool)
            )
        else:
            self._target_boxes_1000 = None
        if _negative_boxes_1000 is not None:
            self._negative_support_labels = new_negative_support_labels_padded
        if track_visual_token_centers:
            self._screen_cell_centers = new_screen_cell_centers_padded
        if _instruction_token_mask is not None:
            self._instruction_token_mask = new_instruction_token_mask_padded
            self._instruction_labels = new_instruction_labels_padded
        if _action_query_token_mask is not None:
            self._action_query_token_mask = new_action_query_token_mask_padded
        if _coordinate_token_mask is not None:
            self._coordinate_token_mask = new_coordinate_token_mask_padded
        if getattr(self.config, "use_pos_skipping", False) and self.training:
            position_ids = torch.arange(new_input_embeds.size(1), device=new_input_embeds.device).unsqueeze(0).to(new_input_embeds.device)
            split_position = random.randint(0, new_input_embeds.size(1))
            left_add = random.randint(0, self.config.pos_skipping_range)
            right_add = random.randint(left_add, self.config.pos_skipping_range)
            position_ids[:, :split_position] += left_add
            position_ids[:, split_position:] += right_add
        
        # add conversation_ids 
        if is_llada and attention_mask is not None: 
            conversation_ids = self.generate_conversation_ids(new_labels)
            if has_screen_state_controls:
                return None, position_ids, attention_mask, past_key_values, new_input_embeds, new_labels, conversation_ids, new_mdm_token_weights_padded, new_mdm_mask_positions_padded, new_mdm_negative_labels_padded
            return None, position_ids, attention_mask, past_key_values, new_input_embeds, new_labels, conversation_ids
        # import pdb; pdb.set_trace()
        # rank0_print("Finish preparing")
        if has_screen_state_controls:
            return None, position_ids, attention_mask, past_key_values, new_input_embeds, new_labels, new_mdm_token_weights_padded, new_mdm_mask_positions_padded, new_mdm_negative_labels_padded
        return None, position_ids, attention_mask, past_key_values, new_input_embeds, new_labels

    def initialize_vision_tokenizer(self, model_args, tokenizer):
        if model_args.mm_use_im_patch_token:
            tokenizer.add_tokens([DEFAULT_IMAGE_PATCH_TOKEN], special_tokens=True)
            self.resize_token_embeddings(len(tokenizer))

        if model_args.mm_use_im_start_end:
            num_new_tokens = tokenizer.add_tokens([DEFAULT_IM_START_TOKEN, DEFAULT_IM_END_TOKEN], special_tokens=True)
            self.resize_token_embeddings(len(tokenizer))

            if num_new_tokens > 0:
                input_embeddings = self.get_input_embeddings().weight.data
                output_embeddings = self.get_output_embeddings().weight.data

                input_embeddings_avg = input_embeddings[:-num_new_tokens].mean(dim=0, keepdim=True)
                output_embeddings_avg = output_embeddings[:-num_new_tokens].mean(dim=0, keepdim=True)

                input_embeddings[-num_new_tokens:] = input_embeddings_avg
                output_embeddings[-num_new_tokens:] = output_embeddings_avg

            if model_args.tune_mm_mlp_adapter:
                for p in self.get_input_embeddings().parameters():
                    p.requires_grad = True
                for p in self.get_output_embeddings().parameters():
                    p.requires_grad = False

            if model_args.pretrain_mm_mlp_adapter:
                mm_projector_weights = torch.load(model_args.pretrain_mm_mlp_adapter, map_location="cpu")
                embed_tokens_weight = mm_projector_weights["model.embed_tokens.weight"]
                assert num_new_tokens == 2
                if input_embeddings.shape == embed_tokens_weight.shape:
                    input_embeddings[-num_new_tokens:] = embed_tokens_weight[-num_new_tokens:]
                elif embed_tokens_weight.shape[0] == num_new_tokens:
                    input_embeddings[-num_new_tokens:] = embed_tokens_weight
                else:
                    raise ValueError(f"Unexpected embed_tokens_weight shape. Pretrained: {embed_tokens_weight.shape}. Current: {input_embeddings.shape}. Numer of new tokens: {num_new_tokens}.")
        elif model_args.mm_use_im_patch_token:
            if model_args.tune_mm_mlp_adapter:
                for p in self.get_input_embeddings().parameters():
                    p.requires_grad = False
                for p in self.get_output_embeddings().parameters():
                    p.requires_grad = False
