"""Checkpoint loader for the released LLaDA-GUI model."""

from __future__ import annotations

import os
from typing import Any

import torch
from transformers import AutoTokenizer

from llava.constants import (
    DEFAULT_IMAGE_PATCH_TOKEN,
    DEFAULT_IM_END_TOKEN,
    DEFAULT_IM_START_TOKEN,
)
from llava.model.language_model.llava_llada import (
    LlavaLLaDAConfig,
    LlavaLLaDAModelLM,
)
from llava.utils import rank0_print


def _resolve_dtype(value: Any) -> torch.dtype | None:
    if value in ("float16", torch.float16, torch.half):
        return torch.float16
    if value in ("bfloat16", torch.bfloat16):
        return torch.bfloat16
    if value in (None, "auto"):
        return None
    raise ValueError(f"Unsupported torch_dtype={value!r}")


def load_pretrained_model(
    model_path,
    model_base,
    model_name,
    load_8bit=False,
    load_4bit=False,
    device_map="auto",
    torch_dtype="float16",
    attn_implementation="flash_attention_2",
    customized_config=None,
    overwrite_config=None,
    **kwargs,
):
    """Load one full LLaDA-GUI checkpoint and its SigLIP-2 vision tower."""
    if model_base is not None:
        raise ValueError("LLaDA-GUI expects a full checkpoint; model_base must be omitted")
    if load_8bit or load_4bit:
        raise ValueError("the released inference path does not use quantized loading")
    kwargs.pop("multimodal", None)
    kwargs["device_map"] = device_map
    resolved_dtype = _resolve_dtype(torch_dtype)
    if resolved_dtype is not None:
        kwargs["torch_dtype"] = resolved_dtype

    config = customized_config or LlavaLLaDAConfig.from_pretrained(model_path)
    if overwrite_config:
        rank0_print(f"Overwriting config with {overwrite_config}")
        for name, value in overwrite_config.items():
            setattr(config, name, value)
    has_action_field = any(
        bool(getattr(config, key, False))
        for key in (
            "screen_state_action_field_enabled",
            "gui_unified_spatial_action_diffusion_enabled",
            "gui_screen_state_action_field_enabled",
            "gui_diffusion_grounding_enabled",
        )
    )
    if not has_action_field:
        raise ValueError("checkpoint does not declare a screen-state action field")

    tokenizer_path = (
        os.environ.get("LLADA_GUI_TOKENIZER_PATH")
        or os.environ.get("LLADA_TOKENIZER_PATH")
        or model_path
    )
    tokenizer = AutoTokenizer.from_pretrained(
        tokenizer_path,
        use_fast=False,
        trust_remote_code=True,
    )
    model = LlavaLLaDAModelLM.from_pretrained(
        model_path,
        low_cpu_mem_usage=True,
        attn_implementation=attn_implementation,
        config=config,
        **kwargs,
    )

    if getattr(model.config, "mm_use_im_patch_token", True):
        tokenizer.add_tokens([DEFAULT_IMAGE_PATCH_TOKEN], special_tokens=True)
    if getattr(model.config, "mm_use_im_start_end", False):
        tokenizer.add_tokens(
            [DEFAULT_IM_START_TOKEN, DEFAULT_IM_END_TOKEN],
            special_tokens=True,
        )
    model.resize_token_embeddings(len(tokenizer))

    vision_tower = model.get_vision_tower()
    if not vision_tower.is_loaded:
        vision_tower.load_model(device_map=device_map)
    if device_map != "auto":
        vision_tower.to(device="cuda", dtype=torch.float16)
    image_processor = vision_tower.image_processor

    context_len = getattr(
        model.config,
        "max_sequence_length",
        getattr(
            model.config,
            "max_position_embeddings",
            getattr(model.config, "tokenizer_model_max_length", 2048),
        ),
    )
    rank0_print(f"Model Class: {model.__class__.__name__}")
    return tokenizer, model, image_processor, context_len
