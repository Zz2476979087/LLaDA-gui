"""Prompt, click readout, and action serialization for LLaDA-GUI."""

__all__ = ["action_serialization", "click_readout", "grounding_prompt"]
