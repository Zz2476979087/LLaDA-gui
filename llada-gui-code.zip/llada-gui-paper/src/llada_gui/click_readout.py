from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import torch


@dataclass(frozen=True)
class ClickRegion:
    indices: torch.Tensor
    score: torch.Tensor
    mass: torch.Tensor
    point: torch.Tensor


def _field_indices(
    probabilities: torch.Tensor,
    centers_1000: torch.Tensor,
    base_length: int,
) -> torch.Tensor:
    if probabilities.ndim != 1:
        raise ValueError("action probabilities must be one-dimensional")
    if centers_1000.shape != (probabilities.numel(), 2):
        raise ValueError("action probabilities and visual centres must align")
    valid = torch.isfinite(centers_1000).all(dim=-1)
    valid = valid & centers_1000.ge(0.0).all(dim=-1)
    start = min(max(int(base_length), 0), int(probabilities.numel()))
    highres = torch.arange(
        probabilities.numel(),
        device=probabilities.device,
        dtype=torch.long,
    ).ge(start)
    selected = valid & highres
    if not torch.any(selected):
        selected = valid
    indices = torch.nonzero(selected, as_tuple=False).flatten()
    if indices.numel() == 0:
        raise ValueError("action field contains no valid visual location")
    return indices


def connected_target_regions(
    probabilities: torch.Tensor,
    centers_1000: torch.Tensor,
    *,
    base_length: int,
    threshold_ratio: float = 0.30,
    offsets_1000: Optional[torch.Tensor] = None,
    selection_mode: str = "mean",
) -> list[ClickRegion]:
    """Return four-neighbour target regions from one action field.

    The any-resolution visual sequence contains a coarse base grid followed by
    one canonical high-resolution screen grid.  Only that non-duplicated grid
    is decoded when it exists.  Components are ranked later by mean action
    probability by default.  The
    ``peak_anchored`` mode instead keeps the connected object containing the
    global semantic maximum first.  This prevents a compact lower-peak island
    from replacing the model's semantic winner while retaining region-centre
    decoding.
    """

    probabilities = probabilities.float().reshape(-1)
    centers = centers_1000.float()
    if offsets_1000 is None:
        offsets = torch.zeros_like(centers)
    else:
        offsets = offsets_1000.float()
        if offsets.shape != centers.shape:
            raise ValueError("action offsets and visual centres must align")
    field_indices = _field_indices(probabilities, centers, base_length)
    field_probabilities = probabilities.index_select(0, field_indices)
    field_centers = centers.index_select(0, field_indices)
    field_points = (field_centers + offsets.index_select(0, field_indices)).clamp(
        0.0, 1000.0
    )

    peak = field_probabilities.max()
    threshold = peak * max(float(threshold_ratio), 0.0)
    active_local = torch.nonzero(
        field_probabilities.ge(threshold), as_tuple=False
    ).flatten()
    if active_local.numel() == 0:
        active_local = torch.argmax(field_probabilities).reshape(1)

    x_values, x_inverse = torch.unique(
        field_centers[:, 0], sorted=True, return_inverse=True
    )
    y_values, y_inverse = torch.unique(
        field_centers[:, 1], sorted=True, return_inverse=True
    )
    if int(x_values.numel() * y_values.numel()) != int(field_centers.shape[0]):
        raise ValueError(
            "high-resolution visual centres do not form one regular screen grid"
        )

    coordinate_to_local: dict[tuple[int, int], int] = {}
    for local_index in active_local.tolist():
        coordinate = (
            int(y_inverse[local_index].item()),
            int(x_inverse[local_index].item()),
        )
        if coordinate in coordinate_to_local:
            raise ValueError("duplicate visual centre in canonical action grid")
        coordinate_to_local[coordinate] = int(local_index)

    unvisited = set(coordinate_to_local)
    components: list[ClickRegion] = []
    while unvisited:
        seed = unvisited.pop()
        queue = [seed]
        coordinates = [seed]
        while queue:
            y, x = queue.pop()
            for neighbour in ((y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1)):
                if neighbour not in unvisited:
                    continue
                unvisited.remove(neighbour)
                queue.append(neighbour)
                coordinates.append(neighbour)
        local_indices = torch.tensor(
            [coordinate_to_local[value] for value in coordinates],
            device=probabilities.device,
            dtype=torch.long,
        )
        indices = field_indices.index_select(0, local_indices)
        weights = field_probabilities.index_select(0, local_indices).clamp_min(0.0)
        mass = weights.sum()
        point = torch.sum(
            field_points.index_select(0, local_indices) * weights[:, None],
            dim=0,
        ) / mass.clamp_min(1e-12)
        components.append(
            ClickRegion(
                indices=indices,
                score=weights.mean(),
                mass=mass,
                point=point,
            )
        )
    normalized_mode = str(selection_mode).strip().lower()
    if normalized_mode not in {"mean", "peak_anchored"}:
        raise ValueError(
            "action component selection_mode must be mean or peak_anchored"
        )
    if normalized_mode == "peak_anchored":
        peak_index = field_indices[int(torch.argmax(field_probabilities).item())]
        components.sort(
            key=lambda component: (
                bool(torch.any(component.indices.eq(peak_index)).item()),
                float(component.score.item()),
            ),
            reverse=True,
        )
    else:
        components.sort(
            key=lambda component: float(component.score.item()), reverse=True
        )
    return components


def decode_click_from_field(
    probabilities: torch.Tensor,
    centers_1000: torch.Tensor,
    *,
    base_length: int,
    threshold_ratio: float = 0.30,
    offsets_1000: Optional[torch.Tensor] = None,
    selection_mode: str = "mean",
    peak_window_radius: int = 2,
) -> dict[str, torch.Tensor]:
    """Decode one final click from a semantic action field."""

    normalized_mode = str(selection_mode).strip().lower()
    component_mode = (
        "peak_anchored" if normalized_mode == "peak_window" else normalized_mode
    )
    components = connected_target_regions(
        probabilities,
        centers_1000,
        base_length=base_length,
        threshold_ratio=threshold_ratio,
        offsets_1000=offsets_1000,
        selection_mode=component_mode,
    )
    best = components[0]
    if normalized_mode == "peak_window":
        radius = max(int(peak_window_radius), 0)
        field_indices = _field_indices(probabilities, centers_1000, base_length)
        field_centers = centers_1000.float().index_select(0, field_indices)
        x_values, x_inverse = torch.unique(
            field_centers[:, 0], sorted=True, return_inverse=True
        )
        y_values, y_inverse = torch.unique(
            field_centers[:, 1], sorted=True, return_inverse=True
        )
        if int(x_values.numel() * y_values.numel()) != int(
            field_centers.shape[0]
        ):
            raise ValueError(
                "high-resolution visual centres do not form one regular screen grid"
            )
        peak_field = int(
            torch.argmax(
                probabilities.float().index_select(0, field_indices)
            ).item()
        )
        global_to_field = torch.full(
            (probabilities.numel(),),
            -1,
            device=probabilities.device,
            dtype=torch.long,
        )
        global_to_field[field_indices] = torch.arange(
            field_indices.numel(),
            device=probabilities.device,
            dtype=torch.long,
        )
        component_field = global_to_field.index_select(0, best.indices)
        within_window = (
            (x_inverse.index_select(0, component_field) - x_inverse[peak_field])
            .abs()
            .le(radius)
            & (y_inverse.index_select(0, component_field) - y_inverse[peak_field])
            .abs()
            .le(radius)
        )
        window_indices = best.indices[within_window]
        if window_indices.numel() == 0:
            window_indices = field_indices[peak_field].reshape(1)
        window_weights = probabilities.float().index_select(
            0, window_indices
        ).clamp_min(0.0)
        if offsets_1000 is None:
            points = centers_1000.float().index_select(0, window_indices)
        else:
            points = (
                centers_1000.float().index_select(0, window_indices)
                + offsets_1000.float().index_select(0, window_indices)
            ).clamp(0.0, 1000.0)
        best = ClickRegion(
            indices=window_indices,
            score=window_weights.mean(),
            mass=window_weights.sum(),
            point=torch.sum(points * window_weights[:, None], dim=0)
            / window_weights.sum().clamp_min(1e-12),
        )
    weights = probabilities.float().index_select(
        0, best.indices
    ).clamp_min(0.0)
    component_center = torch.sum(
        centers_1000.float().index_select(0, best.indices)
        * weights[:, None],
        dim=0,
    ) / weights.sum().clamp_min(1e-12)
    return {
        "point": best.point.clamp(0.0, 1000.0),
        "component_center": component_center.clamp(0.0, 1000.0),
        "indices": best.indices,
        "score": best.score,
        "mass": best.mass,
        "component_count": best.indices.new_tensor(len(components)),
    }


def serialize_click_digits(
    point_1000: torch.Tensor,
    *,
    half_size: float = 5.0,
) -> torch.Tensor:
    """Serialize one final point as twelve fixed-width decimal digits."""

    point = point_1000.float().reshape(-1)
    if point.numel() != 2:
        raise ValueError("a click point must contain x and y")
    box = torch.stack(
        (
            point[0] - float(half_size),
            point[1] - float(half_size),
            point[0] + float(half_size),
            point[1] + float(half_size),
        )
    ).round().clamp(0.0, 999.0).long()
    divisors = box.new_tensor((100, 10, 1))
    digits = torch.remainder(
        torch.div(box[:, None], divisors[None, :], rounding_mode="floor"),
        10,
    )
    return digits.reshape(12)
