from __future__ import annotations

import math
import re
from typing import Any


LCLICK_RE = re.compile(
    r"(?:lclick|click)\s*\[\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*,"
    r"\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\]",
    flags=re.IGNORECASE,
)

def clamp(value: float, lo: float = 0.0, hi: float = 1000.0) -> float:
    return max(lo, min(hi, float(value)))


def normalize_bbox1000(value: Any) -> list[float] | None:
    if not isinstance(value, (list, tuple)) or len(value) < 4:
        return None
    try:
        vals = [float(v) for v in value[:4]]
    except (TypeError, ValueError):
        return None
    if not all(math.isfinite(v) for v in vals):
        return None
    if max(abs(v) for v in vals) <= 1.5:
        vals = [v * 1000.0 for v in vals]
    vals = [clamp(v) for v in vals]
    x1, x2 = sorted((vals[0], vals[2]))
    y1, y2 = sorted((vals[1], vals[3]))
    if x2 <= x1 or y2 <= y1:
        return None
    return [x1, y1, x2, y2]


def parse_lclick(text: Any) -> list[float] | None:
    match = LCLICK_RE.search(str(text or ""))
    if not match:
        return None
    return normalize_bbox1000([float(v) for v in match.groups()])


def bbox_center(box: list[float]) -> tuple[float, float]:
    return (box[0] + box[2]) * 0.5, (box[1] + box[3]) * 0.5


def fixed_click_action(cx: float, cy: float, half_size: float = 5.0) -> tuple[str, list[float]]:
    cx = clamp(cx)
    cy = clamp(cy)
    x1 = int(round(clamp(cx - half_size)))
    y1 = int(round(clamp(cy - half_size)))
    x2 = int(round(clamp(cx + half_size)))
    y2 = int(round(clamp(cy + half_size)))
    if x2 <= x1:
        x1 = min(x1, 999)
        x2 = x1 + 1
    if y2 <= y1:
        y1 = min(y1, 999)
        y2 = y1 + 1
    box = [float(x1), float(y1), float(x2), float(y2)]
    return f"lclick [{x1},{y1},{x2},{y2}]", box


def action_from_bbox(box: list[float], half_size: float = 5.0) -> tuple[str, list[float]]:
    cx, cy = bbox_center(box)
    return fixed_click_action(cx, cy, half_size=half_size)


def area_bin(box: list[float]) -> str:
    area = max(0.0, box[2] - box[0]) * max(0.0, box[3] - box[1]) / 1_000_000.0
    if area < 0.0015:
        return "tiny"
    if area < 0.01:
        return "small"
    if area < 0.05:
        return "medium"
    return "large"


def edge_bucket(box: list[float]) -> str:
    cx, cy = bbox_center(box)
    out: list[str] = []
    if cx < 80:
        out.append("left")
    if cx > 920:
        out.append("right")
    if cy < 80:
        out.append("top")
    if cy > 920:
        out.append("bottom")
    return "+".join(out) if out else "not_edge"
