from __future__ import annotations

import re

import torch

from llava.constants import DEFAULT_IMAGE_TOKEN, IMAGE_TOKEN_INDEX
from llava.mm_utils import tokenizer_image_token


SYSTEM_MESSAGE = (
    "You are a helpful language and vision assistant. You are able to understand the "
    "visual content that the user provides, and assist the user with a variety of tasks "
    "using natural language."
)

LLADA_CHAT_TEMPLATE = (
    "{% for message in messages %}"
    "{{'<|startoftext|>' + '<|start_header_id|>' + message['role'] + "
    "'<|end_header_id|>' + '\n\n' + message['content'] + '<|eot_id|>'}}"
    "{% endfor %}"
    "{% if add_generation_prompt %}{{ '<|start_header_id|>assistant<|end_header_id|>\n\n' }}{% endif %}"
)

FORMAT_HINT = (
    "Return exactly one action and nothing else. Use this format: "
    "lclick [x1,y1,x2,y2]. The box should be a tiny box centered on the "
    "element to click."
)


def first_user_instruction(row: dict) -> str:
    for turn in row.get("conversations", []):
        role = turn.get("from") or turn.get("role")
        if role in {"human", "user"}:
            value = str(turn.get("value") or turn.get("content") or "")
            return value.replace(DEFAULT_IMAGE_TOKEN, "").strip()
    return str(row.get("instruction") or row.get("query") or "").strip()


def build_prompt(tokenizer, instruction: str, format_hint: str = "") -> str:
    tokenizer.chat_template = LLADA_CHAT_TEMPLATE
    if format_hint:
        instruction = f"{instruction.strip()}\n{format_hint.strip()}".strip()
    messages = [
        {"role": "system", "content": SYSTEM_MESSAGE},
        {"role": "user", "content": f"{DEFAULT_IMAGE_TOKEN}\n{instruction}"},
    ]
    return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)


def _find_subsequence(values: list[int], pattern: list[int]) -> int:
    if not pattern or len(pattern) > len(values):
        return -1
    for start in range(0, len(values) - len(pattern) + 1):
        if values[start : start + len(pattern)] == pattern:
            return start
    return -1


def _find_subsequence_last(values: list[int], pattern: list[int]) -> int:
    if not pattern or len(pattern) > len(values):
        return -1
    for start in range(len(values) - len(pattern), -1, -1):
        if values[start : start + len(pattern)] == pattern:
            return start
    return -1


def task_instruction_text(content: str) -> str:
    text = str(content or "")
    text = re.sub(r"<image>", " ", text, flags=re.IGNORECASE)
    text = re.split(r"Return exactly one action", text, maxsplit=1, flags=re.IGNORECASE)[0]
    text = re.split(r"Use this format", text, maxsplit=1, flags=re.IGNORECASE)[0]
    text = re.split(r"The box should", text, maxsplit=1, flags=re.IGNORECASE)[0]
    text = re.split(r"Do not output", text, maxsplit=1, flags=re.IGNORECASE)[0]
    return re.sub(r"\s+", " ", text).strip()


def _tokenize_without_bos(tokenizer, text: str) -> list[int]:
    try:
        token_ids = list(tokenizer(text, add_special_tokens=False).input_ids)
    except TypeError:
        token_ids = list(tokenizer(text).input_ids)
    bos_id = getattr(tokenizer, "bos_token_id", None)
    if token_ids and bos_id is not None and int(token_ids[0]) == int(bos_id):
        token_ids = token_ids[1:]
    return [int(token_id) for token_id in token_ids]


def build_instruction_token_mask(
    tokenizer,
    prompt: str,
    instruction: str,
    device=None,
    prefer_last: bool = False,
) -> torch.Tensor:
    prompt_ids = tokenizer_image_token(prompt, tokenizer, IMAGE_TOKEN_INDEX, return_tensors="pt")
    prompt_ids_list = [int(token_id) for token_id in prompt_ids.tolist()]
    mask = torch.zeros_like(prompt_ids, dtype=torch.bool)

    task_text = task_instruction_text(instruction)
    task_ids = _tokenize_without_bos(tokenizer, task_text) if task_text else []
    start = (
        _find_subsequence_last(prompt_ids_list, task_ids)
        if prefer_last
        else _find_subsequence(prompt_ids_list, task_ids)
    )
    if start >= 0:
        special_ids = {
            int(token_id)
            for token_id in [
                tokenizer.convert_tokens_to_ids("<|startoftext|>"),
                tokenizer.convert_tokens_to_ids("<|start_header_id|>"),
                tokenizer.convert_tokens_to_ids("<|end_header_id|>"),
                tokenizer.convert_tokens_to_ids("<|eot_id|>"),
                tokenizer.convert_tokens_to_ids("\n\n"),
                IMAGE_TOKEN_INDEX,
            ]
            if token_id is not None
        }
        for pos in range(start, start + len(task_ids)):
            if int(prompt_ids_list[pos]) not in special_ids:
                mask[pos] = True
    else:
        try:
            eot_id = int(tokenizer.convert_tokens_to_ids("<|eot_id|>"))
        except Exception:
            eot_id = None
        try:
            image_pos = prompt_ids_list.index(int(IMAGE_TOKEN_INDEX))
        except ValueError:
            image_pos = -1
        end = len(prompt_ids_list)
        if image_pos >= 0 and eot_id is not None:
            for idx in range(image_pos + 1, len(prompt_ids_list)):
                if prompt_ids_list[idx] == eot_id:
                    end = idx
                    break
            for pos in range(image_pos + 1, end):
                token_id = prompt_ids_list[pos]
                if token_id != IMAGE_TOKEN_INDEX and token_id != eot_id:
                    mask[pos] = True

    if device is not None:
        mask = mask.to(device=device)
    return mask


def build_prompt_and_instruction_mask(tokenizer, instruction: str, format_hint: str = "", device=None):
    prompt = build_prompt(tokenizer, instruction, format_hint)
    return prompt, build_instruction_token_mask(tokenizer, prompt, instruction, device=device)

