from __future__ import annotations

import importlib.util
from pathlib import Path

import torch

from llada_gui.click_readout import decode_click_from_field


MODULE_PATH = (
    Path(__file__).resolve().parents[1]
    / "src/llava/model/language_model/screen_state_action_field.py"
)
SPEC = importlib.util.spec_from_file_location(
    "screen_state_action_field", MODULE_PATH
)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)
ScreenStateActionField = MODULE.ScreenStateActionField


def make_inputs():
    torch.manual_seed(7)
    axis = torch.linspace(100.0, 900.0, 5)
    yy, xx = torch.meshgrid(axis, axis, indexing="ij")
    centers = torch.stack((xx.flatten(), yy.flatten()), dim=-1)
    return {
        "query_hidden": torch.randn(3, 16),
        "visual_hidden": torch.randn(25, 16),
        "visual_raw_hidden": torch.randn(25, 16),
        "visual_centers_1000": centers,
        "base_length": 0,
    }


def make_head():
    return ScreenStateActionField(
        hidden_size=16, grounding_dim=16, num_heads=4
    )


def test_peak_anchored_component_preserves_semantic_winner():
    axis = torch.tensor([100.0, 500.0, 900.0])
    yy, xx = torch.meshgrid(axis, axis, indexing="ij")
    centers = torch.stack((xx.flatten(), yy.flatten()), dim=-1)
    probabilities = torch.zeros(9)
    probabilities[0] = 0.90
    probabilities[1] = 0.30
    probabilities[3] = 0.30
    probabilities[8] = 0.80
    mean = decode_click_from_field(
        probabilities,
        centers,
        base_length=0,
        threshold_ratio=0.30,
        selection_mode="mean",
    )
    anchored = decode_click_from_field(
        probabilities,
        centers,
        base_length=0,
        threshold_ratio=0.30,
        selection_mode="peak_anchored",
    )
    assert torch.equal(mean["indices"], torch.tensor([8]))
    assert torch.any(anchored["indices"].eq(0))
    assert not torch.any(anchored["indices"].eq(8))


def test_peak_window_limits_centroid_drift_inside_semantic_component():
    axis = torch.arange(7, dtype=torch.float32) * 100.0 + 100.0
    yy, xx = torch.meshgrid(axis, axis, indexing="ij")
    centers = torch.stack((xx.flatten(), yy.flatten()), dim=-1)
    probabilities = torch.zeros(49)
    probabilities[24] = 1.0
    probabilities[25:28] = 0.40
    probabilities[31] = 0.40
    probabilities[38] = 0.40
    probabilities[45] = 0.40
    anchored = decode_click_from_field(
        probabilities,
        centers,
        base_length=0,
        threshold_ratio=0.30,
        selection_mode="peak_anchored",
    )
    windowed = decode_click_from_field(
        probabilities,
        centers,
        base_length=0,
        threshold_ratio=0.30,
        selection_mode="peak_window",
        peak_window_radius=2,
    )
    peak = centers[24]
    assert torch.linalg.vector_norm(windowed["point"] - peak) < torch.linalg.vector_norm(
        anchored["point"] - peak
    )
    assert int(windowed["indices"].numel()) < int(anchored["indices"].numel())


def test_all_mask_forward_process_matches_absorbing_diffusion():
    clean = torch.tensor([0, 1, 0, 1], dtype=torch.long)
    noisy, masked, t = ScreenStateActionField.sample_forward(
        clean, torch.tensor(1.0)
    )
    assert torch.all(masked)
    assert torch.all(noisy.eq(ScreenStateActionField.MASK))
    assert t.item() == 1.0


def test_extension_initialization_preserves_contextual_primary_map():
    head = make_head().eval()
    inputs = make_inputs()
    output = head.compute_action_field(**inputs)
    query = torch.nn.functional.normalize(
        head.legacy_query_norm(
            head.legacy_query_proj(inputs["query_hidden"])
        ).float(),
        dim=-1,
    )
    visual = torch.nn.functional.normalize(
        head.legacy_visual_norm(
            head.legacy_visual_proj(inputs["visual_hidden"])
        ).float(),
        dim=-1,
    )
    per_query = query @ visual.transpose(0, 1) / head.POINTER_TEMPERATURE
    expected = torch.logsumexp(per_query, dim=0) - torch.log(
        torch.tensor(float(per_query.shape[0]))
    )
    torch.testing.assert_close(output["logits"], expected)
    assert output["visual_basis"] == (
        "contextual_and_fine_grained_screen_lattice"
    )
    assert float(output["contextual_primary_rms"].item()) > 0.0
    assert float(output["raw_residual_rms"].item()) == 0.0


def test_zero_init_raw_cannot_override_contextual_primary_field():
    head = make_head().eval()
    inputs = make_inputs()
    before = head.compute_action_field(**inputs)["logits"]
    changed_raw = dict(inputs)
    changed_raw["visual_raw_hidden"] = torch.randn_like(
        inputs["visual_raw_hidden"]
    ) * 100.0
    after_raw = head.compute_action_field(**changed_raw)["logits"]
    torch.testing.assert_close(before, after_raw)

    changed_context = dict(inputs)
    changed_context["visual_hidden"] = torch.randn_like(
        inputs["visual_hidden"]
    ) * 100.0
    after_context = head.compute_action_field(**changed_context)["logits"]
    assert not torch.allclose(before, after_context)


def test_raw_residual_is_not_amplified_after_a_tiny_update():
    head = make_head().eval()
    inputs = make_inputs()
    with torch.no_grad():
        head.raw_visual_proj.weight.fill_(1e-6)
    output = head.compute_action_field(**inputs)
    residual_rms = float(output["raw_residual_rms"].item())
    assert residual_rms > 0.0
    assert residual_rms < 1e-3


def test_raw_premix_preserves_the_bounded_zero_point_scale():
    head = make_head().eval()
    inputs = make_inputs()
    with torch.no_grad():
        head.raw_visual_proj.weight.fill_(1e-6)
    seed_direction, _ = head._bounded_raw_direction(
        inputs["visual_raw_hidden"]
    )
    expected = seed_direction * (
        head.grounding_dim ** 0.5 * head.raw_residual_rms_limit
    )
    production, _aligned, _projected_rms, _mixed_rms = (
        head._mixed_raw_features(inputs["visual_raw_hidden"])
    )
    # The zero-initialized raw mixer is an identity.  A small update must keep
    # the exact old production scale instead of multiplying it a second time.
    torch.testing.assert_close(production, expected)


def test_raw_alignment_and_production_residual_are_strictly_bounded():
    head = make_head().eval()
    inputs = make_inputs()
    with torch.no_grad():
        head.raw_visual_proj.weight.fill_(1000.0)
        head.raw_visual_norm.weight.fill_(1000.0)
        head.raw_visual_norm.bias.fill_(1000.0)
    action = head.compute_action_field(**inputs)
    aligned = head.compute_fine_grained_alignment(
        query_hidden=inputs["query_hidden"],
        visual_raw_hidden=inputs["visual_raw_hidden"],
        base_length=inputs["base_length"],
    )
    assert float(action["raw_residual_rms"].item()) <= 0.25001
    assert float(aligned["raw_aligned_rms"].item()) <= (
        head.grounding_dim ** -0.5 + 1e-6
    )
    assert float(aligned["logits"].abs().max().item()) <= (
        1.0 / head.POINTER_TEMPERATURE + 1e-4
    )


def test_raw_alignment_cannot_run_away_under_repeated_conflicting_updates():
    head = make_head().train()
    inputs = make_inputs()
    optimizer = torch.optim.SGD(head.parameters(), lr=0.1)
    supports = []
    for positive in ([0], [24], [6, 7, 11, 12], [4, 20]):
        support = torch.zeros(25)
        support[positive] = 1.0
        supports.append(support)
    for step in range(40):
        optimizer.zero_grad(set_to_none=True)
        support = supports[step % len(supports)]
        output = head.compute_objective(
            **inputs,
            object_distribution=support,
            target_box_1000=torch.tensor([0.0, 0.0, 1000.0, 1000.0]),
            is_icon=True,
            diffusion_t=torch.tensor(1.0),
            action_query_count=3,
            raw_alignment_weight=0.5,
        )
        assert torch.isfinite(output["loss"])
        assert float(output["raw_alignment_heat_loss"].item()) < 40.0
        output["loss"].backward()
        torch.nn.utils.clip_grad_norm_(head.parameters(), 1.0)
        optimizer.step()
    final = head.compute_action_field(**inputs)
    assert float(final["raw_residual_rms"].item()) <= 0.25001


def test_raw_alignment_loss_cannot_free_ride_on_contextual_field():
    head = make_head().train()
    inputs = make_inputs()
    support = torch.zeros(25)
    support[[6, 7, 11, 12]] = 1.0
    output = head.compute_objective(
        **inputs,
        object_distribution=support,
        target_box_1000=torch.tensor([250.0, 250.0, 550.0, 550.0]),
        is_icon=True,
        diffusion_t=torch.tensor(1.0),
        raw_alignment_weight=0.5,
    )
    assert torch.isfinite(output["raw_alignment_heat_loss"])
    assert float(output["raw_alignment_heat_loss"].item()) > 0.0
    output["raw_alignment_heat_loss"].backward()
    raw_gradient = head.raw_visual_proj.weight.grad
    assert raw_gradient is not None
    assert torch.isfinite(raw_gradient).all()
    assert float(raw_gradient.abs().sum().item()) > 0.0
    assert float(raw_gradient.norm().item()) < 1e4
    for parameter in (
        head.legacy_query_proj.weight,
        head.legacy_visual_proj.weight,
        head.visual_o.weight,
    ):
        assert parameter.grad is None or torch.all(parameter.grad.eq(0))


def test_fine_grained_alignment_supervises_every_action_query():
    head = make_head().train()
    inputs = make_inputs()
    support = torch.zeros(25)
    support[[6, 7, 11, 12]] = 1.0
    output = head.compute_objective(
        **inputs,
        object_distribution=support,
        target_box_1000=torch.tensor([250.0, 250.0, 550.0, 550.0]),
        is_icon=True,
        diffusion_t=torch.tensor(1.0),
        action_query_count=3,
        raw_alignment_weight=0.5,
    )
    expected = torch.nn.functional.kl_div(
        torch.nn.functional.log_softmax(
            output["raw_alignment_per_query_logits"][:3].float(), dim=-1
        ),
        output["heat_target"].unsqueeze(0).expand(3, -1),
        reduction="sum",
    ) / 3.0
    torch.testing.assert_close(
        output["raw_alignment_per_query_loss"], expected
    )
    torch.testing.assert_close(output["raw_alignment_heat_loss"], expected)


def test_context_masked_raw_alignment_trains_the_raw_visual_mixer():
    head = make_head().train()
    inputs = make_inputs()
    support = torch.zeros(25)
    support[[6, 7, 11, 12]] = 1.0
    # The exact zero bootstrap first learns the raw projection through the
    # residual identity.  Once raw evidence is non-zero, its direct bbox loss
    # must also update the same raw mixer used by production inference.
    with torch.no_grad():
        head.raw_visual_proj.weight.normal_(mean=0.0, std=0.01)
    output = head.compute_objective(
        **inputs,
        object_distribution=support,
        target_box_1000=torch.tensor([250.0, 250.0, 550.0, 550.0]),
        is_icon=True,
        diffusion_t=torch.tensor(1.0),
        action_query_count=3,
        raw_alignment_weight=0.5,
    )
    output["raw_alignment_heat_loss"].backward()
    for parameter in (
        head.raw_visual_proj.weight,
        head.visual_o.weight,
        head.visual_ffn[-1].weight,
    ):
        assert parameter.grad is not None
        assert torch.isfinite(parameter.grad).all()
        assert float(parameter.grad.abs().sum().item()) > 0.0


def test_contextual_primary_field_bypasses_the_raw_visual_mixer():
    head = make_head().eval()
    inputs = make_inputs()
    # With the bounded raw correction disabled, arbitrary raw-mixer weights
    # must not remap the already learned contextual heatmap.
    head.raw_production_scale = 0.0
    before = head.compute_action_field(**inputs)["logits"]
    with torch.no_grad():
        for module in (
            head.visual_q,
            head.visual_k,
            head.visual_v,
            head.visual_o,
            head.visual_ffn[0],
            head.visual_ffn[-1],
        ):
            module.weight.normal_(mean=0.0, std=1.0)
            if module.bias is not None:
                module.bias.normal_(mean=0.0, std=1.0)
    after = head.compute_action_field(**inputs)["logits"]
    torch.testing.assert_close(before, after)


def test_zero_production_scale_keeps_raw_mask_training_gradients():
    head = make_head().train()
    head.raw_production_scale = 0.0
    inputs = make_inputs()
    support = torch.zeros(25)
    support[[6, 7, 11, 12]] = 1.0
    with torch.no_grad():
        head.raw_visual_proj.weight.normal_(mean=0.0, std=0.01)
    action = head.compute_action_field(**inputs)
    assert float(action["raw_residual_rms"].item()) == 0.0
    output = head.compute_objective(
        **inputs,
        object_distribution=support,
        target_box_1000=torch.tensor([250.0, 250.0, 550.0, 550.0]),
        is_icon=True,
        diffusion_t=torch.tensor(1.0),
        action_query_count=3,
        raw_alignment_weight=0.5,
    )
    output["raw_alignment_heat_loss"].backward()
    for parameter in (
        head.raw_visual_proj.weight,
        head.visual_o.weight,
        head.visual_ffn[-1].weight,
    ):
        assert parameter.grad is not None
        assert torch.isfinite(parameter.grad).all()
        assert float(parameter.grad.abs().sum().item()) > 0.0


def test_raw_alignment_view_is_training_only_not_a_second_predictor():
    head = make_head().eval()

    def forbidden(**_):
        raise AssertionError("inference must not call the raw alignment view")

    head.compute_fine_grained_alignment = forbidden
    output = head.sample(**make_inputs(), steps=4)
    assert output["logits"].shape == (25,)
    assert len(output["trajectory"]) == 4


def test_icon_target_matches_box_overlap_support():
    head = make_head()
    inputs = make_inputs()
    support = torch.zeros(25)
    support[[6, 7, 11, 12]] = 1.0
    target = head.build_target_distribution(
        support,
        inputs["visual_centers_1000"],
        torch.tensor([250.0, 250.0, 550.0, 550.0]),
        is_icon=True,
    )
    assert torch.equal(target.gt(0), support.gt(0))
    torch.testing.assert_close(target.sum(), torch.tensor(1.0))
    torch.testing.assert_close(
        target[support.gt(0)],
        torch.full((4,), 0.25),
    )


def test_visible_spatial_state_changes_the_same_action_field():
    head = make_head().eval()
    inputs = make_inputs()
    masked = torch.full((25,), head.MASK, dtype=torch.long)
    visible = masked.clone()
    visible[6:9] = head.TARGET
    with torch.no_grad():
        head.state_embed.weight[head.TARGET].copy_(
            torch.linspace(
                -0.25,
                0.25,
                head.grounding_dim,
            )
        )
        head.visual_o.weight.copy_(torch.eye(head.grounding_dim))
    all_mask = head.compute_action_field(**inputs, noisy_state=masked)["logits"]
    conditioned = head.compute_action_field(**inputs, noisy_state=visible)["logits"]
    assert not torch.allclose(all_mask, conditioned)


def test_all_mask_field_is_invariant_to_trained_state_embeddings():
    head = make_head().eval()
    inputs = make_inputs()
    before = head.compute_action_field(**inputs)["logits"]
    with torch.no_grad():
        head.state_embed.weight.normal_(mean=3.0, std=2.0)
    after = head.compute_action_field(**inputs)["logits"]
    torch.testing.assert_close(before, after)


def test_full_compute_objective_is_finite_and_backpropagates_to_new_abilities():
    head = make_head().train()
    inputs = make_inputs()
    support = torch.zeros(25)
    support[[6, 7, 11, 12]] = 1.0
    explicit_negative = torch.zeros(25)
    explicit_negative[[18, 19, 23, 24]] = 1.0
    output = head.compute_objective(
        **inputs,
        object_distribution=support,
        explicit_negative_distribution=explicit_negative,
        target_box_1000=torch.tensor([250.0, 250.0, 550.0, 550.0]),
        is_icon=True,
        diffusion_t=torch.tensor(1.0),
        support_dice_weight=1.0,
        action_query_count=1,
    )
    assert torch.isfinite(output["loss"])
    assert int(output["explicit_negative_count"].item()) == 4
    assert float(output["counterfactual_loss"].item()) > 0.0
    assert 0.0 <= float(output["support_dice_loss"].item()) <= 1.0
    assert float(output["diffusion_loss"].item()) > 0.0
    assert bool(output["force_all_mask"].item())
    assert not bool(output["no_seed_boundary"].item())
    output["loss"].backward()
    for parameter in (
        head.raw_visual_proj.weight,
        head.state_embed.weight,
        head.offset_head.weight,
    ):
        assert parameter.grad is not None
        assert torch.isfinite(parameter.grad).all()


def test_reverse_chain_monotonically_unmasks_and_returns_one_map():
    head = make_head().eval()
    output = head.sample(**make_inputs(), steps=4)
    trajectory = output["trajectory"]
    assert len(trajectory) == 4
    assert all(
        left["masked_after"] >= right["masked_after"]
        for left, right in zip(trajectory, trajectory[1:])
    )
    assert trajectory[-1]["masked_after"] == 0
    assert output["logits"].shape == (25,)
    assert not torch.any(output["state"].eq(head.MASK))


def test_reverse_commit_uses_global_llada_class_confidence():
    state = torch.full(
        (4,), ScreenStateActionField.MASK, dtype=torch.long
    )
    probabilities = torch.tensor([0.99, 0.51, 0.49, 0.01])
    next_state, committed = (
        ScreenStateActionField.commit_reverse_update(
            state,
            probabilities,
            transfer_count=2,
            remaining_steps=4,
        )
    )
    assert torch.equal(
        torch.nonzero(committed, as_tuple=False).flatten(),
        torch.tensor([0, 3]),
    )
    assert int(next_state[0].item()) == ScreenStateActionField.TARGET
    assert (
        int(next_state[3].item())
        == ScreenStateActionField.BACKGROUND
    )


def test_binary_reverse_commits_target_and_background_progressively():
    state = torch.full(
        (8,), ScreenStateActionField.MASK, dtype=torch.long
    )
    probabilities = torch.tensor(
        [0.95, 0.85, 0.75, 0.65, 0.05, 0.15, 0.25, 0.35]
    )
    next_state, committed = ScreenStateActionField.commit_reverse_update(
        state,
        probabilities,
        transfer_count=2,
        remaining_steps=4,
    )
    assert int(committed.sum().item()) == 2
    assert int((committed & next_state.eq(ScreenStateActionField.TARGET)).sum().item()) == 1
    assert int((committed & next_state.eq(ScreenStateActionField.BACKGROUND)).sum().item()) == 1


def test_normal_absorbing_process_clamps_unused_small_time_regime():
    head = make_head().train()
    inputs = make_inputs()
    support = torch.zeros(25)
    support[[6, 7, 11, 12]] = 1.0
    output = head.compute_objective(
        **inputs,
        object_distribution=support,
        target_box_1000=torch.tensor([250.0, 250.0, 550.0, 550.0]),
        is_icon=True,
        diffusion_t=torch.tensor(0.001),
        support_dice_weight=1.0,
    )
    assert not bool(output["no_seed_boundary"].item())
    assert abs(float(output["t"].item()) - head.MIN_DIFFUSION_TIME) < 1e-6
    assert torch.isfinite(output["loss"])
    assert output["boundary_logits"].shape == output["logits"].shape
    assert output["predicted_clean_state"].shape == output["clean_state"].shape


def test_self_conditioned_inference_boundary_trains_shared_state_path():
    head = make_head().train()
    inputs = make_inputs()
    support = torch.zeros(25)
    support[[6, 7, 11, 12]] = 1.0
    output = head.compute_objective(
        **inputs,
        object_distribution=support,
        target_box_1000=torch.tensor([250.0, 250.0, 550.0, 550.0]),
        is_icon=True,
        diffusion_t=torch.tensor(0.5),
        support_dice_weight=1.0,
    )
    assert float(output["boundary_heat_loss"].item()) > 0.0
    assert float(output["boundary_diffusion_loss"].item()) > 0.0
    output["loss"].backward()
    gradient = head.state_embed.weight.grad
    assert gradient is not None
    assert torch.isfinite(gradient).all()
    assert float(gradient.abs().sum().item()) > 0.0


def test_auxiliary_state_loss_cannot_rewrite_all_mask_locator():
    head = make_head().train()
    inputs = make_inputs()
    support = torch.zeros(25)
    support[[6, 7, 11, 12]] = 1.0
    output = head.compute_objective(
        **inputs,
        object_distribution=support,
        target_box_1000=torch.tensor([250.0, 250.0, 550.0, 550.0]),
        is_icon=True,
        diffusion_t=torch.tensor(0.5),
    )
    output["boundary_heat_loss"].backward()
    state_gradient = head.state_embed.weight.grad
    assert state_gradient is not None
    assert float(state_gradient.abs().sum().item()) > 0.0
    for parameter in (
        head.legacy_query_proj.weight,
        head.legacy_visual_proj.weight,
        head.raw_visual_proj.weight,
        head.visual_o.weight,
    ):
        assert parameter.grad is None or torch.all(parameter.grad.eq(0))


def test_discovery_support_supervision_trains_the_same_visual_locator():
    head = make_head().train()
    inputs = make_inputs()
    field = head.compute_action_field(**inputs)
    truth = torch.zeros_like(field["support_logits"])
    truth[:4] = 1.0
    loss = torch.nn.functional.binary_cross_entropy_with_logits(
        field["support_logits"], truth
    )
    loss.backward()
    assert head.support_logit_bias.grad is not None
    assert head.support_logit_log_scale.grad is not None
    assert head.legacy_query_proj.weight.grad is not None
    assert float(head.legacy_query_proj.weight.grad.abs().sum().item()) > 0.0
    assert head.legacy_visual_proj.weight.grad is not None
    assert float(head.legacy_visual_proj.weight.grad.abs().sum().item()) > 0.0
    assert head.raw_visual_proj.weight.grad is not None
    assert float(head.raw_visual_proj.weight.grad.abs().sum().item()) > 0.0


def test_requested_grounding_width_is_not_silently_capped_at_256():
    head = ScreenStateActionField(
        hidden_size=512, grounding_dim=384, num_heads=8
    )
    assert head.requested_grounding_dim == 384
    assert head.grounding_dim == 384
    assert head.raw_visual_proj.weight.shape == (384, 512)


def test_reverse_chain_does_not_force_the_initial_peak_into_target():
    head = make_head().eval()
    inputs = make_inputs()
    initial = head.compute_action_field(**inputs)
    expected_anchor = int(torch.argmax(initial["logits"]).item())
    with torch.no_grad():
        head.support_logit_bias.fill_(-100.0)
    output = head.sample(**inputs, steps=4)
    assert int(output["state"].eq(head.TARGET).sum().item()) == 0
    assert output["semantic_anchor_index"] is None
    assert output["initial_top_index"] == expected_anchor
    assert int(output["state"][expected_anchor].item()) == head.BACKGROUND
    assert output["forced_nonempty_target"] is False
    assert output["target_commit_probabilities"].shape == (25,)
    assert torch.all(output["target_commit_probabilities"].eq(0))


def test_no_masked_target_keeps_offset_parameters_in_distributed_graph():
    head = make_head().train()
    inputs = make_inputs()
    support = torch.zeros(25)
    support[0] = 1.0
    for seed in range(100):
        torch.manual_seed(seed)
        output = head.compute_objective(
            **inputs,
            object_distribution=support,
            target_box_1000=torch.tensor(
                [90.0, 90.0, 110.0, 110.0]
            ),
            is_icon=True,
            diffusion_t=torch.tensor(0.05),
        )
        if not torch.any(
            output["masked"] & output["clean_state"].eq(head.TARGET)
        ):
            break
    else:
        raise AssertionError("failed to construct no-masked-target case")
    output["loss"].backward()
    for parameter in (
        head.offset_query_proj.weight,
        head.offset_head.weight,
        head.offset_head.bias,
    ):
        assert parameter.grad is not None
        assert torch.isfinite(parameter.grad).all()
