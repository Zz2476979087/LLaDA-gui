from __future__ import annotations

import torch

from llada_gui.click_readout import decode_click_from_field, serialize_click_digits


def regular_grid(size: int = 5) -> torch.Tensor:
    axis = torch.linspace(100.0, 900.0, size)
    yy, xx = torch.meshgrid(axis, axis, indexing="ij")
    return torch.stack((xx.flatten(), yy.flatten()), dim=-1)


def test_connected_readout_does_not_average_disconnected_icons():
    centers = regular_grid()
    probabilities = torch.full((25,), 0.001)
    probabilities[6] = 0.98
    probabilities[7] = 0.90
    probabilities[9] = 0.86
    decoded = decode_click_from_field(
        probabilities,
        centers,
        base_length=0,
        threshold_ratio=0.30,
    )
    expected = (
        centers[6] * probabilities[6] + centers[7] * probabilities[7]
    ) / (probabilities[6] + probabilities[7])
    torch.testing.assert_close(decoded["point"], expected)
    assert decoded["component_count"].item() == 2


def test_high_resolution_grid_excludes_duplicate_base_scale():
    highres = regular_grid()
    base = regular_grid(3)
    centers = torch.cat((base, highres), dim=0)
    probabilities = torch.full((centers.shape[0],), 0.001)
    probabilities[0] = 0.99
    probabilities[base.shape[0] + 12] = 0.80
    decoded = decode_click_from_field(
        probabilities,
        centers,
        base_length=base.shape[0],
    )
    torch.testing.assert_close(decoded["point"], highres[12])


def test_bounded_offset_refines_tiny_icon_without_changing_object_selection():
    centers = regular_grid()
    probabilities = torch.full((25,), 0.001)
    probabilities[12] = 0.90
    offsets = torch.zeros_like(centers)
    offsets[12] = torch.tensor([8.0, -7.0])
    decoded = decode_click_from_field(
        probabilities,
        centers,
        base_length=0,
        offsets_1000=offsets,
    )
    torch.testing.assert_close(decoded["point"], centers[12] + offsets[12])
    assert decoded["indices"].tolist() == [12]


def test_final_coordinate_is_serialized_once_as_twelve_coupled_digits():
    digits = serialize_click_digits(torch.tensor([500.0, 250.0]))
    assert digits.tolist() == [4, 9, 5, 2, 4, 5, 5, 0, 5, 2, 5, 5]
