from llada_gui.action_serialization import action_from_bbox, normalize_bbox1000, parse_lclick


def test_normalize_bbox_norm():
    assert normalize_bbox1000([0.2, 0.3, 0.4, 0.5]) == [200.0, 300.0, 400.0, 500.0]


def test_action_round_trip():
    action, box = action_from_bbox([100, 200, 140, 260])
    assert action == "lclick [115,225,125,235]"
    assert parse_lclick(action) == box
