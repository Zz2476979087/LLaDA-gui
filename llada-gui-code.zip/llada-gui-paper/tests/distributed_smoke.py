"""Minimal NCCL smoke test for the project's four-GPU allocation."""

from __future__ import annotations

import torch
import torch.distributed as dist


def main() -> None:
    dist.init_process_group("nccl")
    rank = dist.get_rank()
    torch.cuda.set_device(rank)
    total = torch.tensor([rank + 1.0], device="cuda")
    dist.all_reduce(total)
    print(
        f"rank={rank} device={torch.cuda.get_device_name(rank)} sum={total.item()}",
        flush=True,
    )
    dist.destroy_process_group()


if __name__ == "__main__":
    main()
