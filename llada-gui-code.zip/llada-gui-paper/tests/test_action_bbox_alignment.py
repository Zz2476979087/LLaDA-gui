from __future__ import annotations

import runpy


MODULE = runpy.run_path("scripts/validate_data.py")


def test_fixed_click_and_element_bbox_with_same_center_are_aligned():
    row = {
        "target_action": "lclick [495,245,505,255]",
        "metadata": {"gui_target_bbox_1000": [450, 200, 550, 300]},
    }
    action = MODULE["action_box"](row)
    target, _ = MODULE["metadata_box"](row)
    assert MODULE["centre"](action) == MODULE["centre"](target)
