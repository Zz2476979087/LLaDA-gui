#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORKSPACE_ROOT="${WORKSPACE_ROOT:-$(cd "${PROJECT_DIR}/.." && pwd)}"
PYTHON_ENV="${PYTHON_ENV:-$(cd "${WORKSPACE_ROOT}/.." && pwd)/myai/env}"
if [[ -x "${PYTHON_ENV}/bin/python" ]]; then
  export PATH="${PYTHON_ENV}/bin:${PATH}"
fi
export PYTHONPATH="${PROJECT_DIR}/src:${PYTHONPATH:-}"
export HF_HUB_OFFLINE="${HF_HUB_OFFLINE:-1}"
export TRANSFORMERS_OFFLINE="${TRANSFORMERS_OFFLINE:-1}"
export HF_DATASETS_OFFLINE="${HF_DATASETS_OFFLINE:-1}"

PY_BIN="${PY_BIN:-python}"
MODEL_PATH="${MODEL_PATH:?MODEL_PATH is required}"
VISION_TOWER="${VISION_TOWER:-${WORKSPACE_ROOT}/models/google_siglip2-so400m-patch14-384}"
MANIFEST="${MANIFEST:-${PROJECT_DIR}/data/eval/screenspot_v2_official.json}"
IMAGE_FOLDER="${IMAGE_FOLDER:?IMAGE_FOLDER is required}"
RUN_TAG="${RUN_TAG:-llada_gui_$(date +%Y%m%d_%H%M%S)}"
OUTPUT="${OUTPUT:-${PROJECT_DIR}/reports/${RUN_TAG}_predictions.json}"
REPORT_OUTPUT="${REPORT_OUTPUT:-${PROJECT_DIR}/reports/${RUN_TAG}_report.json}"
METRICS_OUTPUT="${METRICS_OUTPUT:-${PROJECT_DIR}/reports/${RUN_TAG}_metrics.json}"
SHARD_DIR="${SHARD_DIR:-${PROJECT_DIR}/reports}"
EVAL_GPUS="${EVAL_GPUS:-4}"
REVERSE_STEPS="${REVERSE_STEPS:-4}"
READOUT_SOURCE="${READOUT_SOURCE:-final_support}"
PEAK_RELATIVE_THRESHOLD="${PEAK_RELATIVE_THRESHOLD:-0.30}"
REGION_SELECTION="${REGION_SELECTION:-peak_window}"
LOCAL_WINDOW_RADIUS="${LOCAL_WINDOW_RADIUS:-2}"
USE_LEARNED_OFFSET="${USE_LEARNED_OFFSET:-0}"
ATTN_IMPLEMENTATION="${ATTN_IMPLEMENTATION:-flash_attention_2}"
VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3}"
IFS=',' read -r -a DEVICE_IDS <<< "${VISIBLE_DEVICES}"

if [[ "${#DEVICE_IDS[@]}" -lt "${EVAL_GPUS}" ]]; then
  echo "Expected ${EVAL_GPUS} GPUs, got CUDA_VISIBLE_DEVICES=${VISIBLE_DEVICES}" >&2
  exit 1
fi

mkdir -p "${SHARD_DIR}"
pids=()
shard_outputs=()
shard_reports=()
for ((shard=0; shard<EVAL_GPUS; shard++)); do
  shard_output="${SHARD_DIR}/${RUN_TAG}_shard${shard}.json"
  shard_report="${SHARD_DIR}/${RUN_TAG}_shard${shard}_report.json"
  shard_outputs+=("${shard_output}")
  shard_reports+=("${shard_report}")
  (
    export CUDA_VISIBLE_DEVICES="${DEVICE_IDS[$shard]}"
    optional_args=()
    if [[ "${USE_LEARNED_OFFSET}" == "1" ]]; then
      optional_args+=(--use-learned-offset)
    fi
    "${PY_BIN}" "${PROJECT_DIR}/eval/predict.py" \
      --model-path "${MODEL_PATH}" \
      --vision-tower "${VISION_TOWER}" \
      --manifest "${MANIFEST}" \
      --image-folder "${IMAGE_FOLDER}" \
      --output "${shard_output}" \
      --report-output "${shard_report}" \
      --device cuda:0 \
      --attn-implementation "${ATTN_IMPLEMENTATION}" \
      --reverse-steps "${REVERSE_STEPS}" \
      --readout-source "${READOUT_SOURCE}" \
      --peak-relative-threshold "${PEAK_RELATIVE_THRESHOLD}" \
      --region-selection "${REGION_SELECTION}" \
      --local-window-radius "${LOCAL_WINDOW_RADIUS}" \
      "${optional_args[@]}" \
      --num-shards "${EVAL_GPUS}" \
      --shard-index "${shard}"
  ) &
  pids+=("$!")
done
for pid in "${pids[@]}"; do
  wait "${pid}"
done

"${PY_BIN}" - "${OUTPUT}" "${REPORT_OUTPUT}" "${shard_outputs[@]}" "${shard_reports[@]}" <<'PY'
import json
import sys
from pathlib import Path

output = Path(sys.argv[1])
report_output = Path(sys.argv[2])
rest = sys.argv[3:]
half = len(rest) // 2
prediction_paths = [Path(value) for value in rest[:half]]
report_paths = [Path(value) for value in rest[half:]]
rows = []
for path in prediction_paths:
    rows.extend(json.loads(path.read_text(encoding="utf-8")))
rows.sort(key=lambda row: int(row.get("source_index", 0)))
output.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
report_output.write_text(
    json.dumps(
        {
            "method": "state-conditioned screen-state recovery",
            "merged_rows": len(rows),
            "prediction_shards": [str(path) for path in prediction_paths],
            "shard_reports": [
                json.loads(path.read_text(encoding="utf-8"))
                for path in report_paths
            ],
        },
        ensure_ascii=False,
        indent=2,
    ),
    encoding="utf-8",
)
PY

"${PY_BIN}" "${PROJECT_DIR}/eval/screenspot_v2.py" \
  --manifest "${MANIFEST}" \
  --predictions "${OUTPUT}" \
  --output "${METRICS_OUTPUT}"

echo "predictions=${OUTPUT}"
echo "report=${REPORT_OUTPUT}"
echo "metrics=${METRICS_OUTPUT}"
