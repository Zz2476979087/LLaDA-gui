#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export TRAIN_RECIPE=localization_first
exec bash "${PROJECT_DIR}/scripts/train.sh"
