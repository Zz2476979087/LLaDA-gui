#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path
from typing import Any


ACTION_RE = re.compile(
    r"\[\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*,"
    r"\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\]"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Reject GUI rows whose action centre and metadata bbox disagree."
    )
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--max-center-error", type=float, default=2.0)
    parser.add_argument("--output", type=Path)
    return parser.parse_args()


def action_box(row: dict[str, Any]) -> list[float] | None:
    text = str(row.get("target_action") or "")
    if not text:
        conversations = row.get("conversations") or []
        text = str(conversations[-1].get("value") if conversations else "")
    match = ACTION_RE.search(text)
    return [float(value) for value in match.groups()] if match else None


def metadata_box(row: dict[str, Any]) -> tuple[list[float] | None, str | None]:
    metadata = row.get("metadata") or {}
    for key in ("gui_target_bbox_1000", "bbox_xyxy_norm"):
        value = row.get(key)
        if value is None:
            value = metadata.get(key)
        if value is None:
            continue
        box = [float(item) for item in value[:4]]
        if max(abs(item) for item in box) <= 1.01:
            box = [1000.0 * item for item in box]
        return box, key
    return None, None


def centre(box: list[float]) -> tuple[float, float]:
    return (0.5 * (box[0] + box[2]), 0.5 * (box[1] + box[3]))


def main() -> None:
    args = parse_args()
    rows = json.loads(args.data.read_text(encoding="utf-8"))
    failures = []
    distances = []
    for index, row in enumerate(rows):
        action = action_box(row)
        target, source = metadata_box(row)
        if action is None or target is None:
            failures.append(
                {
                    "index": index,
                    "id": row.get("id"),
                    "reason": "missing_action_or_metadata_bbox",
                }
            )
            continue
        action_centre = centre(action)
        target_centre = centre(target)
        distance = math.hypot(
            action_centre[0] - target_centre[0],
            action_centre[1] - target_centre[1],
        )
        distances.append(distance)
        if distance > float(args.max_center_error):
            failures.append(
                {
                    "index": index,
                    "id": row.get("id"),
                    "image": row.get("image"),
                    "reason": "action_metadata_center_mismatch",
                    "distance_1000": distance,
                    "action_box_1000": action,
                    "metadata_box_1000": target,
                    "metadata_source": source,
                }
            )
    report = {
        "data": str(args.data.resolve()),
        "rows": len(rows),
        "max_center_error_1000": float(args.max_center_error),
        "aligned_rows": len(rows) - len(failures),
        "failures": len(failures),
        "max_observed_center_error_1000": max(distances) if distances else None,
        "failure_examples": failures[:50],
    }
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    if failures:
        raise SystemExit(
            f"refusing misaligned GUI training data: {len(failures)} rows"
        )


if __name__ == "__main__":
    main()
