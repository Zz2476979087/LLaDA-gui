#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORKSPACE_ROOT="${WORKSPACE_ROOT:-$(cd "${PROJECT_DIR}/.." && pwd)}"
PYTHON_ENV="${PYTHON_ENV:-$(cd "${WORKSPACE_ROOT}/.." && pwd)/myai/env}"
if [[ -x "${PYTHON_ENV}/bin/python" ]]; then
  export PATH="${PYTHON_ENV}/bin:${PATH}"
fi

PY_BIN="${PY_BIN:-python}"
GPUS="${GPUS:-4}"
MASTER_ADDR="${MASTER_ADDR:-127.0.0.1}"
MASTER_PORT="${MASTER_PORT:-29311}"
TRAIN_RECIPE="${TRAIN_RECIPE:-joint_optimization}"
DATA_PATH="${DATA_PATH:-${PROJECT_DIR}/data/train.json}"
IMAGE_FOLDER="${IMAGE_FOLDER:-${WORKSPACE_ROOT}}"
RUN_NAME="${RUN_NAME:-llada_gui_${TRAIN_RECIPE}}"
OUTPUT_DIR="${OUTPUT_DIR:-${WORKSPACE_ROOT}/exp/${RUN_NAME}}"
MODEL_PATH="${MODEL_PATH:-${WORKSPACE_ROOT}/models/GSAI-ML_LLaDA-V}"
TOKENIZER_PATH="${TOKENIZER_PATH:-${MODEL_PATH}}"
VISION_TOWER="${VISION_TOWER:-${WORKSPACE_ROOT}/models/google_siglip2-so400m-patch14-384}"
DEEPSPEED_CONFIG="${DEEPSPEED_CONFIG:-${PROJECT_DIR}/scripts/zero3.json}"
MM_TUNABLE_PARTS="${MM_TUNABLE_PARTS:-mm_vision_tower,mm_mlp_adapter,mm_language_model}"

export HF_HUB_OFFLINE="${HF_HUB_OFFLINE:-1}"
export TRANSFORMERS_OFFLINE="${TRANSFORMERS_OFFLINE:-1}"
export HF_DATASETS_OFFLINE="${HF_DATASETS_OFFLINE:-1}"
export PYTHONUNBUFFERED=1
export PYTHONPATH="${PROJECT_DIR}/src:${PYTHONPATH:-}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-8}"
export NCCL_DEBUG="${NCCL_DEBUG:-WARN}"
export TORCHDYNAMO_DISABLE="${TORCHDYNAMO_DISABLE:-1}"

# Screen-state objective: L_map + lambda_x0 L_x0 + L_reg. L_MDM is computed
# by the backbone and combined with this term in modeling_llada.py.
export LLADA_GUI_SCREEN_STATE_OBJECTIVE=True
export LLADA_GUI_SCREEN_STATE_LOSS_WEIGHT="${LLADA_GUI_SCREEN_STATE_LOSS_WEIGHT:-1.0}"
export LLADA_GUI_GROUNDING_DIM="${LLADA_GUI_GROUNDING_DIM:-512}"
export LLADA_GUI_GROUNDING_HEADS="${LLADA_GUI_GROUNDING_HEADS:-8}"
export LLADA_GUI_GROUNDING_DROPOUT="${LLADA_GUI_GROUNDING_DROPOUT:-0.0}"
export LLADA_GUI_STATE_MIXER_SCALE="${LLADA_GUI_STATE_MIXER_SCALE:-64}"
export LLADA_GUI_STATE_PARAMETER_LR="${LLADA_GUI_STATE_PARAMETER_LR:-5e-5}"
export LLADA_GUI_TARGET_LOGIT_BIAS_INIT="${LLADA_GUI_TARGET_LOGIT_BIAS_INIT:--1.5}"
export LLADA_GUI_X0_LOSS_WEIGHT="${LLADA_GUI_X0_LOSS_WEIGHT:-1.0}"
export LLADA_GUI_SUPPORT_DICE_WEIGHT="${LLADA_GUI_SUPPORT_DICE_WEIGHT:-0.1}"
export LLADA_GUI_TARGET_CLASS_BALANCE="${LLADA_GUI_TARGET_CLASS_BALANCE:-0.5}"
export LLADA_GUI_ROLLOUT_MONOTONIC_WEIGHT="${LLADA_GUI_ROLLOUT_MONOTONIC_WEIGHT:-1.0}"
export LLADA_GUI_ROLLOUT_MONOTONIC_MARGIN="${LLADA_GUI_ROLLOUT_MONOTONIC_MARGIN:-0.01}"
export LLADA_GUI_FINE_GRAINED_ALIGNMENT_WEIGHT="${LLADA_GUI_FINE_GRAINED_ALIGNMENT_WEIGHT:-0.5}"
export LLADA_GUI_FINE_GRAINED_RESIDUAL_LIMIT="${LLADA_GUI_FINE_GRAINED_RESIDUAL_LIMIT:-0.25}"
export LLADA_GUI_FINE_GRAINED_PRODUCTION_SCALE="${LLADA_GUI_FINE_GRAINED_PRODUCTION_SCALE:-0}"
export LLADA_GUI_TARGET_RANKING_WEIGHT="${LLADA_GUI_TARGET_RANKING_WEIGHT:-0.5}"
export LLADA_GUI_TARGET_RANKING_MARGIN="${LLADA_GUI_TARGET_RANKING_MARGIN:-0.5}"
export LLADA_GUI_CLICK_REG_WEIGHT="${LLADA_GUI_CLICK_REG_WEIGHT:-0.0}"
export LLADA_GUI_HARD_NEGATIVE_WEIGHT="${LLADA_GUI_HARD_NEGATIVE_WEIGHT:-1.0}"
export LLADA_GUI_HARD_NEGATIVE_MARGIN="${LLADA_GUI_HARD_NEGATIVE_MARGIN:-0.5}"
export LLADA_GUI_PER_QUERY_MAP_LOSS="${LLADA_GUI_PER_QUERY_MAP_LOSS:-True}"

# Canonical-lattice supervision and coordinate-slot masking.
export LLADA_GUI_TARGET_LABEL_ANYRES=True
export LLADA_GUI_TARGET_LABEL_DILATION=0
export LLADA_GUI_TARGET_LABEL_ANYRES_BASE_WEIGHT=1.0
export LLADA_GUI_TARGET_LABEL_ANYRES_SMALL_BASE_WEIGHT=1.0
export LLADA_GUI_TARGET_LABEL_ANYRES_CROP_WEIGHT=1.0
export LLADA_GUI_CANONICAL_CENTERS=True
export LLADA_GUI_MASK_ACTION_TOKENS="${LLADA_GUI_MASK_ACTION_TOKENS:-True}"
export LLADA_GUI_MASK_ACTION_ROWS_ONLY="${LLADA_GUI_MASK_ACTION_ROWS_ONLY:-True}"
export LLADA_GUI_AUDIT_OUTPUT="${LLADA_GUI_AUDIT_OUTPUT:-${PROJECT_DIR}/reports/${RUN_NAME}_loss_audit.jsonl}"
export LLADA_GUI_AUDIT_FORWARDS="${LLADA_GUI_AUDIT_FORWARDS:-256}"

case "${TRAIN_RECIPE}" in
  localization_first)
    export LLADA_GUI_FORCE_ALL_MASK=True
    export LLADA_GUI_ACTION_FIELD_ONLY="${LLADA_GUI_ACTION_FIELD_ONLY:-True}"
    GRADIENT_CHECKPOINTING="${GRADIENT_CHECKPOINTING:-False}"
    LEARNING_RATE="${LEARNING_RATE:-1e-4}"
    MM_PROJECTOR_LR="${MM_PROJECTOR_LR:-1e-4}"
    MM_VISION_TOWER_LR="${MM_VISION_TOWER_LR:-0}"
    export LLADA_GUI_MDM_ROW_MODE="${LLADA_GUI_MDM_ROW_MODE:-visual}"
    export LLADA_GUI_MDM_INSIDE_WEIGHT="${LLADA_GUI_MDM_INSIDE_WEIGHT:-0.0}"
    export LLADA_GUI_MDM_OUTSIDE_WEIGHT="${LLADA_GUI_MDM_OUTSIDE_WEIGHT:-0.0}"
    ;;
  joint_optimization)
    export LLADA_GUI_FORCE_ALL_MASK=False
    export LLADA_GUI_ACTION_FIELD_ONLY="${LLADA_GUI_ACTION_FIELD_ONLY:-False}"
    GRADIENT_CHECKPOINTING="${GRADIENT_CHECKPOINTING:-True}"
    LEARNING_RATE="${LEARNING_RATE:-5e-6}"
    MM_PROJECTOR_LR="${MM_PROJECTOR_LR:-5e-6}"
    MM_VISION_TOWER_LR="${MM_VISION_TOWER_LR:-2e-6}"
    ;;
  *)
    echo "TRAIN_RECIPE must be localization_first or joint_optimization" >&2
    exit 2
    ;;
esac

SCREEN_STATE_LR="${SCREEN_STATE_LR:-${LEARNING_RATE}}"
MAX_GRAD_NORM="${MAX_GRAD_NORM:-1.0}"

echo "python_bin=$(command -v "${PY_BIN}" || true)"
echo "train_recipe=${TRAIN_RECIPE} data=${DATA_PATH} output=${OUTPUT_DIR}"
echo "model=${MODEL_PATH} vision_tower=${VISION_TOWER}"
echo "screen_state: all_mask=${LLADA_GUI_FORCE_ALL_MASK} dim=${LLADA_GUI_GROUNDING_DIM} mixer_scale=${LLADA_GUI_STATE_MIXER_SCALE}"

EXTRA_REPRO_ARGS=()
if [[ -n "${SEED_BEFORE_MODEL_INIT:-}" ]]; then
  EXTRA_REPRO_ARGS+=(--seed_before_model_init "${SEED_BEFORE_MODEL_INIT}")
fi
if [[ -n "${MODEL_INIT_SEED:-}" ]]; then
  EXTRA_REPRO_ARGS+=(--model_init_seed "${MODEL_INIT_SEED}")
fi
if [[ -n "${TRAIN_SAMPLER_SEED:-}" ]]; then
  EXTRA_REPRO_ARGS+=(--train_sampler_seed "${TRAIN_SAMPLER_SEED}")
fi
if [[ -n "${TRAIN_SAMPLE_PLAN_OUTPUT:-}" ]]; then
  EXTRA_REPRO_ARGS+=(--train_sample_plan_output "${TRAIN_SAMPLE_PLAN_OUTPUT}")
fi

DATA_ALIGNMENT_OUTPUT="${DATA_ALIGNMENT_OUTPUT:-${PROJECT_DIR}/reports/${RUN_NAME}_data_alignment.json}"
"${PY_BIN}" "${PROJECT_DIR}/scripts/validate_data.py" \
  --data "${DATA_PATH}" \
  --max-center-error 2.0 \
  --output "${DATA_ALIGNMENT_OUTPUT}"

cd "${PROJECT_DIR}"
"${PY_BIN}" -m torch.distributed.run \
  --nproc_per_node="${GPUS}" \
  --nnodes=1 \
  --master_addr="${MASTER_ADDR}" \
  --master_port="${MASTER_PORT}" \
  --node_rank=0 \
  train.py \
  --deepspeed "${DEEPSPEED_CONFIG}" \
  --model_name_or_path "${MODEL_PATH}" \
  --tokenizer_name_or_path "${TOKENIZER_PATH}" \
  --version llava_llada \
  --data_path "${DATA_PATH}" \
  --image_folder "${IMAGE_FOLDER}" \
  --vision_tower "${VISION_TOWER}" \
  --mm_tunable_parts "${MM_TUNABLE_PARTS}" \
  --mm_projector_type mlp2x_gelu \
  --mm_projector_lr "${MM_PROJECTOR_LR}" \
  --mm_vision_tower_lr "${MM_VISION_TOWER_LR}" \
  --screen_state_lr "${SCREEN_STATE_LR}" \
  --mm_vision_select_layer -2 \
  --mm_use_im_start_end False \
  --mm_use_im_patch_token False \
  --group_by_modality_length True \
  --image_aspect_ratio "${IMAGE_ASPECT_RATIO:-anyres_max_6}" \
  --image_grid_pinpoints "${IMAGE_GRID_PINPOINTS:-(1x1),...,(6x6)}" \
  --mm_patch_merge_type spatial_unpad \
  --bf16 True \
  --run_name "${RUN_NAME}" \
  --output_dir "${OUTPUT_DIR}" \
  --num_train_epochs "${TRAIN_EPOCHS:-1}" \
  --max_steps "${MAX_STEPS:--1}" \
  --per_device_train_batch_size "${PER_DEVICE_TRAIN_BATCH_SIZE:-1}" \
  --per_device_eval_batch_size 4 \
  --gradient_accumulation_steps "${GRAD_ACCUM:-1}" \
  --eval_strategy no \
  --save_strategy "${SAVE_STRATEGY:-epoch}" \
  --save_steps "${SAVE_STEPS:-100000}" \
  --save_total_limit "${SAVE_TOTAL_LIMIT:-2}" \
  --learning_rate "${LEARNING_RATE}" \
  --max_grad_norm "${MAX_GRAD_NORM}" \
  --weight_decay "${WEIGHT_DECAY:-0}" \
  --warmup_ratio "${WARMUP_RATIO:-0.03}" \
  --lr_scheduler_type cosine \
  --logging_steps 1 \
  --seed "${TRAIN_SEED:-42}" \
  "${EXTRA_REPRO_ARGS[@]}" \
  --tf32 True \
  --model_max_length "${MODEL_MAX_LENGTH:-8192}" \
  --gradient_checkpointing "${GRADIENT_CHECKPOINTING}" \
  --dataloader_num_workers "${DATALOADER_NUM_WORKERS:-0}" \
  --lazy_preprocess True \
  --report_to "${REPORT_TO:-tensorboard}" \
  --lora_enable False \
  --dataloader_drop_last True \
  --attn_implementation "${ATTN_IMPLEMENTATION:-flash_attention_2}" \
  --use_conversation_mask False \
  --action_token_weighting "${ACTION_TOKEN_WEIGHTING:-True}" \
  --action_token_weight "${ACTION_TOKEN_WEIGHT:-1.10}" \
  --icon_action_token_weight "${ICON_ACTION_TOKEN_WEIGHT:-1.20}" \
  --small_icon_action_token_weight "${SMALL_ICON_ACTION_TOKEN_WEIGHT:-1.25}" \
  --coordinate_token_weighting "${COORDINATE_TOKEN_WEIGHTING:-True}" \
  --coordinate_token_weight "${COORDINATE_TOKEN_WEIGHT:-1.05}" \
  --icon_coordinate_token_weight "${ICON_COORDINATE_TOKEN_WEIGHT:-1.10}" \
  --small_icon_coordinate_token_weight "${SMALL_ICON_COORDINATE_TOKEN_WEIGHT:-1.15}" \
  --screen_state_objective True \
  --screen_state_loss_weight "${LLADA_GUI_SCREEN_STATE_LOSS_WEIGHT}"
