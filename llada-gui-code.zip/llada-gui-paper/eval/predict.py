#!/usr/bin/env python3
"""Run LLaDA-GUI screen-state recovery and deterministic click readout."""

from __future__ import annotations

import argparse
import json
import traceback
from collections import Counter
from pathlib import Path
from typing import Any

import torch
from PIL import Image

from llada_gui.action_serialization import fixed_click_action
from llada_gui.click_readout import decode_click_from_field, serialize_click_digits
from llada_gui.grounding_prompt import (
    FORMAT_HINT,
    build_prompt_and_instruction_mask,
    first_user_instruction,
)
from llava.constants import IMAGE_TOKEN_INDEX
from llava.mm_utils import process_images, tokenizer_image_token
from llava.model.builder import load_pretrained_model

try:
    from tqdm import tqdm
except Exception:  # pragma: no cover - tqdm is optional for batch inference.
    tqdm = lambda rows, **_: rows


PROJECT_ROOT = Path(__file__).resolve().parents[1]
WORKSPACE_ROOT = PROJECT_ROOT.parent
FULL_SCREEN_BOX = [0.0, 0.0, 1000.0, 1000.0]


def load_manifest(
    path: Path,
    limit: int | None,
    num_shards: int,
    shard_index: int,
) -> list[dict[str, Any]]:
    rows = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(rows, list):
        raise TypeError("evaluation manifest must contain a JSON list")
    if limit is not None:
        rows = rows[:limit]
    selected = []
    for index, row in enumerate(rows):
        if index % num_shards != shard_index:
            continue
        item = dict(row)
        item["_source_index"] = index
        selected.append(item)
    return selected


def find_image(image_folder: Path, image_value: str) -> Path:
    path = Path(str(image_value))
    return path if path.is_absolute() else image_folder / path


def _token_ids_without_bos(tokenizer, text: str) -> list[int]:
    ids = list(tokenizer(text, add_special_tokens=False).input_ids)
    bos = getattr(tokenizer, "bos_token_id", None)
    if ids and bos is not None and int(ids[0]) == int(bos):
        ids = ids[1:]
    return [int(value) for value in ids]


def _find_subsequence(values: list[int], pattern: list[int]) -> int:
    if not pattern or len(pattern) > len(values):
        return -1
    for start in range(len(values) - len(pattern) + 1):
        if values[start : start + len(pattern)] == pattern:
            return start
    return -1


def _build_action_inputs(
    tokenizer,
    prompt: str,
    instruction_mask: torch.Tensor,
    action_marker: str,
    action_stub: str,
    device: str,
    mask_token_id: int,
) -> tuple[torch.Tensor, ...]:
    """Append masked coordinate slots while keeping the action marker visible."""

    prompt_ids = tokenizer_image_token(
        prompt, tokenizer, IMAGE_TOKEN_INDEX, return_tensors="pt"
    )
    input_ids = tokenizer_image_token(
        f"{prompt}{action_stub}",
        tokenizer,
        IMAGE_TOKEN_INDEX,
        return_tensors="pt",
    ).unsqueeze(0).to(device)
    labels = input_ids.clone()
    prompt_length = min(int(prompt_ids.numel()), labels.shape[1])
    labels[:, :prompt_length] = -100
    labels[labels == IMAGE_TOKEN_INDEX] = -100
    attention_mask = torch.ones_like(input_ids, dtype=torch.bool)
    mdm_mask_positions = torch.zeros_like(labels)

    action_query_mask = torch.zeros_like(labels, dtype=torch.bool)
    full_ids = [int(value) for value in input_ids[0].detach().cpu().tolist()]
    for variant in (action_marker, " " + action_marker):
        marker_ids = _token_ids_without_bos(tokenizer, variant)
        start = _find_subsequence(full_ids, marker_ids)
        if start >= 0:
            action_query_mask[0, start : start + len(marker_ids)] = True
            break
    if not torch.any(action_query_mask):
        raise RuntimeError("action marker was not found after tokenization")

    coordinate_mask = torch.zeros_like(labels, dtype=torch.bool)
    for position in range(prompt_length, labels.shape[1]):
        if bool(action_query_mask[0, position].item()):
            continue
        token_id = int(full_ids[position])
        if token_id == IMAGE_TOKEN_INDEX:
            continue
        piece = tokenizer.decode([token_id], skip_special_tokens=False)
        if any(character.isdigit() for character in piece):
            coordinate_mask[0, position] = True

    action_stub_mask = torch.zeros_like(input_ids, dtype=torch.bool)
    action_stub_mask[:, prompt_length:] = True
    action_stub_mask[input_ids == IMAGE_TOKEN_INDEX] = False
    action_stub_mask &= ~action_query_mask
    input_ids = input_ids.clone()
    input_ids[action_stub_mask] = int(mask_token_id)

    prepared_instruction_mask = torch.zeros_like(labels, dtype=torch.bool)
    if instruction_mask is not None and instruction_mask.numel() > 0:
        length = min(int(instruction_mask.numel()), labels.shape[1])
        prepared_instruction_mask[0, :length] = instruction_mask[:length].to(
            device=device, dtype=torch.bool
        )
    return (
        input_ids,
        labels,
        mdm_mask_positions,
        attention_mask,
        prepared_instruction_mask,
        action_query_mask,
        coordinate_mask,
    )


def _require_finite(name: str, tensor: torch.Tensor) -> None:
    finite = torch.isfinite(tensor)
    if bool(finite.all().item()):
        return
    raise FloatingPointError(
        f"{name} contains {int((~finite).sum().item())}/"
        f"{tensor.numel()} non-finite values"
    )


def _prepare_forward(
    model,
    tokenizer,
    image_tensor,
    image_size,
    instruction: str,
    args: argparse.Namespace,
) -> dict[str, torch.Tensor]:
    prompt, prompt_instruction_mask = build_prompt_and_instruction_mask(
        tokenizer,
        instruction,
        args.format_hint,
        device=args.device,
    )
    action_stub = f"lclick [000,000,000,000] {args.action_marker}"
    (
        input_ids,
        labels,
        mdm_mask_positions,
        attention_mask,
        instruction_mask,
        action_query_mask,
        coordinate_mask,
    ) = _build_action_inputs(
        tokenizer,
        prompt,
        prompt_instruction_mask,
        args.action_marker,
        action_stub,
        args.device,
        args.mask_token_id,
    )

    # A full-screen placeholder requests geometry for every visual token. It is
    # never used as target supervision or as part of the click decision.
    prepared = model.prepare_inputs_labels_for_multimodal(
        input_ids,
        None,
        attention_mask,
        None,
        labels,
        image_tensor,
        ["image"],
        image_sizes=[image_size],
        is_llada=True,
        mdm_mask_positions=mdm_mask_positions,
        target_boxes_1000=torch.tensor(
            [FULL_SCREEN_BOX], device=args.device, dtype=torch.float32
        ),
        target_row_mask=torch.tensor(
            [True], device=args.device, dtype=torch.bool
        ),
        instruction_token_mask=instruction_mask,
        action_query_token_mask=action_query_mask,
        coordinate_token_mask=coordinate_mask,
    )
    (
        _input_ids,
        position_ids,
        prepared_attention_mask,
        _past_key_values,
        inputs_embeds,
        prepared_labels,
        _conversation_ids,
        _mdm_token_weights,
        _prepared_mdm_mask_positions,
        _mdm_negative_labels,
    ) = prepared
    hidden_states = model.model(
        input_ids=None,
        attention_mask=prepared_attention_mask,
        position_ids=position_ids,
        inputs_embeds=inputs_embeds,
        use_cache=False,
        output_hidden_states=False,
        return_dict=False,
    )[0]
    return {
        "hidden_states": hidden_states,
        "inputs_embeds": inputs_embeds,
        "visual_support": getattr(model, "_target_support_labels"),
        "visual_centers": getattr(model, "_screen_cell_centers"),
        "action_query_mask": getattr(model, "_action_query_token_mask"),
    }


def _readout_probabilities(
    head,
    initial_field: dict[str, torch.Tensor],
    final_field: dict[str, torch.Tensor],
    args: argparse.Namespace,
) -> tuple[torch.Tensor, str]:
    initial_energy = torch.softmax(initial_field["logits"].float(), dim=-1)
    final_energy = torch.softmax(final_field["logits"].float(), dim=-1)
    if args.readout_source == "initial_energy":
        return initial_energy, "initial_action_field"
    if args.readout_source == "final_energy":
        return final_energy, "final_action_field"

    state = final_field.get("state")
    if state is None or not torch.any(state.eq(head.TARGET)):
        return final_energy, "final_action_field"
    target_sites = state.eq(head.TARGET)
    if args.readout_source == "commit_probability":
        scores = final_field["target_commit_probabilities"].float()
    else:
        scores = final_field["support_probabilities"].float()
    target_indices = torch.nonzero(target_sites, as_tuple=False).flatten()
    if args.readout_topk > 0 and target_indices.numel() > args.readout_topk:
        selected = target_indices.index_select(
            0,
            torch.topk(
                scores.index_select(0, target_indices), k=args.readout_topk
            ).indices,
        )
        target_sites = torch.zeros_like(target_sites)
        target_sites[selected] = True
    probabilities = torch.where(
        target_sites,
        scores.clamp_min(0.0).pow(float(args.readout_power)),
        torch.zeros_like(scores),
    )
    return probabilities, "committed_target_state"


@torch.no_grad()
def score_one(
    model,
    tokenizer,
    image_processor,
    row: dict[str, Any],
    image_folder: Path,
    args: argparse.Namespace,
) -> dict[str, Any]:
    image_path = find_image(image_folder, str(row.get("image") or ""))
    image = Image.open(image_path).convert("RGB")
    image_tensor = process_images([image], image_processor, model.config)
    dtype = torch.float16 if args.torch_dtype == "float16" else torch.bfloat16
    image_tensor = [value.to(device=args.device, dtype=dtype) for value in image_tensor]

    prepared = _prepare_forward(
        model,
        tokenizer,
        image_tensor,
        image.size,
        first_user_instruction(row),
        args,
    )
    visual_mask = prepared["visual_support"][0].ge(0)
    query_mask = prepared["action_query_mask"][0].to(
        device=args.device, dtype=torch.bool
    )
    if not torch.any(query_mask):
        raise RuntimeError("screen-state recovery found no action query")

    hidden = prepared["hidden_states"][0]
    try:
        base_length = int(model.get_vision_tower().num_patches_per_side) ** 2
    except Exception:
        base_length = 27 * 27
    head = model.screen_state_action_field
    field_inputs = {
        "query_hidden": hidden[query_mask],
        "visual_hidden": hidden[visual_mask],
        "visual_raw_hidden": prepared["inputs_embeds"][0, visual_mask],
        "visual_centers_1000": prepared["visual_centers"][0, visual_mask],
        "base_length": base_length,
    }
    for name, tensor in field_inputs.items():
        if isinstance(tensor, torch.Tensor):
            _require_finite(name, tensor)

    initial_field = head.compute_action_field(**field_inputs)
    if args.reverse_steps > 0:
        final_field = head.sample(**field_inputs, steps=args.reverse_steps)
        trajectory = final_field["trajectory"]
    else:
        final_field = initial_field
        trajectory = []
    probabilities, readout_name = _readout_probabilities(
        head, initial_field, final_field, args
    )
    decoded = decode_click_from_field(
        probabilities,
        final_field["field_centers_1000"].float(),
        base_length=0,
        threshold_ratio=float(args.peak_relative_threshold),
        offsets_1000=(
            final_field["offsets_1000"].float()
            if args.use_learned_offset
            else None
        ),
        selection_mode=args.region_selection,
        peak_window_radius=args.local_window_radius,
    )
    point = decoded["point"].float()
    _require_finite("decoded_click", point)
    action, click_box = fixed_click_action(
        float(point[0].item()),
        float(point[1].item()),
        half_size=float(args.click_half_size),
    )
    digits = serialize_click_digits(point, half_size=float(args.click_half_size))

    topk = min(max(int(args.trace_topk), 1), int(probabilities.numel()))
    values, indices = torch.topk(probabilities, k=topk)
    heatmap_topk = [
        {
            "index": int(index),
            "probability": float(value),
            "center": [
                float(v)
                for v in final_field["field_centers_1000"][int(index)]
                .float()
                .tolist()
            ],
        }
        for value, index in zip(values.tolist(), indices.tolist())
    ]
    return {
        "prediction": action,
        "raw_prediction": action,
        "screen_state_recovery": {
            "visual_basis": str(head.VISUAL_BASIS),
            "reverse_steps": int(args.reverse_steps),
            "state_mixer_scale": float(head.state_scale),
            "query_source": "action_marker_with_masked_coordinate_context",
            "action_query_tokens": int(field_inputs["query_hidden"].shape[0]),
            "readout_source": args.readout_source,
            "readout": readout_name,
            "point": [float(value) for value in point.tolist()],
            "click_box": click_box,
            "serialized_digits": [int(value) for value in digits.tolist()],
            "coordinate_generation": "deterministic_serialization_after_region_readout",
            "peak_relative_threshold": float(args.peak_relative_threshold),
            "region_selection": args.region_selection,
            "local_window_radius": int(args.local_window_radius),
            "component_count": int(decoded["component_count"].item()),
            "component_score": float(decoded["score"].item()),
            "component_mass": float(decoded["mass"].item()),
            "active_cells": int(decoded["indices"].numel()),
            "initial_top_index": int(torch.argmax(initial_field["logits"]).item()),
            "final_top_index": int(torch.argmax(final_field["logits"]).item()),
            "visual_tokens": int(visual_mask.sum().item()),
            "field_cells": int(probabilities.numel()),
            "base_lattice_length": int(base_length),
            "fine_grained_production_scale": float(
                final_field["raw_production_scale"].float().item()
            ),
            "heatmap_topk": heatmap_topk,
            "trajectory": trajectory,
        },
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--model-base", default="")
    parser.add_argument("--model-name", default="llava_llada")
    parser.add_argument(
        "--vision-tower",
        default=str(WORKSPACE_ROOT / "models/google_siglip2-so400m-patch14-384"),
    )
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--image-folder", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--report-output", required=True)
    parser.add_argument("--format-hint", default=FORMAT_HINT)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--attn-implementation", default="flash_attention_2")
    parser.add_argument(
        "--torch-dtype", choices=["float16", "bfloat16"], default="float16"
    )
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--num-shards", type=int, default=1)
    parser.add_argument("--shard-index", type=int, default=0)
    parser.add_argument("--action-marker", default="<|gui_ptr|>")
    parser.add_argument("--mask-token-id", type=int, default=126336)
    parser.add_argument("--click-half-size", type=float, default=5.0)
    parser.add_argument("--reverse-steps", type=int, default=4)
    parser.add_argument("--peak-relative-threshold", type=float, default=0.30)
    parser.add_argument(
        "--region-selection",
        choices=["mean", "peak_anchored", "peak_window"],
        default="peak_window",
    )
    parser.add_argument("--local-window-radius", type=int, default=2)
    parser.add_argument("--use-learned-offset", action="store_true")
    parser.add_argument(
        "--readout-source",
        choices=[
            "initial_energy",
            "final_energy",
            "final_support",
            "commit_probability",
        ],
        default="final_support",
    )
    parser.add_argument("--readout-power", type=float, default=1.0)
    parser.add_argument("--readout-topk", type=int, default=0)
    parser.add_argument("--trace-topk", type=int, default=16)
    parser.add_argument("--allow-failures", action="store_true")
    args = parser.parse_args()
    if args.reverse_steps < 0:
        parser.error("--reverse-steps must be non-negative")
    if args.readout_power <= 0:
        parser.error("--readout-power must be positive")
    return args


def _checkpoint_declares_action_field(config: dict[str, Any]) -> bool:
    return any(
        bool(config.get(key, False))
        for key in (
            "screen_state_action_field_enabled",
            "gui_unified_spatial_action_diffusion_enabled",
            "gui_screen_state_action_field_enabled",
            "gui_diffusion_grounding_enabled",
        )
    )


def main() -> None:
    args = parse_args()
    import os

    os.environ["LLADA_GUI_TARGET_LABEL_ANYRES"] = "1"
    os.environ["LLADA_GUI_TARGET_LABEL_DILATION"] = "0"
    os.environ["LLADA_GUI_SCREEN_STATE_OBJECTIVE"] = "1"

    config_path = Path(args.model_path).resolve() / "config.json"
    if not config_path.is_file():
        raise FileNotFoundError(f"missing checkpoint config: {config_path}")
    checkpoint_config = json.loads(config_path.read_text(encoding="utf-8"))
    if not _checkpoint_declares_action_field(checkpoint_config):
        raise RuntimeError("checkpoint does not declare a screen-state action field")

    overwrite_config = {
        "mm_spatial_pool_mode": "bilinear",
        "mm_vision_tower": str(Path(args.vision_tower).resolve()),
        "vision_tower": str(Path(args.vision_tower).resolve()),
    }
    dtype = torch.float16 if args.torch_dtype == "float16" else torch.bfloat16
    tokenizer, model, image_processor, _ = load_pretrained_model(
        str(Path(args.model_path).resolve()),
        str(Path(args.model_base).resolve()) if args.model_base else None,
        args.model_name,
        attn_implementation=args.attn_implementation,
        device_map=args.device,
        torch_dtype=dtype,
        overwrite_config=overwrite_config,
        multimodal=True,
    )
    head = getattr(model, "screen_state_action_field", None)
    if head is None or head.__class__.__name__ != "ScreenStateActionField":
        raise RuntimeError("checkpoint did not instantiate the screen-state action field")
    for name, parameter in head.named_parameters():
        _require_finite(f"screen_state_action_field.{name}", parameter)
    model.eval()

    rows = load_manifest(
        Path(args.manifest), args.limit, args.num_shards, args.shard_index
    )
    predictions: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    counts: Counter[str] = Counter()
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    for row in tqdm(rows, desc=f"LLaDA-GUI shard {args.shard_index}/{args.num_shards}"):
        try:
            scored = score_one(
                model,
                tokenizer,
                image_processor,
                row,
                Path(args.image_folder),
                args,
            )
            predictions.append(
                {
                    "id": row.get("id"),
                    "sample_id": row.get("sample_id") or row.get("id"),
                    "source_index": row.get("_source_index"),
                    "image": row.get("image"),
                    "instruction": first_user_instruction(row),
                    "target_action": row.get("target_action")
                    or ((row.get("conversations") or [{}, {}])[-1].get("value")),
                    **scored,
                }
            )
            counts["ok"] += 1
        except Exception as error:
            failures.append(
                {
                    "id": row.get("id"),
                    "source_index": row.get("_source_index"),
                    "error": repr(error),
                    "traceback": traceback.format_exc(),
                }
            )
            predictions.append(
                {
                    "id": row.get("id"),
                    "sample_id": row.get("sample_id") or row.get("id"),
                    "source_index": row.get("_source_index"),
                    "prediction": "lclick [0,0,1,1]",
                    "raw_prediction": "",
                    "screen_state_recovery_error": repr(error),
                }
            )
            counts["failed"] += 1
        output_path.write_text(
            json.dumps(predictions, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    report = {
        "model_path": str(args.model_path),
        "manifest": str(args.manifest),
        "rows": len(rows),
        "counts": dict(counts),
        "failures": failures[:50],
        "args": vars(args),
    }
    report_path = Path(args.report_output)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if failures and not args.allow_failures:
        raise RuntimeError(f"prediction failed for {len(failures)} samples")


if __name__ == "__main__":
    main()
