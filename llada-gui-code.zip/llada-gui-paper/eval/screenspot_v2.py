#!/usr/bin/env python3
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import re

ACTION_RE = re.compile(
    r"^\s*(type\s+in|lclick|hover)\s*"
    r"\[\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*,"
    r"\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\]",
    flags=re.IGNORECASE | re.DOTALL,
)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Evaluate ScreenSpot-v2 predictions with the official point-in-box click accuracy."
    )
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--predictions", required=True)
    parser.add_argument("--prediction-key", default="prediction")
    parser.add_argument("--output", default=None)
    return parser.parse_args()


def read_json_or_jsonl(path_text):
    path = Path(path_text)
    text = path.read_text(encoding="utf-8")
    if path.suffix == ".jsonl":
        return [json.loads(line) for line in text.splitlines() if line.strip()]
    data = json.loads(text)
    if isinstance(data, list):
        return data
    if isinstance(data, dict) and isinstance(data.get("data"), list):
        return data["data"]
    raise ValueError("Expected a JSON list or JSONL file: {}".format(path))


def parse_action_center(text):
    match = ACTION_RE.match(text or "")
    if not match:
        raise ValueError("Cannot parse GUI action string: {!r}".format(text))
    coords = [max(0.0, min(1000.0, float(match.group(i)))) for i in range(2, 6)]
    x1, y1, x2, y2 = coords
    left, right = sorted((x1, x2))
    top, bottom = sorted((y1, y2))
    return (left + right) / 2.0, (top + bottom) / 2.0


def counter_report(counter):
    total = counter["total"]
    return {
        "total": total,
        "correct": counter["correct"],
        "valid": counter["valid"],
        "accuracy": counter["correct"] / total if total else 0.0,
        "ssr": counter["correct"] / total if total else 0.0,
        "valid_rate": counter["valid"] / total if total else 0.0,
    }


def point_inside_norm(point_1000, bbox_xyxy_norm):
    px, py = point_1000[0] / 1000.0, point_1000[1] / 1000.0
    x1, y1, x2, y2 = [float(v) for v in bbox_xyxy_norm]
    return x1 <= px <= x2 and y1 <= py <= y2


def prediction_map(predictions):
    by_id = {}
    by_source_index = {}
    for idx, row in enumerate(predictions):
        row_id = row.get("sample_id") or row.get("id")
        if row_id is not None:
            by_id[str(row_id)] = row
        if row.get("source_index") is not None:
            by_source_index[int(row["source_index"])] = row
        else:
            by_source_index[idx] = row
    return by_id, by_source_index


def main():
    args = parse_args()
    manifest = read_json_or_jsonl(args.manifest)
    predictions = read_json_or_jsonl(args.predictions)
    pred_by_id, pred_by_source_index = prediction_map(predictions)

    stats = Counter()
    by_domain = defaultdict(Counter)
    by_data_type = defaultdict(Counter)
    by_domain_data_type = defaultdict(Counter)
    parse_failures = []
    missing_predictions = []

    for idx, sample in enumerate(manifest):
        sample_id = str(sample.get("sample_id") or sample.get("id"))
        prediction = pred_by_id.get(sample_id) or pred_by_source_index.get(idx)
        domain = str(sample.get("domain") or "unknown")
        data_type = str(sample.get("data_type") or "unknown")
        group_key = f"{domain}/{data_type}"
        for counter in (stats, by_domain[domain], by_data_type[data_type], by_domain_data_type[group_key]):
            counter["total"] += 1

        if prediction is None:
            missing_predictions.append({"index": idx, "sample_id": sample_id})
            continue

        text = str(prediction.get(args.prediction_key, ""))
        try:
            center = parse_action_center(text)
        except Exception as exc:
            parse_failures.append(
                {
                    "index": idx,
                    "sample_id": sample_id,
                    "error": repr(exc),
                    "prediction": text,
                }
            )
            continue

        for counter in (stats, by_domain[domain], by_data_type[data_type], by_domain_data_type[group_key]):
            counter["valid"] += 1
        if point_inside_norm(center, sample["bbox_xyxy_norm"]):
            for counter in (stats, by_domain[domain], by_data_type[data_type], by_domain_data_type[group_key]):
                counter["correct"] += 1

    domain_reports = {key: counter_report(value) for key, value in sorted(by_domain.items())}
    data_type_reports = {key: counter_report(value) for key, value in sorted(by_data_type.items())}
    domain_type_reports = {key: counter_report(value) for key, value in sorted(by_domain_data_type.items())}
    domain_scores = [item["accuracy"] for item in domain_reports.values() if item["total"] > 0]

    report = {
        "manifest": str(Path(args.manifest).resolve()),
        "predictions": str(Path(args.predictions).resolve()),
        "total": stats["total"],
        "correct": stats["correct"],
        "missing_predictions": len(missing_predictions),
        "parse_failures": len(parse_failures),
        "valid": stats["valid"],
        "valid_rate": stats["valid"] / stats["total"] if stats["total"] else 0.0,
        "accuracy": stats["correct"] / stats["total"] if stats["total"] else 0.0,
        "ssr": stats["correct"] / stats["total"] if stats["total"] else 0.0,
        "avg_accuracy": stats["correct"] / stats["total"] if stats["total"] else 0.0,
        "domain_macro_avg": sum(domain_scores) / len(domain_scores) if domain_scores else 0.0,
        "by_domain": domain_reports,
        "by_data_type": data_type_reports,
        "by_domain_data_type": domain_type_reports,
        "parse_failure_examples": parse_failures[:20],
        "missing_prediction_examples": missing_predictions[:20],
    }

    text = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(text + "\n", encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
