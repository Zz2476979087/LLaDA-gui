#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


DEFAULT_SOURCE_ROOT = ROOT / "data/eval/screenspot_v2"


def parse_args():
    parser = argparse.ArgumentParser(
        description="Wrap the official ScreenSpot-v2 JSONL files for LLaDA-V GUI action inference."
    )
    parser.add_argument("--source-root", type=Path, default=DEFAULT_SOURCE_ROOT)
    parser.add_argument(
        "--splits",
        nargs="+",
        default=["mobile", "desktop", "web"],
        choices=["mobile", "desktop", "web"],
    )
    parser.add_argument("--output", type=Path, default=ROOT / "data/eval/screenspot_v2_official.json")
    return parser.parse_args()


def clamp_coord(value):
    return int(round(max(0.0, min(1000.0, float(value)))))


def normalize_xyxy_rel(bbox_xyxy_norm):
    x1, y1, x2, y2 = [float(v) for v in bbox_xyxy_norm]
    return (
        clamp_coord(x1 * 1000.0),
        clamp_coord(y1 * 1000.0),
        clamp_coord(x2 * 1000.0),
        clamp_coord(y2 * 1000.0),
    )


def format_action(bbox_1000):
    x1, y1, x2, y2 = [clamp_coord(v) for v in bbox_1000]
    left, right = sorted((x1, x2))
    top, bottom = sorted((y1, y2))
    return "lclick [{},{},{},{}]".format(left, top, right, bottom)


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def relative_image_path(source_root, image_path_text):
    image_path = Path(image_path_text)
    image_root = source_root / "images"
    if not image_path.exists():
        raise FileNotFoundError(f"Missing ScreenSpot-v2 image: {image_path}")
    try:
        return image_path.relative_to(image_root).as_posix()
    except ValueError:
        return image_path.name


def convert_row(source_root, row):
    bbox_1000 = normalize_xyxy_rel(row["bbox_xyxy_norm"])
    target_action = format_action(bbox_1000)
    instruction = str(row.get("instruction") or "").strip()
    image_rel = relative_image_path(source_root, row["image_path"])
    sample_id = str(row["sample_id"])
    return {
        "id": sample_id,
        "sample_id": sample_id,
        "image": image_rel,
        "image_path": row["image_path"],
        "instruction": instruction,
        "conversations": [
            {"from": "human", "value": f"<image>\n{instruction}"},
            {"from": "gpt", "value": target_action},
        ],
        "target_action": target_action,
        "bbox_xyxy_norm": row["bbox_xyxy_norm"],
        "bbox_xywh_abs": row.get("bbox_xywh_abs"),
        "width": row.get("width"),
        "height": row.get("height"),
        "domain": row.get("domain"),
        "data_type": row.get("data_type"),
        "data_source": row.get("data_source"),
    }


def main():
    args = parse_args()
    rows = []
    counts = {}
    for split in args.splits:
        path = args.source_root / f"screenspot_v2_{split}.jsonl"
        split_rows = read_jsonl(path)
        counts[split] = len(split_rows)
        rows.extend(convert_row(args.source_root, row) for row in split_rows)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {
                "output": str(args.output),
                "source_root": str(args.source_root),
                "splits": args.splits,
                "counts": counts,
                "rows": len(rows),
                "image_folder": str(args.source_root / "images"),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
